#!/usr/bin/env python3
"""
smartstore.py — Sᴍᴀʀᴛ Sᴛᴏʀᴇ v1.5
Aiogram 3.x · SQLite WAL · Telethon OTP · Solid colours + live Emoji ID panel
"""
import asyncio, csv, html, io, json, logging, math, os, random, re
import sqlite3, time, uuid
from urllib.parse import quote
from contextlib import contextmanager, closing as _closing
from datetime import datetime, timedelta
from typing import Optional

from aiogram import Bot, Dispatcher, F, Router
from aiogram.dispatcher.middlewares.base import BaseMiddleware
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    FSInputFile, BufferedInputFile, ChatJoinRequest, LabeledPrice, PreCheckoutQuery,
    KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove,
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.enums import ParseMode

# ══════════════════════════════════════════════════════════
#   SMALL CAPS FONT SYSTEM
# ══════════════════════════════════════════════════════════
_SMALL_CAPS_MAP = str.maketrans(
    "abcdefghijklmnopqrstuvwxyz",
    "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"
)

# Tags, HTML entities and <code>/<pre> blocks are never transformed.
# This keeps copyable values (UPI ID, crypto address, order codes) exact.
_PROTECTED_RE = re.compile(r"<(code|pre)\b[^>]*>.*?</\1>|<[^>]+>|&#?\w+;|[\w.\-]*@[\w.\-]+", re.S | re.I)

def _small_caps_plain(t):
    return "".join(ch.translate(_SMALL_CAPS_MAP) if (ch.isalpha() and ch.islower()) else ch for ch in t)

def _split_protected(s):
    """Yield (chunk, is_protected) pairs covering the whole string."""
    s = str(s); pos = 0
    for m in _PROTECTED_RE.finditer(s):
        if m.start() > pos: yield s[pos:m.start()], False
        yield m.group(0), True
        pos = m.end()
    if pos < len(s): yield s[pos:], False

def _mk(s: str) -> str:
    return "".join(t if prot else _small_caps_plain(t) for t, prot in _split_protected(s))

# ══════════════════════════════════════════════════════════
#   PREMIUM EMOJI
# ══════════════════════════════════════════════════════════
PREMIUM_EMOJI_IDS = {
    "⚠": ["5287494131701004697"], "🚫": ["5843442811688457782"],
    "✨": ["6280418913301827035"], "👑": ["6278244212446073097"],
    "💎": ["5843543678995404276"], "🎁": ["6278578124678500718"],
    "💰": ["6278497426537975692"], "🎉": ["5841597079557773093"],
    "📦": ["5309924418015743460"], "👤": ["5309946893579605926"],
    "📊": ["5796564360344117069"], "📢": ["6086663828953635018"],
    "✅": ["5843501760114596599"], "📥": ["5253742260054409879"],
    "🔥": ["5424972470023104089"], "⭐": ["6188360872042177432"],
    "🪙": ["5382164415019768638"], "🟢": ["6217399545362392046"],
    "🔵": ["6219767605645812412"], "🔴": ["6219968657359904591"],
    "🛍": ["5298707101604919036"], "🏆": ["5203951816588430946"],
    "🆘": ["5422369784266257729"], "🛠": ["6159082432172663888"],
    "⬅": ["6158759248768541376"], "👥": ["5301252853275309905"],
    "⚙": ["6181276357847161435"], "🔄": ["6158994350983355824"],
    "🔑": ["5843576818963060818"], "🚀": ["6280418913301827035"],
    "💳": ["5382164415019768638"], "📲": ["5309924418015743460"],
    "🌍": ["6278244212446073097"], "🛒": ["5298707101604919036"],
    "📋": ["5796564360344117069"], "🏪": ["5203951816588430946"],
    "🧾": ["5309924418015743460"], "📜": ["5796564360344117069"],
    "😀": ["5309946893579605926"], "🏷": ["5298707101604919036"],
    "➕": ["5382164415019768638"], "➖": ["6226240748426105028"],
    "🗑": ["5843442811688457782"], "🔍": ["5796564360344117069"],
    "⬆": ["6158759248768541376"], "⬇": ["6158759248768541376"],
    "◀": ["6158759248768541376"], "▶": ["6158759248768541376"],
    "👁": ["5309946893579605926"], "✏": ["5796564360344117069"],
    "♻": ["6158994350983355824"], "📤": ["5253742260054409879"],
    "🩺": ["6159082432172663888"], "🛒": ["5298707101604919036"],
    "🤕": ["5309946893579605926"],
}
EMOJI_OVERRIDE: dict = {}   # set at runtime from DB
_TG_EMOJI_RE = re.compile(r'<tg-emoji emoji-id="\d+">(.*?)</tg-emoji>', re.S)

def _norm_e(e): return e.replace("\ufe0f", "")

def _reload_emoji():
    global EMOJI_OVERRIDE
    try: EMOJI_OVERRIDE = json.loads(get_setting("emoji_override", "{}"))
    except Exception: EMOJI_OVERRIDE = {}

def _lookup_e(raw):
    base = _norm_e(raw)
    for k in (base, base + "\ufe0f"):
        if k in EMOJI_OVERRIDE: return EMOJI_OVERRIDE[k]
    for k in (raw, base, base + "\ufe0f"):
        if k in PREMIUM_EMOJI_IDS: return PREMIUM_EMOJI_IDS[k]
    return []

def _emoji_re_pat():
    keys = sorted({_norm_e(k) for k in list(PREMIUM_EMOJI_IDS) + list(EMOJI_OVERRIDE)}, key=len, reverse=True)
    if not keys: return re.compile(r"(?!x)x")
    return re.compile("(" + "|".join("\ufe0f?".join(re.escape(c) for c in k) + "\ufe0f?" for k in keys) + ")")

def _premium_text(text):
    text = _mk(text)
    pat = _emoji_re_pat()
    def sub(m):
        raw = m.group(0); ids = _lookup_e(raw)
        if not ids: return raw
        return f'<tg-emoji emoji-id="{random.choice(ids)}">{raw}</tg-emoji>'
    def plain(seg):
        try: return pat.sub(sub, seg)
        except Exception: return seg
    return "".join(t if prot else plain(t) for t, prot in _split_protected(text))

def _strip_premium(text): return _TG_EMOJI_RE.sub(r"\1", text)

# ══════════════════════════════════════════════════════════
#   BUTTON STYLE + AUTO EMOJI
# ══════════════════════════════════════════════════════════
BTN_COLOURS = {"action": "success", "nav": "primary", "danger": "danger"}
_STYLE_NAMES = {"success": "🟢 Green", "primary": "🔵 Blue", "danger": "🔴 Red"}
_STYLE_KEYS = list(_STYLE_NAMES)
_LEGACY_MAP = {"🟢": "success", "🔵": "primary", "🔴": "danger"}

def _reload_btn_colours():
    global BTN_COLOURS
    for k in ("action", "nav", "danger"):
        v = get_setting(f"btn_{k}", BTN_COLOURS[k]) or BTN_COLOURS[k]
        v = _LEGACY_MAP.get(v, v)
        BTN_COLOURS[k] = v if v in _STYLE_KEYS else BTN_COLOURS[k]

def _style_for(text, kind=None):
    """Only green (success) and blue (primary) for inline buttons. Red is never used."""
    if kind in BTN_COLOURS:
        s = BTN_COLOURS[kind]
    else:
        low = str(text).lower()
        if any(w in low for w in ("buy", "add", "confirm", "save", "verify", "approve", "pay", "send", "deposit", "create", "new", "✅", "➕", "browse")):
            s = BTN_COLOURS["action"]
        else:
            s = BTN_COLOURS["nav"]
    if s not in ("success", "primary"):
        s = "primary"
    return s

BTN_EMOJI_MAP = {
    # shop / buying
    "browse": "🛍", "shop": "🛍", "buy": "🛒", "purchase": "🛒", "order": "🧾", "orders": "🧾",
    "transaction": "🧾", "transactions": "🧾", "wallet": "💰", "balance": "💰", "add funds": "💳",
    "add fund": "💳", "deposit": "📥", "deposits": "📥", "pay": "💳", "payment": "💳", "upi": "💳",
    "crypto": "🪙", "stars": "⭐", "premium": "⭐", "amount": "💵", "custom": "✏", "accept": "✅",
    "agree": "✅", "start": "🚀", "let's start": "🚀", "coupon": "🏷", "coupons": "🏷", "price": "🏷",
    "stock": "📦", "account": "📦", "accounts": "📦", "product": "📦",
    # profile / users / admin
    "profile": "👤", "user": "👥", "users": "👥", "find user": "🔎", "admin": "👑", "admins": "👑",
    "staff": "👑", "permission": "🧩", "permissions": "🧩", "captcha": "🧩", "verification": "🪪",
    "verify": "✅", "verified": "✅", "ban": "🚫", "banned": "🚫", "reject": "🚫", "unban": "✅",
    # referral
    "refer": "🤝", "referral": "🤝", "referrals": "🤝", "earn": "🤝", "share": "📤",
    # navigation
    "back": "⬅", "prev": "◀", "previous": "◀", "next": "▶", "menu": "🏠", "home": "🏠", "main": "🏠",
    "panel": "🧭", "dashboard": "📊", "stats": "📊", "cancel": "❌", "close": "❌", "confirm": "✅",
    "approve": "✅", "apply": "✅", "done": "✅", "success": "✅", "reset": "♻", "refresh": "🔄",
    # actions
    "delete": "🗑", "remove": "🗑", "cut": "➖", "deduct": "➖", "minus": "➖", "add": "➕", "new": "➕",
    "create": "➕", "save": "💾", "backup": "💾", "import": "📥", "export": "📤", "search": "🔍",
    "find": "🔍", "filter": "🎛", "sort": "↕", "bulk": "🎲", "send": "📨", "request": "📨",
    "login": "🔐", "2fa": "🔐", "email": "📧", "otp": "🔢", "code": "🔢",
    # info / support / settings
    "terms": "📜", "support": "🆘", "help": "🆘", "contact": "📞", "sales": "📢", "channel": "📢",
    "channels": "📢", "broadcast": "📢", "setting": "⚙", "settings": "⚙", "config": "⚙", "emoji": "😀",
    "colour": "🎨", "color": "🎨", "colours": "🎨", "colors": "🎨", "stock file": "📁", "file": "📁",
    "media": "🖼", "photo": "🖼", "qr": "🔳", "api": "🔑", "telethon": "📲", "system": "🩺",
    "maintenance": "🛠", "tool": "🧰", "tools": "🧰", "audit": "📋", "list": "📋", "page": "📄",
    "top": "🏆", "buyers": "🏆", "server": "🖥", "spam": "🛡", "warranty": "🛡", "origin": "🌍",
    "spoiler": "✨", "welcome": "👋", "address": "📍", "position": "📍", "id": "🆔", "rate": "💱",
    "min": "⬇", "minimum": "⬇", "max": "⬆", "maximum": "⬆", "status": "📌", "session": "🗂",
    "time": "⏱", "filters": "🎛", "tos": "📜", "maintenance mode": "🛠", "add balance": "➕", "cut balance": "➖", "dev": "🧑", "name": "🏷",
}
_BTN_KW_ORDER = sorted(BTN_EMOJI_MAP, key=len, reverse=True)
_EMOJI_PRESENT = re.compile("[\U0001F000-\U0001FAFF\u2300-\u23FF\u25A0-\u25FF"
                            "\u2600-\u27BF\u2B00-\u2BFF\u3030\u303D\u3297\u3299\uFE0F]")
_BTN_FALLBACK_EMOJI = "🔹"

def _add_emoji_if_missing(text: str) -> str:
    """Every button gets an emoji that matches its label. Labels that already have one are left alone."""
    s_ = str(text)
    if _EMOJI_PRESENT.search(s_): return s_
    if "₹" in s_: return f"💵 {s_}"
    low = s_.lower()
    best = None   # (position in label, -keyword length): the earliest keyword in the label wins
    for kw in _BTN_KW_ORDER:
        m = re.search(r"(?<![a-z0-9])" + re.escape(kw) + r"(?![a-z0-9])", low)
        if m and (best is None or (m.start(), -len(kw)) < best[0]):
            best = ((m.start(), -len(kw)), kw)
    if best: return f"{BTN_EMOJI_MAP[best[1]]} {s_}"
    return f"{_BTN_FALLBACK_EMOJI} {s_}"

ICON_BUTTONS = True   # premium icon on buttons (icon_custom_emoji_id), like hh.py

def split_icon(label):
    """Button label -> (text, premium icon id or None). The first mapped emoji becomes the icon."""
    if not ICON_BUTTONS: return label, None
    pat = _emoji_re_pat()
    m = pat.match(label)
    if not (m and _lookup_e(m.group(0))):
        m = pat.search(label)
        if not (m and _lookup_e(m.group(0))): return label, None
    icon = random.choice(_lookup_e(m.group(0)))
    rest = (label[:m.start()] + label[m.end():]).replace("  ", " ").strip()
    return rest, icon

# ── per-button colours: every button is registered by its key and can be recoloured live ──
BTN_REG = {}   # key -> {"label", "grp" ("menu" | "adm"), "dflt" (style), "h" (short id)}
BTN_OVR = {}   # key -> "success" | "primary" | "danger" | "none"   (set from Admin → Button Colours)

def _btn_key(cb, url):
    return ("u:" + url) if url else ("c:" + str(cb))

def _btn_hash(key):
    import hashlib
    return hashlib.md5(key.encode()).hexdigest()[:10]

def _btn_style(key, default):
    if key in BTN_OVR:
        v = BTN_OVR[key]
        return None if v == "none" else v
    return default

def _reload_btn_overrides():
    BTN_OVR.clear()
    with db() as c:
        for r in c.execute("SELECT k, v FROM extras_kv WHERE k LIKE 'bc:%'").fetchall():
            if r["v"] in ("success", "primary", "danger", "none"): BTN_OVR[r["k"][3:]] = r["v"]

VALID_STYLES = ("success", "primary", "danger")

def _reg_btn(key, label, cb, dflt):
    if dflt not in VALID_STYLES: dflt = "primary"
    grp = "adm" if (cb and str(cb).startswith(("adm", "xadm"))) else "menu"
    e = BTN_REG.get(key)
    if e is None: BTN_REG[key] = {"label": str(label), "grp": grp, "dflt": dflt, "h": _btn_hash(key)}
    else: e["label"] = str(label); e["dflt"] = dflt

def make_btn(text, cb=None, url=None, kind=None, default_style=None, reg=True, plain=False):
    """plain=True keeps the label exactly as written (no small caps). Premium icon still applies."""
    t = _add_emoji_if_missing(text) if plain else _mk(_add_emoji_if_missing(text))
    key = _btn_key(cb, url)
    dflt = default_style or _style_for(t, kind)
    if reg: _reg_btn(key, text, cb, dflt)
    style = _btn_style(key, dflt)
    extra = {"style": style} if style else {}
    full = t
    t, icon = split_icon(t)
    if icon and t.strip(): extra["icon_custom_emoji_id"] = icon
    elif icon: t = full
    if url: return InlineKeyboardButton(text=t or " ", url=url, **extra)
    return InlineKeyboardButton(text=t or " ", callback_data=cb, **extra)

def _ib(text, cb, kind=None): return make_btn(text=text, cb=cb, kind=kind)
def _ib_url(text, url, kind=None): return make_btn(text=text, url=url, kind=kind)
def xbtn(text, cb, kind="nav"): return make_btn(text=text, cb=cb, kind=kind)

def _kb(*rows):
    out = []
    for row in rows:
        r = []
        for item in row:
            t, d = item[0], item[1]
            kind = item[2] if len(item) > 2 else None
            r.append(_ib_url(t, d, kind) if str(d).startswith("http") else _ib(t, d, kind))
        out.append(r)
    return InlineKeyboardMarkup(inline_keyboard=out)

def xkb(*rows):
    out = []
    for row in rows:
        r = []
        for item in row:
            if isinstance(item, InlineKeyboardButton):
                r.append(item); continue
            t, d = item[0], item[1]
            kind = item[2] if len(item) > 2 else None
            r.append(xbtn(t, d, kind))
        out.append(r)
    return InlineKeyboardMarkup(inline_keyboard=out)

# ══════════════════════════════════════════════════════════
#   CONFIG
# ══════════════════════════════════════════════════════════
def _load_dotenv(path):
    if not os.path.isfile(path): return
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            k, _, v = line.partition("="); v = v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'": v = v[1:-1]
            os.environ.setdefault(k.strip(), v)
_load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

def _env(k, d=""): return os.environ.get(k, d).strip()
def _env_int(k, d):
    try: return int(_env(k, str(d)))
    except ValueError: raise SystemExit(f"[config] {k} integer")
def _env_ids(k):
    try: return {int(x) for x in _env(k).replace(" ", "").split(",") if x}
    except ValueError: raise SystemExit(f"[config] {k} numeric ids")

BOT_TOKEN = _env("BOT_TOKEN", "PASTE_NEW_TOKEN_HERE")   # naya token yahan daalo (BotFather se)
ADMIN_IDS = _env_ids("ADMIN_IDS") or {8725834864}
SALES_CHANNEL = _env_int("SALES_CHANNEL", 0)   # apna channel ID (-100...) yahan ya settings panel se
SUPPORT_BOT = _env("SUPPORT_BOT", "https://t.me/RkLiveShopBot?start=ref_7849786352")
UPI_ID = _env("UPI_ID", "yourupi@paytm")   # apni asli UPI ID yahan ya settings panel se
SALE_PHOTO_PATH = _env("SALE_PHOTO_PATH", "sale_card.jpg")
DB_PATH = _env("DB_PATH", "smartstore.db")
SUPERADMIN_ID = int(_env("SUPERADMIN_ID", "8725834864") or 0)
DEPOSIT_TTL_MIN = _env_int("DEPOSIT_TTL_MIN", 30)
BULK_MAX = _env_int("BULK_MAX", 50)
LOG_LEVEL = _env("LOG_LEVEL", "INFO").upper()
PAGE_SIZE = 8

if not BOT_TOKEN or ":" not in BOT_TOKEN: raise SystemExit("[config] BOT_TOKEN missing")
if not ADMIN_IDS: raise SystemExit("[config] ADMIN_IDS missing")

logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.INFO),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("smartstore")
BOT_NAME = "Sᴍᴀʀᴛ Sᴛᴏʀᴇ"
LOGO = f"🏪 <b>{BOT_NAME}</b>"
START_TIME = datetime.now()
bot: Optional[Bot] = None
BOT_USERNAME = ""
# ══════════════════════════════════════════════════════════
#   DB
# ══════════════════════════════════════════════════════════
@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        with conn: yield conn
    finally: conn.close()

def get_setting(key, default=""):
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default
def set_setting(key, value):
    with db() as c:
        c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, value))
def cfg_sales_channel():
    v = get_setting("sales_channel", "").strip()
    try: return int(v) if v else SALES_CHANNEL
    except ValueError: return SALES_CHANNEL
def cfg_support():
    return get_setting("support_bot", "").strip() or SUPPORT_BOT
def cfg_upi():
    return get_setting("upi_id", "").strip() or UPI_ID
def _cfg_value(key, raw):
    s = (raw or "").strip()
    if key == "sales_channel":
        return s if re.fullmatch(r"-100\d{5,}", s) else None
    if key == "support_bot":
        m = re.fullmatch(r"(?:https?://)?t\.me/([A-Za-z0-9_]{4,})/?|@([A-Za-z0-9_]{4,})", s)
        return f"https://t.me/{m.group(1) or m.group(2)}" if m else None
    if key == "upi_id":
        return s if re.fullmatch(r"[A-Za-z0-9._\-]{2,}@[A-Za-z0-9._\-]{2,}", s) else None
    return None
def esc(s): return html.escape(str(s if s is not None else ""))
def _money(x): return f"₹{float(x or 0):,.2f}"
def _midnight(days_back=0):
    d = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    return (d - timedelta(days=days_back)).isoformat()
def _norm_code(raw):
    raw = raw.strip()
    return "ss_" + raw[3:].upper() if raw.lower().startswith("ss_") else raw
def gen_order_code(): return "ss_" + uuid.uuid4().hex[:8].upper()
def deposit_limits():
    return float(get_setting("min_deposit", "10")), float(get_setting("max_deposit", "2500"))
def new_deposit(uid, amount, method="upi"):
    code = gen_order_code()
    expires = (datetime.now() + timedelta(minutes=DEPOSIT_TTL_MIN)).strftime("%d-%m-%Y %H:%M:%S")
    with db() as c:
        c.execute("INSERT INTO deposits(order_code,user_id,amount,method,created_at,expires_at) "
                  "VALUES(?,?,?,?,?,?)", (code, uid, amount, method, datetime.now().isoformat(), expires))
    return code, expires

# ───────── ADMIN / USER helpers ─────────
ROLES = {"full": "🔑 Full Access", "deposits": "💳 Deposits Only", "stock": "📦 Stock Only", "custom": "🧩 Custom"}
PERM_KEYS = ["deposits", "stock", "emoji", "coupons", "settings", "tools"]
PERM_LABELS = {"deposits": "💳 Deposits", "stock": "📦 Stock", "emoji": "😀 Emoji",
               "coupons": "🏷 Coupons", "settings": "⚙️ Settings", "tools": "🧰 Tools"}

def is_admin(uid):
    if uid in ADMIN_IDS: return True
    with db() as c:
        return bool(c.execute("SELECT 1 FROM admins WHERE user_id=?", (uid,)).fetchone())
def admin_role(uid):
    if uid in ADMIN_IDS: return "full"
    with db() as c:
        row = c.execute("SELECT role FROM admins WHERE user_id=?", (uid,)).fetchone()
        return row["role"] if row else ""
def admin_perms(uid):
    with db() as c:
        r = c.execute("SELECT perms FROM admins WHERE user_id=?", (uid,)).fetchone()
    return (set((r["perms"] or "").split(",")) - {""}) if r else set()
def has_perm(uid, perm):
    role = admin_role(uid)
    if role == "full": return True
    if role == "custom": return perm in admin_perms(uid)
    return perm == role
def can_tools(uid):
    """Tools: only SUPERADMIN, or a custom-role admin explicitly given the 'tools' permission.
    Note: has_perm() returns True for every key on 'full' admins, so it must not be used here."""
    if SUPERADMIN_ID and uid == SUPERADMIN_ID: return True
    return admin_role(uid) == "custom" and "tools" in admin_perms(uid)

def add_admin(uid, added_by, role="full"):
    with db() as c:
        c.execute("INSERT OR REPLACE INTO admins(user_id,added_by,role,added_at) VALUES(?,?,?,?)",
                  (uid, added_by, role, datetime.now().isoformat()))
def remove_admin(uid):
    with db() as c: c.execute("DELETE FROM admins WHERE user_id=?", (uid,))
def log_admin(admin_id, action):
    with db() as c:
        c.execute("INSERT INTO admin_log(admin_id,action,ts) VALUES(?,?,?)",
                  (admin_id, action, datetime.now().isoformat()))

def is_banned(uid):
    with db() as c:
        row = c.execute("SELECT is_banned FROM users WHERE user_id=?", (uid,)).fetchone()
        return bool(row and row["is_banned"])
def is_verified(uid):
    with db() as c:
        row = c.execute("SELECT verified FROM users WHERE user_id=?", (uid,)).fetchone()
        return bool(row and row["verified"])
def ensure_user(uid, username, name):
    with db() as c:
        c.execute("INSERT OR IGNORE INTO users(user_id,username,name,joined_at) VALUES(?,?,?,?)",
                  (uid, username or "", name, datetime.now().isoformat()))
        c.execute("UPDATE users SET username=?, name=? WHERE user_id=?",
                  (username or "", name, uid))
def set_verified(uid):
    with db() as c: c.execute("UPDATE users SET verified=1 WHERE user_id=?", (uid,))
    xset(f"vtime:{uid}", datetime.now().strftime("%Y-%m-%d %H:%M"))

def set_unverified(uid):
    with db() as c: c.execute("UPDATE users SET verified=0 WHERE user_id=?", (uid,))
def user_balance(uid):
    with db() as c:
        row = c.execute("SELECT balance FROM users WHERE user_id=?", (uid,)).fetchone()
        return row["balance"] if row else 0.0
def add_balance(uid, amount, deposited=False, admin_id=0, note=""):
    with db() as c:
        if deposited:
            cur = c.execute("UPDATE users SET balance=balance+?, total_deposited=total_deposited+? "
                            "WHERE user_id=?", (amount, amount, uid))
        else:
            cur = c.execute("UPDATE users SET balance=balance+? WHERE user_id=?", (amount, uid))
        if cur.rowcount == 1 and admin_id:
            c.execute("INSERT INTO balance_logs(admin_id,user_id,action,amount,note,created_at) "
                      "VALUES(?,?,?,?,?,?)",
                      (admin_id, uid, "add", amount, note, datetime.now().isoformat()))
        return cur.rowcount == 1
def cut_balance(uid, amount, admin_id=0, note=""):
    with db() as c:
        cur = c.execute("UPDATE users SET balance=balance-? WHERE user_id=? AND balance>=?",
                        (amount, uid, amount))
        if cur.rowcount == 1 and admin_id:
            c.execute("INSERT INTO balance_logs(admin_id,user_id,action,amount,note,created_at) "
                      "VALUES(?,?,?,?,?,?)",
                      (admin_id, uid, "cut", amount, note, datetime.now().isoformat()))
        return cur.rowcount == 1
def deduct_balance(uid, amount):
    with db() as c:
        cur = c.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                        "WHERE user_id=? AND balance>=?", (amount, amount, uid, amount))
        return cur.rowcount == 1
def refund_balance(uid, amount):
    with db() as c:
        c.execute("UPDATE users SET balance=balance+?, total_spent=total_spent-? WHERE user_id=?",
                  (amount, amount, uid))
def confirm_deposit(code):
    with db() as c:
        cur = c.execute("UPDATE deposits SET status='paid' WHERE order_code=? AND status IN ('pending','review')", (code,))
        if cur.rowcount != 1: return None
        dep = c.execute("SELECT * FROM deposits WHERE order_code=?", (code,)).fetchone()
        c.execute("UPDATE users SET balance=balance+?, total_deposited=total_deposited+? WHERE user_id=?",
                  (dep["amount"], dep["amount"], dep["user_id"]))
    return dep
def reject_deposit(code):
    with db() as c:
        cur = c.execute("UPDATE deposits SET status='rejected' WHERE order_code=? AND status IN ('pending','review')", (code,))
        if cur.rowcount != 1: return None
        return c.execute("SELECT * FROM deposits WHERE order_code=?", (code,)).fetchone()
def claim_account(acc_id, uid):
    now = datetime.now().isoformat()
    with db() as c:
        cur = c.execute("UPDATE accounts SET sold=1, sold_to=?, sold_at=? "
                        "WHERE id=? AND sold=0 AND session_data IS NOT NULL AND session_data<>''",
                        (uid, now, acc_id))
        if cur.rowcount == 0: return None
        return c.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
def release_account(acc_id):
    with db() as c:
        c.execute("UPDATE accounts SET sold=0, sold_to=NULL, sold_at=NULL WHERE id=?", (acc_id,))

# ══════════════════════════════════════════════════════════
#   FSM
# ══════════════════════════════════════════════════════════
class Flow(StatesGroup):
    captcha = State()
    math_captcha = State()
    waiting_custom_dep = State()
    waiting_country_srch = State()
    waiting_bulk_qty = State()
    add_bal_uid = State(); add_bal_amt = State()
    cut_bal_uid = State(); cut_bal_amt = State()
    find_user = State(); find_order = State()
    setting_value = State(); broadcast_wait = State(); sale_photo_wait = State()
    aa_admin_uid = State(); aa_admin_role = State()
    ac_server = State(); ac_country = State(); ac_dial = State(); ac_phone = State()
    ac_price = State(); ac_origin = State(); ac_twofa = State(); ac_session = State()
    tl_phone = State(); tl_otp = State(); tl_2fa = State()
    api_id_wait = State(); api_hash_wait = State()
    stock_file_wait = State()
    emoji_id_wait = State()
    emoji_key_wait = State(); eid_lookup_wait = State(); eid_link_wait = State()
    ep_find = State(); ep_value = State()

class ExFlow(StatesGroup):
    welcome_wait = State(); emoji_id_wait = State(); fch_wait = State(); qr_wait = State()

# ══════════════════════════════════════════════════════════
#   DB INIT
# ══════════════════════════════════════════════════════════
def _migrate_users(c):
    cols = {r[1] for r in c.execute("PRAGMA table_info(users)").fetchall()}
    if "gems" not in cols: c.execute("ALTER TABLE users ADD COLUMN gems INTEGER DEFAULT 0")
    if "premium_until" not in cols: c.execute("ALTER TABLE users ADD COLUMN premium_until REAL DEFAULT 0")
    if "last_daily" not in cols: c.execute("ALTER TABLE users ADD COLUMN last_daily REAL DEFAULT 0")
    if "login_streak" not in cols: c.execute("ALTER TABLE users ADD COLUMN login_streak INTEGER DEFAULT 0")
    if "referred_by" not in cols: c.execute("ALTER TABLE users ADD COLUMN referred_by INTEGER DEFAULT 0")
    if "ref_earned" not in cols: c.execute("ALTER TABLE users ADD COLUMN ref_earned REAL DEFAULT 0")
    c.execute("""CREATE TABLE IF NOT EXISTS ref_rewards (order_code TEXT PRIMARY KEY, referrer_id INTEGER,
                 buyer_id INTEGER, amount REAL, created_at TEXT)""")

def _migrate_accounts(c):
    cols = {r[1] for r in c.execute("PRAGMA table_info(accounts)").fetchall()}
    if "position" not in cols: c.execute("ALTER TABLE accounts ADD COLUMN position INTEGER DEFAULT 0")

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY, username TEXT, name TEXT,
            balance REAL DEFAULT 0.0, total_spent REAL DEFAULT 0.0,
            total_deposited REAL DEFAULT 0.0, joined_at TEXT,
            is_banned INTEGER DEFAULT 0, verified INTEGER DEFAULT 0, referrals INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS admins (
            user_id INTEGER PRIMARY KEY, added_by INTEGER,
            role TEXT DEFAULT 'full', added_at TEXT, perms TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT, server INTEGER, country TEXT, dial TEXT,
            phone TEXT, session_data TEXT, twofa_pass TEXT DEFAULT '',
            price REAL, origin TEXT DEFAULT 'Manual', type TEXT DEFAULT 'Fresh',
            premium INTEGER DEFAULT 0, spam_block INTEGER DEFAULT 0,
            twofa INTEGER DEFAULT 0, email INTEGER DEFAULT 0,
            chats INTEGER DEFAULT 0, groups INTEGER DEFAULT 0, admin_count INTEGER DEFAULT 0,
            uploaded_at TEXT, last_seen TEXT, sold INTEGER DEFAULT 0,
            sold_to INTEGER, sold_at TEXT);
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT, order_code TEXT UNIQUE,
            user_id INTEGER, account_id INTEGER, price REAL,
            status TEXT DEFAULT 'pending', created_at TEXT);
        CREATE TABLE IF NOT EXISTS deposits (
            id INTEGER PRIMARY KEY AUTOINCREMENT, order_code TEXT UNIQUE,
            user_id INTEGER, amount REAL, method TEXT,
            status TEXT DEFAULT 'pending', created_at TEXT, expires_at TEXT);
        CREATE TABLE IF NOT EXISTS balance_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, user_id INTEGER,
            action TEXT, amount REAL, note TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS admin_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, action TEXT, ts TEXT);
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS extras_kv (k TEXT PRIMARY KEY, v TEXT);
        CREATE TABLE IF NOT EXISTS fchannels (
            chat_id TEXT PRIMARY KEY, title TEXT, is_private INTEGER DEFAULT 0,
            invite_url TEXT, ts REAL);
        CREATE TABLE IF NOT EXISTS join_reqs (
            user_id INTEGER, chat_id TEXT, ts REAL, PRIMARY KEY(user_id, chat_id));
        CREATE TABLE IF NOT EXISTS stars_payments (charge_id TEXT PRIMARY KEY, user_id INTEGER, amount REAL, stars INTEGER, ts TEXT);
        CREATE TABLE IF NOT EXISTS pct_coupons (
            code TEXT PRIMARY KEY, pct INTEGER, uses_left INTEGER, created_at REAL);
        CREATE TABLE IF NOT EXISTS otp_watchers (
            account_id INTEGER PRIMARY KEY, buyer_id INTEGER,
            session_data TEXT, started_at TEXT, expires_at TEXT);
        """)
        defaults = [
            ("sale_photo", SALE_PHOTO_PATH), ("warranty_hours", "0"),
            ("min_deposit", "10"), ("max_deposit", "2500"),
            ("api_id", ""), ("api_hash", ""), ("crypto_address", ""),
            ("crypto_coin", "USDT TRC20"),
            ("btn_action", "success"), ("btn_nav", "primary"), ("btn_danger", "danger"),
            ("emoji_override", "{}"), ("stars_rate", "1"),
            ("welcome_text", "<i>Welcome!</i>"),
            ("welcome_dev", "@admin"), ("tos_owner", ""),
            ("otp_admin_id", "0"), ("otp_admin_link", ""),
            ("verif_contact", "1"), ("verif_math", "0"), ("tl_price", "10"),
        ]
        for k, v in defaults:
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
        for aid in ADMIN_IDS:
            c.execute("INSERT OR IGNORE INTO admins(user_id,added_by,role,added_at) VALUES(?,?,?,?)",
                      (aid, 0, "full", datetime.now().isoformat()))
        _migrate_users(c)
        _migrate_accounts(c)
    _reload_btn_colours()
    _reload_emoji()

# ───────── extras_kv helpers ─────────
def _xq(sql, args=(), one=False, fetch=True):
    with db() as c:
        cur = c.execute(sql, args)
        if not fetch: return None
        rows = cur.fetchall()
        return (rows[0] if rows else None) if one else rows
def xget(k, default=""):
    r = _xq("SELECT v FROM extras_kv WHERE k=?", (k,), one=True)
    return r["v"] if r else default
def xset(k, v):
    with db() as c: c.execute("INSERT OR REPLACE INTO extras_kv(k,v) VALUES(?,?)", (k, str(v)))
    # ══════════════════════════════════════════════════════════
#   COUNTRY DIAL INFO
# ══════════════════════════════════════════════════════════
COUNTRIES = {
    "+1":("USA / Canada","🇺🇸"), "+7":("Russia","🇷🇺"), "+20":("Egypt","🇪🇬"),
    "+27":("South Africa","🇿🇦"), "+30":("Greece","🇬🇷"), "+31":("Netherlands","🇳🇱"),
    "+32":("Belgium","🇧🇪"), "+33":("France","🇫🇷"), "+34":("Spain","🇪🇸"),
    "+36":("Hungary","🇭🇺"), "+39":("Italy","🇮🇹"), "+40":("Romania","🇷🇴"),
    "+41":("Switzerland","🇨🇭"), "+43":("Austria","🇦🇹"), "+44":("UK","🇬🇧"),
    "+45":("Denmark","🇩🇰"), "+46":("Sweden","🇸🇪"), "+47":("Norway","🇳🇴"),
    "+48":("Poland","🇵🇱"), "+49":("Germany","🇩🇪"), "+51":("Peru","🇵🇪"),
    "+52":("Mexico","🇲🇽"), "+54":("Argentina","🇦🇷"), "+55":("Brazil","🇧🇷"),
    "+56":("Chile","🇨🇱"), "+57":("Colombia","🇨🇴"), "+58":("Venezuela","🇻🇪"),
    "+60":("Malaysia","🇲🇾"), "+61":("Australia","🇦🇺"), "+62":("Indonesia","🇮🇩"),
    "+63":("Philippines","🇵🇭"), "+65":("Singapore","🇸🇬"), "+66":("Thailand","🇹🇭"),
    "+77":("Kazakhstan","🇰🇿"), "+81":("Japan","🇯🇵"), "+82":("South Korea","🇰🇷"),
    "+84":("Vietnam","🇻🇳"), "+86":("China","🇨🇳"), "+90":("Turkey","🇹🇷"),
    "+91":("India","🇮🇳"), "+92":("Pakistan","🇵🇰"), "+93":("Afghanistan","🇦🇫"),
    "+94":("Sri Lanka","🇱🇰"), "+98":("Iran","🇮🇷"), "+212":("Morocco","🇲🇦"),
    "+213":("Algeria","🇩🇿"), "+216":("Tunisia","🇹🇳"), "+218":("Libya","🇱🇾"),
    "+221":("Senegal","🇸🇳"), "+224":("Guinea","🇬🇳"), "+225":("Ivory Coast","🇨🇮"),
    "+233":("Ghana","🇬🇭"), "+234":("Nigeria","🇳🇬"), "+237":("Cameroon","🇨🇲"),
    "+243":("DR Congo","🇨🇩"), "+244":("Angola","🇦🇴"), "+249":("Sudan","🇸🇩"),
    "+250":("Rwanda","🇷🇼"), "+251":("Ethiopia","🇪🇹"), "+254":("Kenya","🇰🇪"),
    "+255":("Tanzania","🇹🇿"), "+256":("Uganda","🇺🇬"), "+263":("Zimbabwe","🇿🇼"),
    "+380":("Ukraine","🇺🇦"), "+381":("Serbia","🇷🇸"), "+385":("Croatia","🇭🇷"),
    "+420":("Czech","🇨🇿"), "+421":("Slovakia","🇸🇰"), "+358":("Finland","🇫🇮"),
    "+370":("Lithuania","🇱🇹"), "+371":("Latvia","🇱🇻"), "+372":("Estonia","🇪🇪"),
    "+374":("Armenia","🇦🇲"), "+375":("Belarus","🇧🇾"), "+880":("Bangladesh","🇧🇩"),
    "+855":("Cambodia","🇰🇭"), "+960":("Maldives","🇲🇻"), "+961":("Lebanon","🇱🇧"),
    "+962":("Jordan","🇯🇴"), "+963":("Syria","🇸🇾"), "+964":("Iraq","🇮🇶"),
    "+965":("Kuwait","🇰🇼"), "+966":("Saudi","🇸🇦"), "+967":("Yemen","🇾🇪"),
    "+968":("Oman","🇴🇲"), "+971":("UAE","🇦🇪"), "+972":("Israel","🇮🇱"),
    "+973":("Bahrain","🇧🇭"), "+974":("Qatar","🇶🇦"), "+977":("Nepal","🇳🇵"),
    "+992":("Tajikistan","🇹🇯"), "+993":("Turkmenistan","🇹🇲"), "+994":("Azerbaijan","🇦🇿"),
    "+995":("Georgia","🇬🇪"), "+996":("Kyrgyzstan","🇰🇬"), "+998":("Uzbekistan","🇺🇿"),
}
_COUNTRY_CODES_SORTED = sorted(COUNTRIES.keys(), key=len, reverse=True)

def _dial_info(dial):
    name, emoji = COUNTRIES.get(dial, (dial, "🏳"))
    return {"name": name, "emoji": emoji}
def _flag(dial): return COUNTRIES.get(dial, (None, "🏳"))[1]

def dial_from_phone(phone: str) -> str:
    p = (phone or "").strip()
    if not p.startswith("+"): p = "+" + p.lstrip("+")
    for code in _COUNTRY_CODES_SORTED:
        if p.startswith(code): return code
    return "+0"
def country_from_phone(phone: str) -> tuple[str, str]:
    dial = dial_from_phone(phone)
    info = _dial_info(dial)
    return info["name"], dial

# ══════════════════════════════════════════════════════════
#   WELCOME MESSAGE BUILDER & TOS
# ══════════════════════════════════════════════════════════
def build_welcome_msg(uid: int, name: str, username: str) -> str:
    try: bal = _money(user_balance(uid))
    except Exception: bal = "₹0.00"
    with db() as c:
        refs = c.execute("SELECT referrals FROM users WHERE user_id=?", (uid,)).fetchone()
        ref_count = refs["referrals"] if refs else 0
    dev_name = get_setting("welcome_dev", "@admin")
    return (
        "➖➖➖➖➖➖➖➖➖➖\n"
        f"💎 𝐖ᴇʟᴄᴏᴍᴇ 𝐓ᴏ {esc(BOT_NAME)}\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        f"🌸 𝐇ᴇʏ <a href=\"tg://user?id={uid}\">{esc(name)}</a> ✔️\n"
        f"🆔 Tɢ ɪᴅ : <a href=\"tg://user?id={uid}\"><code>{uid}</code></a>\n"
        f"🪙 Wᴀʟʟᴇᴛ : {bal}\n"
        f"👥 𝐑ᴇꜰᴇʀʀᴀʟꜱ : {ref_count}\n"
        "➖➖➖➖➖➖➖➖➖➖\n"
        f"🥰 𝐃ᴇᴠᴇʟᴏᴘᴇʀ : <b>{esc(dev_name)}</b>\n"
        "➖➖➖➖➖➖➖➖➖➖"
    )

def _terms_text():
    owner = get_setting("tos_owner", "").strip()
    owner_line = f"Oᴡɴᴇʀ {esc(owner)}" if owner else "Oᴡɴᴇʀ @conboxohere"
    return (
        "<b>Tᴇʀᴍꜱ ᴏꜰ Sᴇʀᴠɪᴄᴇ</b>\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        "<i>Bʏ ᴜꜱɪɴɢ ᴛʜɪꜱ ʙᴏᴛ ʏᴏᴜ ᴀɢʀᴇᴇ ᴛᴏ ᴀʟʟ ᴛᴇʀᴍꜱ ʙᴇʟᴏᴡ</i>\n"
        "━━━━━━━━━━━━━━━━━━━\n\n"
        "🚫 <b>Nᴏ Rᴇꜰᴜɴᴅꜱ</b>\n"
        "Aʟʟ ꜱᴀʟᴇꜱ ᴀʀᴇ ꜰɪɴᴀʟ. Nᴏ ʀᴇꜰᴜɴᴅꜱ ᴜɴᴅᴇʀ ᴀɴʏ ᴄɪʀᴄᴜᴍꜱᴛᴀɴᴄᴇꜱ.\n\n"
        "⚠️ <b>Sᴜʙ-₹99 Rᴜʟᴇ</b>\n"
        "Aᴄᴄᴏᴜɴᴛꜱ ᴘʀɪᴄᴇᴅ ʙᴇʟᴏᴡ ₹99 ᴄᴀʀʀʏ ɴᴏ ᴡᴀʀʀᴀɴᴛʏ ꜰᴏʀ ʟᴏɢɪɴ ꜰᴀɪʟᴜʀᴇꜱ ᴏʀ ᴍɪꜱꜱɪɴɢ ᴄᴏᴅᴇꜱ.\n\n"
        "🔒 <b>Nᴏ Rᴇ-Lᴏɢɪɴꜱ</b>\n"
        "Sᴇꜱꜱɪᴏɴꜱ ᴀʀᴇ ᴘᴇʀᴍᴀɴᴇɴᴛʟʏ ᴄʟᴏꜱᴇᴅ ᴀꜰᴛᴇʀ ᴘᴜʀᴄʜᴀꜱᴇ. Oɴʟʏ ᴏɴᴇ ʟᴏɢɪɴ ᴡɪʟʟ ᴡᴏʀᴋ.\n\n"
        "⏳ <b>Nᴏ Lᴏɴɢᴇᴠɪᴛʏ Gᴜᴀʀᴀɴᴛᴇᴇ</b>\n"
        "Wᴇ ᴅᴏ ɴᴏᴛ ɢᴜᴀʀᴀɴᴛᴇᴇ ᴀᴄᴄᴏᴜɴᴛ ʟɪꜰᴇꜱᴘᴀɴ, 2FA ꜱᴛᴀᴛᴜꜱ, ᴏʀ ꜱᴘᴀᴍ ʙʟᴏᴄᴋ ꜱᴛᴀᴛᴜꜱ.\n\n"
        "⚖️ <b>Lɪᴀʙɪʟɪᴛʏ</b>\n"
        "Usᴇ ᴀᴛ ʏᴏᴜʀ ᴏᴡɴ ʀɪꜱᴋ. Wᴇ ᴀʀᴇ ɴᴏᴛ ʀᴇꜱᴘᴏɴꜱɪʙʟᴇ ꜰᴏʀ ᴀɴʏ ʟᴏꜱꜱ ᴏꜰ ꜰᴜɴᴅꜱ ᴏʀ ᴀᴄᴄᴏᴜɴᴛꜱ.\n\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        f"<i>{owner_line}</i>"
    )

# ══════════════════════════════════════════════════════════
#   FORCE-JOIN + welcome media
# ══════════════════════════════════════════════════════════
def _chat_ref(cid):
    """Channel reference: @username, t.me/username link, or numeric -100 id. Anything else -> friendly ValueError."""
    s = str(cid).strip()
    m = re.fullmatch(r"(?:https?://)?(?:t\.me|telegram\.me)/([A-Za-z][A-Za-z0-9_]{3,})/?", s)
    if m: return "@" + m.group(1)
    if s.startswith("@"): return s
    if re.fullmatch(r"-?\d+", s): return int(s)
    raise ValueError("Channel ka @username ya -100… wali ID bhejo. (Emoji pack / invite link yahan kaam nahi karta.)")
async def _joined(bot_, uid, cid):
    if _xq("SELECT 1 FROM join_reqs WHERE user_id=? AND chat_id=?", (uid, str(cid)), one=True):
        return True
    try:
        m = await bot_.get_chat_member(_chat_ref(cid), uid)
        return m.status in ("member", "administrator", "creator", "restricted")
    except Exception as e:
        log.warning("force-join check failed for %s: %s", cid, e); return False
async def missing_channels(bot_, uid):
    out = []
    for c in _xq("SELECT chat_id,title,is_private,invite_url FROM fchannels ORDER BY ts"):
        if not await _joined(bot_, uid, c["chat_id"]): out.append(dict(c))
    return out
def _media_of(m):
    if m.photo: return "photo", m.photo[-1].file_id
    if m.video: return "video", m.video.file_id
    if m.animation: return "animation", m.animation.file_id
    return None, None

async def send_welcome(msg, caption, markup=None):
    fid, kind = xget("welcome_media"), xget("welcome_type")
    if fid and kind and len(caption) <= 1000:
        send = {"photo": msg.answer_photo, "video": msg.answer_video,
                "animation": msg.answer_animation}.get(kind)
        if send:
            try:
                return await send(fid, caption=_premium_text(caption), reply_markup=markup,
                                  parse_mode=ParseMode.HTML,
                                  has_spoiler=xget("welcome_spoiler", "1") == "1")
            except Exception as e:
                log.warning("welcome %s failed, sending text instead: %s", kind, e)
                if "file" in str(e).lower():
                    xset("welcome_media", ""); xset("welcome_type", "")
    return await msg.answer(_premium_text(caption), reply_markup=markup, parse_mode=ParseMode.HTML)

# ══════════════════════════════════════════════════════════
#   SAFE SEND
# ══════════════════════════════════════════════════════════
async def safe_edit(cb: CallbackQuery, text: str, kb_: Optional[InlineKeyboardMarkup] = None):
    text_p = _premium_text(text)
    try: await cb.message.edit_text(text_p, reply_markup=kb_, parse_mode=ParseMode.HTML)
    except TelegramBadRequest as e:
        if "not modified" not in str(e):
            try: await cb.message.edit_text(_strip_premium(text_p), reply_markup=kb_, parse_mode=ParseMode.HTML)
            except Exception: pass

async def send_safe(uid: int, text: str, kb_: Optional[InlineKeyboardMarkup] = None) -> bool:
    text_p = _premium_text(text)
    for _ in range(2):
        try:
            await bot.send_message(uid, text_p, parse_mode=ParseMode.HTML, reply_markup=kb_); return True
        except TelegramBadRequest as e:
            if "entity_text_invalid" in str(e).lower():
                try:
                    await bot.send_message(uid, _strip_premium(text_p), parse_mode=ParseMode.HTML, reply_markup=kb_); return True
                except Exception: return False
            return False
        except TelegramRetryAfter as e: await asyncio.sleep(e.retry_after + 1)
        except (TelegramForbiddenError, TelegramBadRequest): return False
        except Exception as e: log.error(f"send {uid}: {e}"); return False
    return False

# ══════════════════════════════════════════════════════════
#   USER ROUTER
# ══════════════════════════════════════════════════════════
router = Router()
_filters: dict = {}

class BanMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user and not is_admin(user.id) and is_banned(user.id):
            if isinstance(event, CallbackQuery): await event.answer("🚫 Banned.", show_alert=True)
            elif isinstance(event, Message): await event.answer("🚫 Banned.")
            return None
        return await handler(event, data)
router.message.outer_middleware(BanMiddleware())
router.callback_query.outer_middleware(BanMiddleware())

def start_btn_kb(uid: int):
    btn = make_btn("Let's Start 🤕", cb="show_shop", kind="action")
    return InlineKeyboardMarkup(inline_keyboard=[[btn]])

def _sales_url():
    """Sales channel link. Admin setting 'sales_link' wins, then env SALES_LINK, then the channel id."""
    link = get_setting("sales_link", "").strip() or _env("SALES_LINK", "")
    if link: return link
    if cfg_sales_channel(): return f"https://t.me/c/{str(cfg_sales_channel())[4:]}"
    return ""

def main_menu_kb(uid: Optional[int] = None) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [make_btn("Browse Accounts", cb="browse", default_style="success", plain=True)],
        [make_btn("Wallet", cb="wallet", default_style="primary", plain=True),
         make_btn("My Orders", cb="myorders", default_style="primary", plain=True)],
        [make_btn("Profile", cb="profile", default_style="primary", plain=True),
         make_btn("Refer & Earn", cb="referral", default_style="primary", plain=True)],
    ])
    link_row = []
    if _sales_url(): link_row.append(make_btn("Sales", url=_sales_url(), default_style="primary", plain=True))
    link_row.append(make_btn("Support", url=cfg_support(), default_style="primary", plain=True))
    kb.inline_keyboard.append(link_row)
    kb.inline_keyboard.append([make_btn("Terms of Service", cb="terms", default_style="primary", plain=True)])
    if uid is not None and is_admin(uid):
        kb.inline_keyboard.append([make_btn("Admin Panel", cb="adm:home", default_style="success", plain=True)])
    return kb

def captcha_kb(result: int) -> InlineKeyboardMarkup:
    opts = [result]
    while len(opts) < 4:
        fake = result + random.randint(-10, 10)
        if fake != result and fake not in opts and fake > 0: opts.append(fake)
    random.shuffle(opts)
    return xkb(*[[xbtn(str(o), f"cap_{o}", "nav") for o in opts[i:i+2]] for i in range(0, 4, 2)]) 
CAPTCHA_EMOJIS = ["🍎", "🍌", "🍇", "🍒", "🐶", "🐱", "🐼", "🦊", "🚗", "🚀", "⚽", "🎈", "🌟", "🌙", "🔥", "💎", "🎁", "🏠", "🌈", "🍕", "🎸", "🌵"]

def _new_captcha():
    pool = random.sample(CAPTCHA_EMOJIS, 4)
    return random.choice(pool), pool

def _captcha_view(target, pool):
    text = (f"🧩 <b>VERIFICATION</b>\n{'─'*22}\n\n"
            "Bot use karne se pehle verify karo.\n\n"
            f"Neeche se wahi emoji dabao jo yahan dikh raha hai:\n\n<b>{target}</b>")
    kb_ = xkb([make_btn(e, cb=f"mcap_{i}", kind="nav", reg=False, plain=True) for i, e in enumerate(pool[:2])],
              [make_btn(e, cb=f"mcap_{i + 2}", kind="nav", reg=False, plain=True) for i, e in enumerate(pool[2:])])
    return text, kb_

async def _send_math_captcha(msg: Message, state: FSMContext):
    """Verification step: tap the emoji that is shown. (Name kept so the existing flow still calls it.)"""
    target, pool = _new_captcha()
    await state.set_state(Flow.math_captcha)
    await state.update_data(cap_ans=target, cap_opts=pool)
    text, kb_ = _captcha_view(target, pool)
    await msg.answer(_premium_text(text), reply_markup=kb_, parse_mode=ParseMode.HTML)

@router.callback_query(F.data.startswith("mcap_"))
async def cb_math_captcha(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    opts = data.get("cap_opts") or []
    target = data.get("cap_ans")
    try: choice = opts[int(cb.data.split("_")[1])]
    except Exception: return await cb.answer("❌ Error", show_alert=True)
    if choice != target:
        new_target, pool = _new_captcha()
        await state.update_data(cap_ans=new_target, cap_opts=pool)
        await cb.answer("❌ Galat emoji! Naya captcha.", show_alert=True)
        text, kb_ = _captcha_view(new_target, pool)
        return await safe_edit(cb, text, kb_)
    await cb.answer("✅ Sahi!")
    if get_setting("verif_contact", "1") == "1" and not xget(f"phone:{cb.from_user.id}", ""):
        return await _ask_contact(cb.message, state)
    set_verified(cb.from_user.id); await state.clear()
    await safe_edit(cb, "✅ <b>Verified!</b>")
    await _after_verify(cb.message, cb.from_user)

@router.message(CommandStart())
async def cmd_start(msg: Message, state: FSMContext, command: CommandObject):
    await state.clear()
    is_new = not _user_exists(msg.from_user.id)
    ensure_user(msg.from_user.id, msg.from_user.username, msg.from_user.full_name)
    if is_new: _set_referrer(msg.from_user.id, command.args or "")
    if (command.args or "").strip().lower() == "buy":
        xset(f"deep:{msg.from_user.id}", "buy")   # opened from the channel's Buy Now button
    if is_admin(msg.from_user.id):
        return await _after_verify(msg, msg.from_user)
    set_unverified(msg.from_user.id)     # verification is asked on every /start
    await _begin_verification(msg, state, msg.from_user)

async def _show_tos(target):
    await target.answer(_premium_text(_terms_text()), reply_markup=tos_accept_kb(), parse_mode=ParseMode.HTML)

async def _ask_contact(msg, state):
    contact_kb = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="📱 Share Contact", request_contact=True)]], resize_keyboard=True, one_time_keyboard=True)
    await state.set_state(Flow.captcha)
    await msg.answer(_premium_text(f"🔐 <b>CONTACT</b>\n{'─'*22}\n\nYe sirf ek baar chahiye. Apna contact share karo.\n\n<i>Neeche 📱 Share Contact dabao ⬇</i>"),
                     reply_markup=contact_kb, parse_mode=ParseMode.HTML)

async def _begin_verification(msg, state, user):
    v_contact = get_setting("verif_contact", "1") == "1"
    v_captcha = get_setting("verif_math", "1") == "1"      # the emoji captcha (name kept from the old setting)
    has_phone = bool(xget(f"phone:{user.id}", ""))
    if v_captcha:
        return await _send_math_captcha(msg, state)
    if v_contact and not has_phone:
        return await _ask_contact(msg, state)
    set_verified(user.id); await state.clear()
    await _after_verify(msg, user)

@router.message(F.contact)
async def contact_verify(msg: Message, state: FSMContext):
    if msg.contact.user_id != msg.from_user.id:
        return await msg.answer("❌ Apna hi contact share karo (📱 Share Contact button se).")
    xset(f"phone:{msg.from_user.id}", msg.contact.phone_number or "")
    set_verified(msg.from_user.id)
    await state.clear()
    await msg.answer("✅ Verified!", reply_markup=ReplyKeyboardRemove())
    await _after_verify(msg, msg.from_user)

def shop_page_text(user) -> str:
    """Single source for the shop page, used by 'Let's Start' and every Back / Main menu."""
    uid = user.id
    name = user.first_name or user.full_name
    uname = f"@{user.username}" if user.username else "—"
    bal = _money(user_balance(uid))
    sep = "➖" * 10
    return (
        "🏪 <b>SMART ACCOUNT STORE</b>\n"
        "💎 <b>PREMIUM TELEGRAM ACCOUNTS</b>\n"
        f"{sep}\n\n"
        f"👋 Hᴇʏ <a href=\"tg://user?id={uid}\">{esc(name)}</a>\n"
        f"👤 USERNAME : {esc(uname)}\n"
        f"🆔 USER ID : <code>{uid}</code>\n"
        f"💰 BALANCE : <b>{bal}</b>\n\n"
        f"{sep}\n"
        "Browse and purchase verified Telegram accounts.\n"
        "⚡ Instant delivery • 🔒 Secure checkout • 🆘 24/7 support\n"
        "<b>Lᴇᴛ'ꜱ Sʜᴏᴩ</b>"
    )

@router.callback_query(F.data == "show_shop")
async def cb_show_shop(cb: CallbackQuery, state: FSMContext):
    # Opens the shop as a NEW message so the welcome message above stays intact.
    await state.clear()
    await cb.message.answer(_premium_text(shop_page_text(cb.from_user)),
                            reply_markup=main_menu_kb(cb.from_user.id), parse_mode=ParseMode.HTML)
    await cb.answer()

@router.callback_query(F.data == "main")
async def cb_main(cb: CallbackQuery, state: FSMContext):
    # Back / Main menu always lands on the shop page, never on the welcome message.
    await state.clear()
    await safe_edit(cb, shop_page_text(cb.from_user), main_menu_kb(cb.from_user.id))
    await cb.answer()

@router.callback_query(F.data == "profile")
async def cb_profile(cb: CallbackQuery):
    uid = cb.from_user.id
    with db() as c:
        u = c.execute("SELECT * FROM users WHERE user_id=?", (uid,)).fetchone()
        if not u: return await cb.answer("Pehle /start.", show_alert=True)
        bought = c.execute("SELECT COUNT(*) FROM orders WHERE user_id=? AND status='delivered'", (uid,)).fetchone()[0]
    text = (f"👤 <b>MY PROFILE</b>\n{'─'*24}\nName: {esc(u['name'])}\nUsername: @{esc(u['username'] or '—')}\n"
            f"ID: <code>{u['user_id']}</code>\nJoined: {(u['joined_at'] or '')[:10]}\n{'─'*24}\n"
            f"💰 Balance: {_money(u['balance'])}\n🛒 Purchased: {bought}\n"
            f"💸 Spent: {_money(u['total_spent'])}\n📥 Deposited: {_money(u['total_deposited'])}")
    await safe_edit(cb, text, profile_kb()); await cb.answer()

@router.callback_query(F.data == "wallet")
async def cb_wallet(cb: CallbackQuery):
    with db() as c:
        u = c.execute("SELECT balance,total_deposited,total_spent FROM users WHERE user_id=?", (cb.from_user.id,)).fetchone()
    text = (f"💰 <b>WALLET</b>\n{'─'*24}\nBalance: <b>{_money(u['balance'] if u else 0)}</b>\n"
            f"Deposited: {_money(u['total_deposited'] if u else 0)}\nSpent: {_money(u['total_spent'] if u else 0)}")
    await safe_edit(cb, text, wallet_kb()); await cb.answer()

@router.callback_query(F.data == "txns")
async def cb_txns(cb: CallbackQuery):
    with db() as c:
        rows = c.execute("SELECT amount,status,method,created_at FROM deposits WHERE user_id=? ORDER BY id DESC LIMIT 10", (cb.from_user.id,)).fetchall()
    icon = {"paid":"✅","pending":"⏳","review":"🔎","rejected":"❌"}
    meth = {"upi":"💳","crypto":"🔑"}
    if rows:
        lines = [f"{icon.get(r['status'],'•')} {meth.get(r['method'],'•')} {_money(r['amount'])} · {r['status']} · {(r['created_at'] or '')[:16]}" for r in rows]
        text = "🧾 <b>TRANSACTIONS</b>\n\n" + "\n".join(lines)
    else: text = "🧾 <b>TRANSACTIONS</b>\n\nEmpty."
    await safe_edit(cb, text, _kb([("Back", "wallet")])); await cb.answer()

@router.callback_query(F.data == "addfunds")
async def cb_addfunds(cb: CallbackQuery):
    min_d, max_d = deposit_limits()
    await safe_edit(cb, f"➕ <b>ADD FUNDS</b>\n{'─'*24}\nMin: {_money(min_d)} Max: {_money(max_d)}\n\nPayment:",
                    addfunds_kb()); await cb.answer()

@router.callback_query(F.data == "dep_upi")
async def cb_dep_upi(cb: CallbackQuery):
    await safe_edit(cb, "💳 <b>UPI — Amount</b>", amount_kb("upi")); await cb.answer()

@router.callback_query(F.data == "dep_crypto")
async def cb_dep_crypto(cb: CallbackQuery):
    if not get_setting("crypto_address", ""): return await cb.answer("❌ Crypto configure nahi.", show_alert=True)
    await safe_edit(cb, f"🔑 <b>CRYPTO — Amount</b>\nCoin: {esc(get_setting('crypto_coin'))}", amount_kb("crypto")); await cb.answer()

async def _send_payment(target, method, text, kb_):
    """Payment message. If the admin uploaded a scanner for this method, it goes out as a photo with the details as caption."""
    qr = xget(f"qr_{method}", "")
    if qr:
        return await target.answer_photo(qr, caption=_premium_text(text), reply_markup=kb_, parse_mode=ParseMode.HTML)
    return await target.answer(_premium_text(text), reply_markup=kb_, parse_mode=ParseMode.HTML)

def _dep_text(amount, code, expires, method):
    if method == "crypto":
        return (f"🔑 <b>CRYPTO PAYMENT</b>\n{'─'*24}\nAmount: <b>₹{amount:.2f}</b>\n"
                f"Coin: <b>{esc(get_setting('crypto_coin'))}</b>\nAddress: <code>{esc(get_setting('crypto_address'))}</code>\n"
                f"Ref: <code>{code}</code>\nValid: {expires}")
    return (f"💳 <b>UPI PAYMENT</b>\n{'─'*24}\nAmount: <b>₹{amount:.2f}</b>\n"
            f"UPI: <code>{esc(cfg_upi())}</code>\nRef: <code>{code}</code>\nValid: {expires}")

@router.callback_query(F.data.startswith("amt_"))
async def cb_amount(cb: CallbackQuery, state: FSMContext):
    parts = cb.data.split("_", 2); method = parts[1]; raw = parts[2] if len(parts) > 2 else ""
    if raw == "custom":
        await state.set_state(Flow.waiting_custom_dep); await state.update_data(dep_method=method)
        min_d, max_d = deposit_limits()
        await safe_edit(cb, f"✏ <b>CUSTOM</b>\nMin: {_money(min_d)} Max: {_money(max_d)}\nNumber bhejo:",
                        _kb([("Cancel", "addfunds", "danger")])); return await cb.answer()
    try: amount = float(raw)
    except ValueError: return await cb.answer("Invalid", show_alert=True)
    if method == "stars":
        await cb.answer(); return await send_stars_invoice(cb.from_user.id, amount)
    code, expires = new_deposit(cb.from_user.id, amount, method)
    try: await cb.message.delete()
    except Exception: pass
    await _send_payment(cb.message, method, _dep_text(amount, code, expires, method), deposit_kb(code))
    await cb.answer()

@router.message(Flow.waiting_custom_dep)
async def custom_dep(msg: Message, state: FSMContext):
    try: amount = float((msg.text or "").strip())
    except ValueError: return await msg.answer("Sirf number.")
    min_d, max_d = deposit_limits()
    if not math.isfinite(amount) or amount < min_d or amount > max_d: return await msg.answer(f"{_money(min_d)} – {_money(max_d)}.")
    data = await state.get_data(); method = data.get("dep_method", "upi"); await state.clear()
    if method == "stars": return await send_stars_invoice(msg.from_user.id, amount)
    code, expires = new_deposit(msg.from_user.id, amount, method)
    await _send_payment(msg, method, _dep_text(amount, code, expires, method), deposit_kb(code))

@router.callback_query(F.data.startswith("verify_"))
async def cb_verify(cb: CallbackQuery):
    code = cb.data[len("verify_"):]
    with db() as c:
        dep = c.execute("SELECT * FROM deposits WHERE order_code=? AND user_id=?", (code, cb.from_user.id)).fetchone()
    if not dep: return await cb.answer("Order nahi mila", show_alert=True)
    if dep["status"] == "paid": return await cb.answer("✅ Credited", show_alert=True)
    if dep["status"] == "review": return await cb.answer("🔎 Review", show_alert=True)
    if dep["status"] == "rejected": return await cb.answer("❌ Rejected", show_alert=True)
    try: exp = datetime.strptime(dep["expires_at"], "%d-%m-%Y %H:%M:%S")
    except Exception: exp = datetime.now() + timedelta(hours=1)
    if datetime.now() > exp: return await cb.answer("⏰ Expired", show_alert=True)
    with db() as c:
        cur = c.execute("UPDATE deposits SET status='review' WHERE order_code=? AND status='pending'", (code,))
    if cur.rowcount == 0: return await cb.answer("Review", show_alert=True)
    notify_kb = _kb([("Confirm", f"adm:dok:{code}", "action"), ("Reject", f"adm:dno:{code}", "danger")])
    for aid in ADMIN_IDS: await send_safe(aid, f"💰 <b>DEPOSIT</b>\nOrder: <code>{code}</code>\nUser: <code>{dep['user_id']}</code>\nAmount: <b>{_money(dep['amount'])}</b>", notify_kb)
    await safe_edit(cb, "⏳ <b>Verify bhej diya!</b>", _kb([("Back", "wallet")])); await cb.answer()
    # ── browse ──
def _get_filter(uid, server):
    return _filters.get((uid, server), {"spam":"any","prem":False,"twofa":False,"email":False,"origin":"","sort":"asc"})
def _set_filter(uid, server, f): _filters[(uid, server)] = f
def _apply_filter(server, f):
    q = ["server=?", "sold=0", "session_data IS NOT NULL", "session_data<>''"]; p = [server]
    if f.get("spam") == "free": q.append("spam_block=0")
    elif f.get("spam") == "blocked": q.append("spam_block=1")
    if f.get("prem"): q.append("premium=1")
    if f.get("twofa"): q.append("twofa=1")
    if f.get("email"): q.append("email=1")
    if f.get("origin"): q.append("LOWER(origin)=LOWER(?)"); p.append(f["origin"])
    order = "ASC" if f.get("sort","asc") == "asc" else "DESC"
    return " AND ".join(q), p, order

@router.callback_query(F.data == "browse")
async def cb_browse(cb: CallbackQuery):
    bal = _money(user_balance(cb.from_user.id))
    await safe_edit(cb, f"🛍 <b>SHOP</b> | 💰 {bal}\n{'─'*26}\n\n🟢 Server 1 · Budget\n🔵 Server 2 · Premium\n\nServer select karo ⬇", server_kb())
    await cb.answer()

def _srv1_terms():
    return ("⚠ <b>SERVER 1 · TERMS</b>\n\n<b>Origin:</b> Phishing · Stealer · Resale\n\n"
            "<b>Risk:</b>\n• Log out\n• OTP issue\n• Freeze/ban\n\n<b>NO REFUND.</b>")

@router.callback_query(F.data.startswith("srv_"))
async def cb_server(cb: CallbackQuery):
    server = int(cb.data[4:])
    if server == 1 and not has_s1_ack(cb.from_user.id): await safe_edit(cb, _srv1_terms(), agree_kb("agree_1", "browse"))
    else: await show_countries(cb, server)
    await cb.answer()

@router.callback_query(F.data.startswith("agree_"))
async def cb_agree(cb: CallbackQuery):
    srv = int(cb.data[6:])
    if srv == 1: set_s1_ack(cb.from_user.id)
    await show_countries(cb, srv); await cb.answer()

async def show_countries(cb, server, page=0):
    uid = cb.from_user.id; f = _get_filter(uid, server)
    where, params, order = _apply_filter(server, f)
    with db() as c:
        rows = c.execute(f"SELECT country, dial, COUNT(*) as stock, MIN(price) as min_price FROM accounts WHERE {where} GROUP BY country, dial ORDER BY min_price {order}", params).fetchall()
    if not rows: return await safe_edit(cb, "😔 Stock nahi.", _kb([("Back", "browse")]))
    icon = "🟢" if server == 1 else "🔵"
    with db() as c: total_av = c.execute("SELECT COUNT(*) FROM accounts WHERE server=? AND sold=0", (server,)).fetchone()[0]
    text = f"{icon} <b>SERVER {server}</b> 💰 {_money(user_balance(uid))}\n{'─'*22}\n📦 Total available: <b>{total_av}</b>\nCountries: {len(rows)}"
    kbl = country_list_kb(server, rows, page)
    kbl.inline_keyboard.insert(-1, [xbtn("Filters", f"filters_{server}", "nav")])
    await safe_edit(cb, text, kbl)

@router.callback_query(F.data.startswith("cl_"))
async def cb_country_page(cb: CallbackQuery):
    _, server, page = cb.data.split("_"); await show_countries(cb, int(server), int(page)); await cb.answer()

@router.callback_query(F.data.startswith("filters_"))
async def cb_filters(cb: CallbackQuery):
    server = int(cb.data[8:]); f = _get_filter(cb.from_user.id, server)
    await safe_edit(cb, f"🎛 <b>FILTERS · S{server}</b>", filter_kb(server, f)); await cb.answer()

@router.callback_query(F.data.startswith("flt_"))
async def cb_filter_toggle(cb: CallbackQuery):
    parts = cb.data.split("_"); server = int(parts[1]); action = parts[2]
    uid = cb.from_user.id; f = _get_filter(uid, server).copy()
    if action == "spam": f["spam"] = {"any":"free","free":"blocked","blocked":"any"}.get(f.get("spam","any"),"any")
    elif action == "prem": f["prem"] = not f.get("prem")
    elif action == "twofa": f["twofa"] = not f.get("twofa")
    elif action == "email": f["email"] = not f.get("email")
    elif action == "origin":
        opts = ["","Phishing","Stealer","Resale","Manual"]; cur = f.get("origin",""); f["origin"] = opts[(opts.index(cur)+1) % len(opts)] if cur in opts else opts[1]
    elif action == "sort": f["sort"] = "desc" if f.get("sort") == "asc" else "asc"
    elif action == "reset": f = {"spam":"any","prem":False,"twofa":False,"email":False,"origin":"","sort":"asc"}
    elif action == "apply": _set_filter(uid, server, f); await show_countries(cb, server); return await cb.answer("✅")
    _set_filter(uid, server, f)
    await safe_edit(cb, f"🎛 <b>FILTERS · S{server}</b>", filter_kb(server, f)); await cb.answer()

@router.callback_query(F.data.startswith("cty_"))
async def cb_country(cb: CallbackQuery):
    _, server, dial = cb.data.split("_", 2); server = int(server)
    uid = cb.from_user.id; f = _get_filter(uid, server)
    where, params, order = _apply_filter(server, f)
    with db() as c:
        rows = c.execute(f"SELECT id, price FROM accounts WHERE {where} AND dial=? ORDER BY position ASC, price {order} LIMIT 20", params + [dial]).fetchall()
        total = c.execute(f"SELECT COUNT(*) FROM accounts WHERE {where} AND dial=?", params + [dial]).fetchone()[0]
    if not rows: return await cb.answer("❌ Out of stock", show_alert=True)
    info = _dial_info(dial)
    await safe_edit(cb, f"{info['emoji']} <b>{esc(info['name'])} {esc(dial)}</b>\n{'─'*22}\nStock: {total}\nFrom: {_money(rows[0]['price'])}", country_detail_kb(server, dial, rows))
    await cb.answer()

@router.callback_query(F.data.startswith("acc_"))
async def cb_account(cb: CallbackQuery):
    acc_id = int(cb.data[4:])
    with db() as c: a = c.execute("SELECT * FROM accounts WHERE id=? AND sold=0", (acc_id,)).fetchone()
    if not a: return await cb.answer("❌ Sold", show_alert=True)
    info = _dial_info(a["dial"]); flags = []
    if a["premium"]: flags.append("⭐ Premium")
    if a["twofa"]: flags.append("🔐 2FA")
    if a["email"]: flags.append("📧 Email")
    if a["spam_block"]: flags.append("🚫 SpamBlock")
    await safe_edit(cb, f"{info['emoji']} <b>ACCOUNT</b>\n{'─'*24}\nCountry: {esc(info['name'])} {esc(a['dial'])}\n"
                        f"Price: <b>{_money(a['price'])}</b>\nType: {esc(a['type'])}\nOrigin: {esc(a['origin'])}\n"
                        f"{'─'*24}\nFlags: {' '.join(flags) or '—'}\nChats: {a['chats']} · Groups: {a['groups']} · Admin: {a['admin_count']}",
                    account_kb(acc_id, a["price"], a["server"], a["dial"]))
    await cb.answer()

@router.callback_query(F.data.startswith("buy_"))
async def cb_buy(cb: CallbackQuery):
    acc_id = int(cb.data[4:]); uid = cb.from_user.id
    with db() as c: a = c.execute("SELECT price FROM accounts WHERE id=? AND sold=0", (acc_id,)).fetchone()
    if not a: return await cb.answer("❌ Sold", show_alert=True)
    price = discounted_price(uid, a["price"])
    if user_balance(uid) < price: await safe_edit(cb, "❗ <b>BALANCE KAM</b>\n\nUPI/Crypto se add.", low_balance_kb()); return await cb.answer()
    if not deduct_balance(uid, price): await safe_edit(cb, "❗ Balance error.", low_balance_kb()); return await cb.answer()
    acc = claim_account(acc_id, uid)
    if not acc: refund_balance(uid, price); return await cb.answer("❌ Sold", show_alert=True)
    order_code = gen_order_code(); twofa = acc["twofa_pass"] or ""
    info = _dial_info(acc["dial"])
    try:
        await _send_login_card(cb.message, uid, acc, order_code)
    except Exception as e:
        log.exception(f"delivery {acc_id}: {e}"); release_account(acc_id); refund_balance(uid, price); return await cb.answer("❌ Fail. Refund.", show_alert=True)
    with db() as c:
        c.execute("INSERT INTO orders(order_code,user_id,account_id,price,status,created_at) VALUES(?,?,?,?,?,?)", (order_code, uid, acc_id, price, "delivered", datetime.now().isoformat()))
    _credit_referrer(order_code, uid, price)
    consume_coupon(uid)
    asyncio.create_task(_post_sale(acc, order_code))
    spawn_otp_watcher(acc["id"], uid, acc["session_data"])
    await safe_edit(cb, f"✅ <b>Purchased!</b> Order: <code>{order_code}</code>", after_buy_kb()); await cb.answer("✅")

def _mask_phone(p):
    d = re.sub(r"\D", "", p or "")
    if len(d) <= 8: return "••••"
    return "+" + d[:6] + "x" * (len(d) - 8) + d[-2:]

def _login_kb(acc_id):
    return xkb([xbtn("📨 Login request bhejo", f"lg:req:{acc_id}", "action")],
               [xbtn("✅ Login ho gaya", f"lg:done:{acc_id}", "action")])

async def _send_login_card(target, uid, acc, order_code):
    """Buyer gets the number and the login steps. The session file is never sent."""
    info = _dial_info(acc["dial"])
    text = (f"✅ <b>ACCOUNT DELIVERED</b>\n{'─'*22}\n"
            f"Order: <code>{order_code}</code>\n"
            f"Country: {info['emoji']} {esc(info['name'])} {esc(acc['dial'])}\n"
            f"Number: <code>{esc(acc['phone'] or '—')}</code>\n"
            f"Price: {_money(acc['price'])}\n\n"
            "🔐 <b>LOGIN STEPS</b>\n"
            "1. Apne phone ya Telegram app mein is number se login karo\n"
            "2. Neeche 📨 <b>Login request bhejo</b> dabao\n"
            "3. OTP yahin aayega, wahi code login mein daalo\n"
            "4. 2FA maange to password bhi yahin milega\n"
            "5. Login ho jaye to ✅ <b>Login ho gaya</b> dabao")
    await target.answer(_premium_text(text), reply_markup=_login_kb(acc["id"]), parse_mode=ParseMode.HTML)

async def _auth_count(session_str):
    """Number of active sessions on the account, or None if it cannot be read."""
    client = None
    try:
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        from telethon.tl.functions.account import GetAuthorizationsRequest
        client = TelegramClient(StringSession(session_str), int(get_setting("api_id", "0")), get_setting("api_hash", ""))
        await client.connect()
        res = await client(GetAuthorizationsRequest())
        return len(res.authorizations)
    except Exception as e:
        log.warning("authorizations check failed: %s", e)
        return None
    finally:
        if client is not None:
            try: await client.disconnect()
            except Exception: pass

def _owned_account(uid, acc_id):
    with db() as c:
        return c.execute("SELECT id, phone, session_data FROM accounts WHERE id=? AND sold_to=?", (acc_id, uid)).fetchone()

@router.callback_query(F.data.startswith("lg:req:"))
async def cb_login_req(cb: CallbackQuery):
    acc_id = int(cb.data.split(":")[2]); uid = cb.from_user.id
    acc = _owned_account(uid, acc_id)
    if not acc: return await cb.answer("❌ Ye account aapka nahi hai.", show_alert=True)
    if xget(f"lgn:{acc_id}") == "done" or not acc["session_data"]:
        return await cb.answer("Ye account ab aapka hai, bot ka access band hai.", show_alert=True)
    xset(f"lgn:{acc_id}", "requested")
    if acc_id not in _otp_tasks or _otp_tasks[acc_id].done():
        spawn_otp_watcher(acc_id, uid, acc["session_data"])
    if xget(f"authbase:{acc_id}", "") == "":
        n = await _auth_count(acc["session_data"])
        if n is not None: xset(f"authbase:{acc_id}", str(n))
    await cb.answer("✅ Request bhej di")
    await cb.message.answer(_premium_text(
        f"📨 <b>Request bhej di</b> · <code>{esc(acc['phone'])}</code>\n\n"
        "Ab apne device par is number se login karo. OTP yahin aayega. Agar 2FA maange, to password bhi yahin milega."),
        parse_mode=ParseMode.HTML)

async def _bot_release_account(acc_id):
    """Buyer confirmed: stop watching, log the bot's session out, wipe it. The account becomes the buyer's alone."""
    t = _otp_tasks.pop(acc_id, None)
    if t and not t.done():
        t.cancel()
        await asyncio.sleep(2)   # let the watcher disconnect before logging out
    with db() as c: row = c.execute("SELECT session_data FROM accounts WHERE id=?", (acc_id,)).fetchone()
    sess = row["session_data"] if row else ""
    if sess:
        client = None
        try:
            from telethon import TelegramClient
            from telethon.sessions import StringSession
            client = TelegramClient(StringSession(sess), int(get_setting("api_id", "0")), get_setting("api_hash", ""))
            await client.connect()
            await client.log_out()
        except Exception as e:
            log.warning("bot logout for account %s failed: %s", acc_id, e)
        finally:
            if client is not None:
                try: await client.disconnect()
                except Exception: pass
    with db() as c:
        c.execute("UPDATE accounts SET session_data='' WHERE id=?", (acc_id,))
        c.execute("DELETE FROM otp_watchers WHERE account_id=?", (acc_id,))
    xset(f"lgn:{acc_id}", "done")

@router.callback_query(F.data.startswith(("lg:done:", "lg:yes:")))
async def cb_login_done(cb: CallbackQuery):
    acc_id = int(cb.data.split(":")[2]); uid = cb.from_user.id
    acc = _owned_account(uid, acc_id)
    if not acc: return await cb.answer("❌ Ye account aapka nahi hai.", show_alert=True)
    if xget(f"lgn:{acc_id}") == "done": return await cb.answer("Ye account ab aapka hai.", show_alert=True)
    await cb.answer()
    base = xget(f"authbase:{acc_id}", "")
    now = await _auth_count(acc["session_data"]) if acc["session_data"] else None
    if base and now is not None and now > int(base):
        check = "✅ Naya login device account par dikh raha hai."
    else:
        check = "⚠️ Abhi naya login device account par dikh nahi raha. Pakka login hua hai tabhi confirm karo."
    await safe_edit(cb,
        "⚠️ <b>Confirm karne ke baad</b>\n" + "─" * 22 + "\n"
        f"{check}\n\n"
        "• Bot is account se logout ho jayega\n"
        "• OTP aur kisi bhi tarah ka access band ho jayega\n"
        "• Account sirf aapka rahega\n\n"
        "Kya aapka login ho gaya hai?",
        xkb([xbtn("✅ Haan, confirm", f"lg:ok:{acc_id}", "action")],
            [xbtn("❌ Nahi hua, dobara", f"lg:no:{acc_id}", "danger")]))

@router.callback_query(F.data.startswith("lg:no:"))
async def cb_login_no(cb: CallbackQuery):
    acc_id = int(cb.data.split(":")[2])
    acc = _owned_account(cb.from_user.id, acc_id)
    if not acc or not acc["session_data"]: return await cb.answer("❌ Ye account aapka nahi hai.", show_alert=True)
    xset(f"authbase:{acc_id}", "")   # next request records a fresh baseline
    await cb.answer()
    await safe_edit(cb,
        "❌ <b>Koi baat nahi.</b>\n\nDobara login karo, phir 📨 <b>Login request bhejo</b> dabao. "
        "OTP aur 2FA yahin aayenge.", _login_kb(acc_id))

@router.callback_query(F.data.startswith("lg:cancel:"))
async def cb_login_cancel(cb: CallbackQuery):
    acc_id = int(cb.data.split(":")[2])
    if not _owned_account(cb.from_user.id, acc_id): return await cb.answer("❌", show_alert=True)
    await cb.answer()
    await safe_edit(cb, f"📨 Login ka kaam chal raha hai · <code>{esc(_owned_account(cb.from_user.id, acc_id)['phone'])}</code>\n\nLogin karne ke baad ✅ <b>Login ho gaya</b> dabao.", _login_kb(acc_id))

@router.callback_query(F.data.startswith("lg:ok:"))
async def cb_login_ok(cb: CallbackQuery):
    acc_id = int(cb.data.split(":")[2]); uid = cb.from_user.id
    acc = _owned_account(uid, acc_id)
    if not acc: return await cb.answer("❌ Ye account aapka nahi hai.", show_alert=True)
    await cb.answer("⏳ Bot logout ho raha hai...")
    await _bot_release_account(acc_id)
    await safe_edit(cb, f"✅ <b>Login confirm ho gaya.</b>\n\nAccount <code>{esc(acc['phone'])}</code> ab aapka hai. Bot ka access band ho chuka hai.\n\nKisi problem ke liye support se contact karo.", after_buy_kb())

async def _post_sale(acc, order_code):
    """Channel notification in the 'SALE CONFIRMED' style. Number is masked, Buy Now opens the bot."""
    if not cfg_sales_channel(): return
    info = _dial_info(acc["dial"])
    text = (f"<b>{esc(BOT_NAME)}</b>\n<i>Sales &amp; Updates</i>\n{'━' * 18}\n"
            f"✅ <b>SALE CONFIRMED · {esc(info['name'])}</b>\n\n"
            f"<pre>Buyer   Hidden\nOrder   #{order_code[-6:]}\nNumber  {_mask_phone(acc['phone'])}\n"
            f"Type    {esc(acc['type'] or 'Fresh')}\nPrice   {_money(acc['price'])}</pre>\n"
            "⚡ Instant auto-delivery • 🔒 Verified stock")
    kb = None
    if BOT_USERNAME:
        kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🛒 Buy Now", url=f"https://t.me/{BOT_USERNAME}?start=buy", style="success")]])
    photo = get_setting("sale_photo")
    try:
        if os.path.exists(photo): await bot.send_photo(cfg_sales_channel(), FSInputFile(photo), caption=_premium_text(text), parse_mode=ParseMode.HTML, reply_markup=kb)
        else: await bot.send_message(cfg_sales_channel(), _premium_text(text), parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception as e: log.error(f"sales post: {e}")

# ── bulk ──
@router.callback_query(F.data == "bulk")
async def cb_bulk(cb: CallbackQuery):
    await safe_edit(cb, "🎲 <b>BULK BUY</b>", bulk_pick_kb()); await cb.answer()
@router.callback_query(F.data.startswith("bulkpick_"))
async def cb_bulk_server(cb: CallbackQuery, state: FSMContext):
    await _bulk_gate(cb, state, int(cb.data[9:]), None)
@router.callback_query(F.data.startswith("bulkcty_"))
async def cb_bulk_country(cb: CallbackQuery, state: FSMContext):
    _, server, dial = cb.data.split("_", 2); await _bulk_gate(cb, state, int(server), dial)
async def _bulk_gate(cb, state, server, dial):
    if server == 1 and not has_s1_ack(cb.from_user.id): await safe_edit(cb, _srv1_terms(), agree_kb(f"bagree_1_{dial or '-'}", "bulk")); return await cb.answer()
    await _ask_bulk_qty(cb, state, server, dial)
@router.callback_query(F.data.startswith("bagree_"))
async def cb_bulk_agree(cb: CallbackQuery, state: FSMContext):
    _, server, key = cb.data.split("_", 2)
    if int(server) == 1: set_s1_ack(cb.from_user.id)
    await _ask_bulk_qty(cb, state, int(server), None if key == "-" else key)
async def _ask_bulk_qty(cb, state, server, dial):
    await state.set_state(Flow.waiting_bulk_qty); await state.update_data(server=server, dial=dial)
    await safe_edit(cb, f"📦 <b>BULK</b>\nServer {server} · Kitne? (1–{BULK_MAX}):", _kb([("Cancel", "bulk", "danger")])); await cb.answer()
@router.message(Flow.waiting_bulk_qty)
async def bulk_qty_msg(msg: Message, state: FSMContext):
    try:
        qty = int((msg.text or "").strip())
        if not 1 <= qty <= BULK_MAX: raise ValueError
    except ValueError: return await msg.answer(f"1–{BULK_MAX}.")
    data = await state.get_data(); await state.clear()
    server = data["server"]; dial = data.get("dial"); uid = msg.from_user.id
    with db() as c:
        q = "server=? AND sold=0 AND session_data IS NOT NULL AND session_data<>''"; p = [server]
        if dial: q += " AND dial=?"; p.append(dial)
        rows = c.execute(f"SELECT id, price FROM accounts WHERE {q} ORDER BY price ASC LIMIT ?", p + [qty]).fetchall()
    if len(rows) < qty: return await msg.answer(f"Sirf {len(rows)} available.")
    total = sum(r["price"] for r in rows)
    if user_balance(uid) < total: return await msg.answer(f"Balance kam. Total {_money(total)}", reply_markup=low_balance_kb())
    got = []; spent = 0.0
    for r in rows:
        if not deduct_balance(uid, r["price"]): break
        acc = claim_account(r["id"], uid)
        if not acc: refund_balance(uid, r["price"]); continue
        got.append(acc); spent += r["price"]
    if not got: return await msg.answer("Koi claim nahi.")
    try:
        await msg.answer(_premium_text(f"✅ <b>{len(got)} accounts bought</b>\nTotal {_money(spent)}\n\nHar account ka login card neeche hai."), parse_mode=ParseMode.HTML)
    except Exception:
        for a in got: release_account(a["id"])
        refund_balance(uid, spent); return await msg.answer("Delivery fail. Refund.")
    for a in got:
        code = gen_order_code()
        with db() as c: c.execute("INSERT INTO orders(order_code,user_id,account_id,price,status,created_at) VALUES(?,?,?,?,?,?)", (code, uid, a["id"], a["price"], "delivered", datetime.now().isoformat()))
        _credit_referrer(code, uid, a["price"])
        await _send_login_card(msg, uid, a, code)
        await _post_sale(a, code)
        spawn_otp_watcher(a["id"], uid, a["session_data"])

@router.callback_query(F.data == "search_country")
async def cb_search(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.waiting_country_srch)
    await safe_edit(cb, "🔍 <b>SEARCH</b>\nCountry / ISO / dial bhejo.", _kb([("Cancel", "browse", "danger")])); await cb.answer()
@router.message(Flow.waiting_country_srch)
async def search_country_msg(msg: Message, state: FSMContext):
    q = (msg.text or "").strip().upper().replace("+", ""); await state.clear()
    if not q: return await msg.answer("Empty.", reply_markup=main_menu_kb(msg.from_user.id))
    with db() as c:
        rows = c.execute("""SELECT server, country, dial, COUNT(*) as stock, MIN(price) as min_price FROM accounts
            WHERE sold=0 AND session_data IS NOT NULL AND session_data<>''
            AND (UPPER(country) LIKE ? OR dial LIKE ? OR dial LIKE ?) GROUP BY server, country, dial""",
            (f"%{q}%", f"%{q}%", f"+{q}%")).fetchall()
    if not rows: return await msg.answer(f"❌ No match.", reply_markup=main_menu_kb(msg.from_user.id))
    kbrows = [[(f"{_flag(r['dial'])} {r['country']} {r['dial']} · S{r['server']} · ₹{r['min_price']:.0f}", f"cty_{r['server']}_{r['dial']}")] for r in rows[:30]]
    kbrows.append([("🏠 Main Menu", "main")])
    await msg.answer(_premium_text(f"🔍 <b>{len(rows)} result(s)</b>"), reply_markup=_kb(*kbrows), parse_mode=ParseMode.HTML)

@router.callback_query(F.data == "myorders")
async def cb_myorders(cb: CallbackQuery):
    with db() as c:
        rows = c.execute("""SELECT o.order_code, o.price, o.created_at, o.status, a.country, a.dial FROM orders o
            JOIN accounts a ON a.id=o.account_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 15""", (cb.from_user.id,)).fetchall()
    if not rows: text = "📦 <b>MY ORDERS</b>\n\nEmpty."
    else:
        lines = [f"{_flag(r['dial'])} <code>{r['order_code']}</code> · {esc(r['country'])} · {_money(r['price'])} · {r['status']} · {r['created_at'][:16]}" for r in rows]
        text = "📦 <b>MY ORDERS</b>\n\n" + "\n".join(lines)
    await safe_edit(cb, text, _kb([("Back", "main")])); await cb.answer()

@router.message(Command("sales"))
async def cmd_sales(msg: Message):
    url = _sales_url()
    if not url: return await msg.answer("📢 Sales channel abhi set nahi hai.")
    await msg.answer(_premium_text("📢 <b>Sales Channel</b>\n\nNaye accounts ki sale yahin post hoti hai. Join karke update rehna."),
                     reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📢 Join Sales Channel", url=url, style="primary")]]),
                     parse_mode=ParseMode.HTML)

@router.callback_query(F.data == "terms")
async def cb_terms(cb: CallbackQuery):
    try: await cb.message.edit_text(_terms_text(), reply_markup=terms_kb(cb.from_user.id), parse_mode=ParseMode.HTML)
    except Exception:
        try: await cb.message.edit_text(_strip_premium(_terms_text()), reply_markup=terms_kb(cb.from_user.id), parse_mode=ParseMode.HTML)
        except Exception: pass
    await cb.answer()
    # ══════════════════════════════════════════════════════════
#   ADMIN ROUTER
# ══════════════════════════════════════════════════════════
adm = Router(name="admin")
adm.message.filter(lambda m: is_admin(m.from_user.id))
adm.callback_query.filter(lambda cb: is_admin(cb.from_user.id))

def stats_snap():
    today, week = _midnight(0), _midnight(6)
    with db() as c:
        def one(sql, *p): return c.execute(sql, p).fetchone()[0]
        return {
            "users": one("SELECT COUNT(*) FROM users"), "banned": one("SELECT COUNT(*) FROM users WHERE is_banned=1"),
            "new_today": one("SELECT COUNT(*) FROM users WHERE joined_at>=?", today),
            "stock1": one("SELECT COUNT(*) FROM accounts WHERE server=1 AND sold=0 AND session_data<>''"),
            "stock2": one("SELECT COUNT(*) FROM accounts WHERE server=2 AND sold=0 AND session_data<>''"),
            "sold": one("SELECT COUNT(*) FROM accounts WHERE sold=1"),
            "rev_today": one("SELECT COALESCE(SUM(price),0) FROM orders WHERE status='delivered' AND created_at>=?", today),
            "rev_week": one("SELECT COALESCE(SUM(price),0) FROM orders WHERE status='delivered' AND created_at>=?", week),
            "rev_total": one("SELECT COALESCE(SUM(price),0) FROM orders WHERE status='delivered'"),
            "orders_today": one("SELECT COUNT(*) FROM orders WHERE status='delivered' AND created_at>=?", today),
            "dep_today": one("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE status='paid' AND created_at>=?", today),
            "dep_pending": one("SELECT COUNT(*) FROM deposits WHERE status IN ('pending','review')"),
            "admins": one("SELECT COUNT(*) FROM admins"),
        }

def dashboard_text():
    s = stats_snap()
    api_ok = "✅" if get_setting("api_id") and get_setting("api_hash") else "❌"
    c = BTN_COLOURS
    btns = f"action={_STYLE_NAMES[c['action']]} · nav={_STYLE_NAMES[c['nav']]} · danger={_STYLE_NAMES[c['danger']]}"
    return (f"⚡ <b>ADMIN — {BOT_NAME}</b>\n<i>{datetime.now():%d %b %Y · %H:%M}</i>\n{'─'*26}\n"
            f"<b>Revenue</b> today {_money(s['rev_today'])} · 7d {_money(s['rev_week'])}\n"
            f"Total {_money(s['rev_total'])} · Orders today: {s['orders_today']}\n"
            f"Deposits today: {_money(s['dep_today'])}\n{'─'*26}\n"
            f"<b>Stock</b> 🟢S1: {s['stock1']} · 🔵S2: {s['stock2']} · sold: {s['sold']}\n{'─'*26}\n"
            f"<b>Users</b> {s['users']} · +{s['new_today']} today · {s['banned']} banned\n"
            f"<b>Admins</b>: {s['admins']} | <b>Pending</b>: {s['dep_pending']}\n"
            f"<b>Telethon</b>: {api_ok}\n<b>Buttons</b>: {btns}")

def adm_home_kb(uid):
    full = has_perm(uid, "full"); dep = has_perm(uid, "deposits"); stock = has_perm(uid, "stock")
    emoji = has_perm(uid, "emoji"); coup = has_perm(uid, "coupons"); sett = has_perm(uid, "settings"); tools = can_tools(uid)
    def g(cond, label, cb, kind="nav"): return xbtn(label, cb, kind) if cond else xbtn(label, "adm:noperm", "danger")
    return xkb(
        [xbtn("Dashboard", "adm:stats", "nav")],
        [xbtn("Find User", "adm:find_user", "nav"), xbtn("Find Order", "adm:find_order", "nav")],
        [xbtn("Broadcast", "adm:bcast", "action"), xbtn("Export CSV", "adm:export", "action")],
        [g(full, "Add Balance", "adm:addbal", "action"), g(full, "Cut Balance", "adm:cutbal", "action")],
        [g(coup, "Coupons", "xadm:coupons", "nav")],
        [g(stock, "Stock", "adm:stock", "nav"), g(stock, "Add Account", "adm:ac_start", "action"), g(stock, "Import TXT", "adm:import", "action")],
        [g(stock, "Telethon Login", "adm:tlogin", "action"), g(emoji, "Emoji IDs", "xadm:emoji", "nav"), xbtn("Button Colour", "adm:btncolour", "nav")],
        [g(sett, "Settings", "adm:settings", "nav"), xbtn("API Config", "adm:apiconfig", "nav"), xbtn("System", "adm:system", "nav")],
        [g(sett, f"📱 Share Contact: {'ON' if get_setting('verif_contact', '1') == '1' else 'OFF'}", "xadm:sharecontact", "action")],
        [g(sett, f"✨ Welcome Spoiler: {'ON' if xget('welcome_spoiler', '1') == '1' else 'OFF'}", "xadm:wspoil_home", "nav")],
        [g(stock, "✏ Edit Product", "xadm:pe:find", "action"), g(stock, "📍 Product Position", "xadm:pe:posfind", "action")],
        [g(sett, "💳 UPI QR ✏", "xadm:qr:upi", "action"), g(sett, "🔑 Crypto QR ✏", "xadm:qr:crypto", "action")],
        [g(sett, "🎨 Button Colours", "xadm:bc:adm:0", "nav")],
        [g(sett, "Maintenance", "xadm:mtoggle:t", "action"), g(tools, "Tools", "xadm:tools", "nav")],
        [g(full, "Add Admin", "adm:addadmin", "action"), g(full, "Permissions", "xadm:admins", "nav")],
        [xbtn("Back to Bot", "main", "nav")])

@adm.callback_query(F.data == "adm:noperm")
async def adm_noperm(cb: CallbackQuery): await cb.answer("❌ Permission nahi", show_alert=True)

@adm.message(Command("admin"))
async def cmd_admin(msg: Message, state: FSMContext):
    await state.clear()
    await msg.answer(_premium_text(dashboard_text()), reply_markup=adm_home_kb(msg.from_user.id), parse_mode=ParseMode.HTML)

@adm.callback_query(F.data == "adm:home")
async def adm_home_cb(cb: CallbackQuery, state: FSMContext):
    await state.clear(); await safe_edit(cb, dashboard_text(), adm_home_kb(cb.from_user.id)); await cb.answer()

@adm.callback_query(F.data == "adm:stats")
async def adm_stats_cb(cb: CallbackQuery, state: FSMContext):
    await state.clear(); await safe_edit(cb, dashboard_text(), adm_home_kb(cb.from_user.id)); await cb.answer()

@adm.callback_query(F.data == "xadm:sharecontact")
async def ex_share_contact(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    new = "0" if get_setting("verif_contact", "1") == "1" else "1"
    set_setting("verif_contact", new)
    log_admin(cb.from_user.id, f"share contact={new}")
    await state.clear()
    await safe_edit(cb, dashboard_text(), adm_home_kb(cb.from_user.id))
    await cb.answer(f"Share Contact {'ON' if new == '1' else 'OFF'}")

@adm.message(Command("cancel"))
async def cmd_cancel(msg: Message, state: FSMContext):
    await state.clear(); await msg.answer("✖ Cancelled.", reply_markup=adm_home_kb(msg.from_user.id))

# ── button colour panel ──
def btncolour_kb():
    rows = []
    for kind, label in (("action", "🟢 Action"), ("nav", "🔵 Nav"), ("danger", "🔴 Danger")):
        cur = BTN_COLOURS[kind]
        rows.append([xbtn(f"{label} → {_STYLE_NAMES[cur]}", "adm:btncolour:noop", "nav")])
        rows.append([xbtn(f"{'✅ ' if cur == s else ''}{_STYLE_NAMES[s]}", f"adm:btncolour:{kind}:{s}", s) for s in _STYLE_KEYS])
    rows.append([xbtn("Preview", "adm:btncolour:preview", "action")])
    rows.append([xbtn("Panel", "adm:home", "nav")])
    return xkb(*rows)
@adm.callback_query(F.data == "adm:btncolour")
async def adm_btncolour(cb: CallbackQuery):
    await safe_edit(cb, "🎨 <b>BUTTON COLOUR — LIVE</b>\nSolid style. Tap to change.", btncolour_kb()); await cb.answer()
@adm.callback_query(F.data.startswith("adm:btncolour:"))
async def adm_btncolour_set(cb: CallbackQuery):
    parts = cb.data.split(":")
    if len(parts) == 3 and parts[2] == "noop": return await cb.answer()
    if len(parts) == 3 and parts[2] == "preview":
        kb = _kb([("Sample Action", "noop", "action")], [("Sample Nav", "noop", "nav")], [("Sample Danger", "noop", "danger")], [("Back", "adm:btncolour", "nav")])
        await safe_edit(cb, "👁 <b>PREVIEW</b>\n" + "\n".join(f"{k} = {_STYLE_NAMES[BTN_COLOURS[k]]}" for k in _STYLE_KEYS), kb); return await cb.answer()
    if len(parts) != 4: return await cb.answer("Bad data", show_alert=True)
    _, _, kind, style = parts
    if kind not in BTN_COLOURS or style not in _STYLE_KEYS: return await cb.answer("❌", show_alert=True)
    set_setting(f"btn_{kind}", style); _reload_btn_colours()
    log_admin(cb.from_user.id, f"btn colour {kind}={style}")
    # Edit the panel directly and answer the callback ONCE (a second cb.answer raised and swallowed the toast).
    await safe_edit(cb, "🎨 <b>BUTTON COLOUR — LIVE</b>\nSolid style. Tap to change.", btncolour_kb())
    await cb.answer(f"✅ {kind} → {_STYLE_NAMES[style]}")
@adm.callback_query(F.data == "noop")
async def adm_noop(cb: CallbackQuery): await cb.answer()

# ── emoji panel ──
# ══════════════════════════════════════════════════════════
#   PREMIUM EMOJI ADMIN (hh.py style: list, detail, add/replace/remove/off, ID lookup, pack → IDs)
# ══════════════════════════════════════════════════════════
EID_CHUNK = 200       # Telegram: max 200 IDs per getCustomEmojiStickers call
EID_PER_MSG = 25
EMOJI_PER_PAGE = 12

def _all_emoji():
    return list(dict.fromkeys([_norm_e(k) for k in list(PREMIUM_EMOJI_IDS) + list(EMOJI_OVERRIDE)]))

def _eff_ids(e):
    """(ids, source) where source is custom / default / off / none."""
    base = _norm_e(e)
    for k in (base, base + "\ufe0f"):
        if k in EMOJI_OVERRIDE:
            v = EMOJI_OVERRIDE[k]
            return (list(v), "custom") if v else ([], "off")
    for k in (base, base + "\ufe0f", e):
        if k in PREMIUM_EMOJI_IDS:
            return list(PREMIUM_EMOJI_IDS[k]), "default"
    return [], "none"

def _save_emoji_override():
    set_setting("emoji_override", json.dumps(EMOJI_OVERRIDE)); _reload_emoji()

def _emoji_list_view(page=0):
    allk = _all_emoji()
    pages = max(1, (len(allk) + EMOJI_PER_PAGE - 1) // EMOJI_PER_PAGE)
    page = min(max(page, 0), pages - 1)
    chunk = allk[page * EMOJI_PER_PAGE:(page + 1) * EMOJI_PER_PAGE]
    lines = [f"😀 <b>EMOJI IDs</b> ({page + 1}/{pages})", "Normal emoji → Premium ID", ""]
    for x in chunk:
        ids, _src = _eff_ids(x)
        idtxt = ", ".join(f"<code>{i}</code>" for i in ids) if ids else "no ID"
        lines.append(f"{esc(x)} → {idtxt}")
    lines.append("\nEmoji tap karo: view, add, change ya remove.")
    rows = [[xbtn(x, f"xadm:emjv:{x}", "nav") for x in chunk[i:i + 3]] for i in range(0, len(chunk), 3)]
    nav = []
    if page > 0: nav.append(xbtn("◀ Prev", f"xadm:emoji:{page - 1}", "nav"))
    if page < pages - 1: nav.append(xbtn("Next ▶", f"xadm:emoji:{page + 1}", "nav"))
    if nav: rows.append(nav)
    rows.append([xbtn("➕ Other emoji", "xadm:emj", "action")])
    rows.append([xbtn("🔎 ID lookup", "xadm:eidlk", "nav"), xbtn("🔗 Link → IDs", "xadm:elink", "nav")])
    rows.append([xbtn("⬅ Admin panel", "adm:home", "nav")])
    return "\n".join(lines), xkb(*rows)

def _emoji_detail_view(e):
    key = _norm_e(e)
    ids, src = _eff_ids(e)
    names = {"custom": "custom (admin)", "default": "default", "off": "premium off", "none": "no premium ID"}
    state = "⭐ premium on" if ids else "normal only (not premium)"
    idtxt = ", ".join(f"<code>{i}</code>" for i in ids) if ids else "—"
    try:
        uses = open(os.path.abspath(__file__), encoding="utf-8").read().count(key)
    except Exception:
        uses = "?"
    sharers = [x for x in _all_emoji() if x != key and set(_eff_ids(x)[0]) & set(ids)] if ids else []
    shared = ("\nSame ID also used by: " + " ".join(f"<code>{esc(x)}</code>" for x in sharers)) if sharers else ""
    text = (f"<b>Emoji ID</b>\nNormal emoji: <code>{esc(key)}</code>\n"
            f"Source: <b>{names[src]}</b>\nStatus: <b>{state}</b>\n"
            f"IDs: {idtxt}\nUsed in code: <b>{uses}</b> place(s){shared}")
    rows = [
        [xbtn("➕ Add ID", f"xadm:emjadd:{key}", "action"), xbtn("✏ Replace", f"xadm:emjset:{key}", "action")],
        [xbtn("🗑 Remove custom", f"xadm:emjdel:{key}", "danger"), xbtn("🚫 Turn off", f"xadm:emjoff:{key}", "danger")],
        [xbtn("🔄 Refresh", f"xadm:emjv:{key}", "nav"), xbtn("🔙 Emoji list", "xadm:emoji", "nav")],
        [xbtn("⬅ Admin panel", "adm:home", "nav")],
    ]
    return text, xkb(*rows)

@adm.callback_query(F.data.startswith("xadm:emoji"))
async def adm_emoji_list(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "emoji"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":")
    page = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
    text, kb_ = _emoji_list_view(page); await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data.startswith("xadm:emjv:"))
async def adm_emoji_view(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "emoji"): return await cb.answer("❌", show_alert=True)
    e = cb.data.split(":", 2)[2]
    text, kb_ = _emoji_detail_view(e); await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data.startswith(("xadm:emjadd:", "xadm:emjset:")))
async def adm_emoji_set_start(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "emoji"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":", 2)
    mode = "add" if parts[1] == "emjadd" else "set"; e = _norm_e(parts[2])
    await state.set_state(Flow.emoji_id_wait); await state.update_data(edit_emoji=e, mode=mode)
    cur = ", ".join(_eff_ids(e)[0]) or "None"
    await safe_edit(cb, f"{esc(e)} → custom-emoji ID(s) bhejo, comma separated.\nCurrent: <code>{esc(cur)}</code>\n"
                        "Ya <code>none</code> (premium off) / <code>reset</code> (default).",
                    xkb([xbtn("Cancel", f"xadm:emjv:{e}", "danger")])); await cb.answer()

@adm.callback_query(F.data.startswith(("xadm:emjdel:", "xadm:emjoff:")))
async def adm_emoji_del_off(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "emoji"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":", 2)
    key = _norm_e(parts[2])
    if parts[1] == "emjdel": EMOJI_OVERRIDE.pop(key, None)
    else: EMOJI_OVERRIDE[key] = []
    _save_emoji_override(); log_admin(cb.from_user.id, f"emoji {parts[1]} {key}")
    text, kb_ = _emoji_detail_view(key); await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data == "xadm:emj")
async def adm_emoji_other(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "emoji"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.emoji_key_wait)
    await safe_edit(cb,
        "➕ <b>OTHER EMOJI</b>\n"
        f"{'─'*22}\n"
        "Jis emoji ka premium ID add, badalna ya hatana hai, wo emoji bhejo.\n\n"
        "Sirf ek emoji bhejo, jaise 👑 ya ➖.\n\n"
        "Bot us emoji ki detail khol dega, jahan se ID add, replace, remove ya off kar sakte ho.\n\n"
        "<i>Wapas list par jaane ke liye ⬅ Back dabao.</i>",
        xkb([xbtn("⬅ Back", "xadm:emoji", "nav")]))
    await cb.answer()

@adm.message(Flow.emoji_key_wait)
async def adm_emoji_key_msg(msg: Message, state: FSMContext):
    if not has_perm(msg.from_user.id, "emoji"): await state.clear(); return
    txt = (msg.text or "").strip()
    if not txt:
        return await msg.answer("Ek emoji bhejo, ya ⬅ Back se list par jao.",
                                reply_markup=xkb([xbtn("⬅ Back", "xadm:emoji", "nav")]))
    key = _norm_e(txt.split()[0]); await state.clear()
    text, kb_ = _emoji_detail_view(key)
    await msg.answer(_premium_text(text), reply_markup=kb_, parse_mode=ParseMode.HTML)

@adm.message(Flow.emoji_id_wait)
async def adm_emj_save(msg: Message, state: FSMContext):
    data = await state.get_data(); key = data.get("edit_emoji")
    if not key: await state.clear(); return
    txt = (msg.text or "").strip(); low = txt.lower()
    if low == "reset":
        EMOJI_OVERRIDE.pop(key, None); res = "default pe reset"
    elif low == "none":
        EMOJI_OVERRIDE[key] = []; res = "premium off"
    else:
        ids = re.findall(r"\d{5,25}", txt)
        if not ids: return await msg.answer("Valid ID nahi mili. Dubara bhejo ya /cancel.")
        if data.get("mode") == "add":
            cur = list(_eff_ids(key)[0]); ids = cur + [i for i in ids if i not in cur]
        EMOJI_OVERRIDE[key] = ids; res = f"{len(ids)} ID(s) saved"
    _save_emoji_override(); log_admin(msg.from_user.id, f"emoji set {key}")
    await state.clear()
    await msg.answer(f"✅ {esc(key)}: {res}", parse_mode=ParseMode.HTML,
                     reply_markup=xkb([xbtn("🔙 Emoji detail", f"xadm:emjv:{key}", "nav"), xbtn("⬅ Admin panel", "adm:home", "nav")]))

def _extract_emoji_ids(msg):
    ids = [e.custom_emoji_id for e in (msg.entities or []) if e.type == "custom_emoji"]
    ids += re.findall(r"\d{10,25}", msg.text or "")
    out = []
    for i in ids:
        if i not in out: out.append(i)
    return out

@adm.callback_query(F.data == "xadm:eidlk")
async def adm_eid_lookup_start(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "emoji"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.eid_lookup_wait)
    await safe_edit(cb, "🔎 <b>Emoji ID lookup</b>\n\nEmoji IDs bhejo (space, comma ya new line se alag), "
                        "ya premium emoji wala message bhejo/forward karo. /cancel se band.",
                    xkb([xbtn("Cancel", "xadm:emoji", "danger")])); await cb.answer()

@adm.message(Flow.eid_lookup_wait)
async def adm_eid_lookup_msg(msg: Message, state: FSMContext):
    ids = _extract_emoji_ids(msg)
    if not ids:
        return await msg.answer("Emoji ID bhejo, ya premium emoji wala message. /cancel se band karo.")
    found = {}
    for i in range(0, len(ids), EID_CHUNK):
        try:
            stickers = await msg.bot.get_custom_emoji_stickers(custom_emoji_ids=ids[i:i + EID_CHUNK])
        except Exception as ex:
            return await msg.answer(f"❌ Lookup failed: {esc(str(ex))}\nIDs check karke dobara bhejo, ya /cancel.")
        for s in stickers: found[s.custom_emoji_id] = s.emoji or "❔"
    rows = []
    for pid in ids:
        if pid in found:
            rows.append(f'<tg-emoji emoji-id="{pid}">{esc(found[pid])}</tg-emoji>  <code>{pid}</code>')
        else:
            rows.append(f"❌ <code>{pid}</code> not found")
    await msg.answer(f"🔎 <b>{len(found)}/{len(ids)}</b> found. ID par tap karke copy karo.", parse_mode=ParseMode.HTML)
    for i in range(0, len(rows), EID_PER_MSG):
        await msg.answer("\n".join(rows[i:i + EID_PER_MSG]), parse_mode=ParseMode.HTML)

def _pack_name_from(text):
    m = re.search(r"(?:t\.me|telegram\.me)/addemoji/([A-Za-z0-9_]+)", text)
    if m: return m.group(1)
    t = text.strip()
    return t if re.fullmatch(r"[A-Za-z0-9_]{3,64}", t) else None

@adm.callback_query(F.data == "xadm:elink")
async def adm_eid_link_start(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "emoji"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.eid_link_wait)
    await safe_edit(cb, "🔗 <b>Link → IDs</b>\n\nEmoji pack ka link bhejo (https://t.me/addemoji/NAME). "
                        "Main pack ke saare emoji aur IDs dunga. /cancel se band.",
                    xkb([xbtn("Cancel", "xadm:emoji", "danger")])); await cb.answer()

@adm.message(Flow.eid_link_wait)
async def adm_eid_link_msg(msg: Message, state: FSMContext):
    name = _pack_name_from(msg.text or "")
    if not name:
        return await msg.answer("Emoji pack ka link bhejo, jaise https://t.me/addemoji/NAME. /cancel se band karo.")
    try:
        sset = await msg.bot.get_sticker_set(name)
    except Exception:
        return await msg.answer(f"❌ Pack nahi mila: {esc(name)}\nLink check karo (pack public hona chahiye), ya /cancel.")
    stickers = [s for s in sset.stickers if s.custom_emoji_id]
    if not stickers:
        return await msg.answer("❌ Ye pack custom emoji wala nahi hai.")
    rows = [f'<tg-emoji emoji-id="{s.custom_emoji_id}">{esc(s.emoji or "❔")}</tg-emoji>  <code>{s.custom_emoji_id}</code>'
            for s in stickers]
    await msg.answer(f"📦 <b>{esc(sset.title or name)}</b>: {len(rows)} emoji. ID par tap karke copy karo.",
                     parse_mode=ParseMode.HTML)
    for i in range(0, len(rows), EID_PER_MSG):
        await msg.answer("\n".join(rows[i:i + EID_PER_MSG]), parse_mode=ParseMode.HTML)
 # ── broadcast ──
@adm.callback_query(F.data == "adm:bcast")
async def adm_bcast(cb: CallbackQuery, state: FSMContext):
    if not (has_perm(cb.from_user.id, "full") or has_perm(cb.from_user.id, "deposits")): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.broadcast_wait)
    await safe_edit(cb, "📢 <b>BROADCAST</b>\n\nMessage bhejo.\n/cancel se band.", _kb([("Cancel", "adm:home", "danger")])); await cb.answer()
@adm.message(Flow.broadcast_wait)
async def adm_do_broadcast(msg: Message, state: FSMContext):
    await state.clear()
    with db() as c: users = [r["user_id"] for r in c.execute("SELECT user_id FROM users WHERE is_banned=0").fetchall()]
    ok = fail = 0
    for uid in users:
        for _ in range(3):
            try: await bot.copy_message(chat_id=uid, from_chat_id=msg.chat.id, message_id=msg.message_id); ok += 1; break
            except TelegramRetryAfter as e: await asyncio.sleep(e.retry_after + 1)
            except Exception: fail += 1; break
        await asyncio.sleep(0.05)
    await msg.answer(_premium_text(f"📣 <b>Done!</b>\n✅ {ok}\n❌ {fail}"), reply_markup=adm_home_kb(msg.from_user.id), parse_mode=ParseMode.HTML)
    log_admin(msg.from_user.id, f"bcast ok={ok} fail={fail}")

# ── deposits ──
def deposits_view():
    with db() as c:
        rows = c.execute("SELECT order_code,user_id,amount,status,method FROM deposits WHERE status IN ('pending','review') ORDER BY id DESC LIMIT 10").fetchall()
    if not rows: return "💰 <b>DEPOSITS</b>\n\nNone.", _kb([("Back", "adm:home")])
    lines, kbrows = [], []
    for r in rows:
        m = "💳" if r["method"] == "upi" else "🔑"
        lines.append(f"{m} <code>{esc(r['order_code'])}</code> · <code>{r['user_id']}</code> · {_money(r['amount'])} · {r['status']}")
        kbrows.append([("✅ Confirm", f"adm:dok:{r['order_code']}", "action"), ("Reject", f"adm:dno:{r['order_code']}", "danger")])
    kbrows.append([("Refresh", "adm:deps"), ("Back", "adm:home")])
    return "💰 <b>PENDING DEPOSITS</b>\n\n" + "\n".join(lines), _kb(*kbrows)
@adm.callback_query(F.data == "adm:deps")
async def adm_deps(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if not has_perm(cb.from_user.id, "deposits"): return await cb.answer("❌", show_alert=True)
    text, kb_ = deposits_view(); await safe_edit(cb, text, kb_); await cb.answer()
@adm.callback_query(F.data.startswith("adm:dok:"))
async def adm_dep_ok(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "deposits"): return await cb.answer("❌", show_alert=True)
    code = cb.data.split(":", 2)[2]; dep = confirm_deposit(code)
    if not dep: return await cb.answer("Already", show_alert=True)
    await send_safe(dep["user_id"], f"✅ <b>{_money(dep['amount'])} credited!</b>")
    log_admin(cb.from_user.id, f"dep ok {code}")
    text, kb_ = deposits_view(); await safe_edit(cb, text, kb_); await cb.answer(f"✅ {_money(dep['amount'])}")
@adm.callback_query(F.data.startswith("adm:dno:"))
async def adm_dep_no(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "deposits"): return await cb.answer("❌", show_alert=True)
    code = cb.data.split(":", 2)[2]; dep = reject_deposit(code)
    if not dep: return await cb.answer("Already", show_alert=True)
    await send_safe(dep["user_id"], f"❌ Deposit <code>{code}</code> rejected.")
    log_admin(cb.from_user.id, f"dep rej {code}")
    text, kb_ = deposits_view(); await safe_edit(cb, text, kb_); await cb.answer("Rejected")

# ══════════════════════════════════════════════════════════
#   TELEGRAM STARS (⭐) WALLET TOP-UP
# ══════════════════════════════════════════════════════════
def _stars_rate():
    try: rate = float(get_setting("stars_rate", "1") or 1)
    except ValueError: rate = 1.0
    return rate if rate > 0 else 1.0

def stars_for(amount):
    return max(1, math.ceil(amount / _stars_rate()))

def _parse_stars_payload(payload):
    parts = (payload or "").split(":")
    if len(parts) != 3 or parts[0] != "sd" or not parts[1].isdigit() or not parts[2].isdigit():
        return None
    return int(parts[1]), int(parts[2]) / 100

def _is_payment_update(event):
    if getattr(event, "pre_checkout_query", None) is not None: return True
    if getattr(event, "successful_payment", None) is not None: return True
    m = getattr(event, "message", None)
    return m is not None and getattr(m, "successful_payment", None) is not None

async def send_stars_invoice(uid, amount):
    stars = stars_for(amount)
    payload = f"sd:{uid}:{int(round(amount * 100))}"
    await bot.send_invoice(chat_id=uid, title=f"Wallet top-up {_money(amount)}",
                           description=f"{_money(amount)} aapke wallet mein add hoga.",
                           payload=payload, provider_token="", currency="XTR",
                           prices=[LabeledPrice(label=_money(amount), amount=stars)])

@router.callback_query(F.data == "dep_stars")
async def cb_dep_stars(cb: CallbackQuery):
    await safe_edit(cb, f"⭐ <b>STARS — Amount</b>\n₹{_stars_rate():g} = ⭐1", amount_kb("stars")); await cb.answer()

@router.pre_checkout_query()
async def stars_precheckout(q: PreCheckoutQuery):
    p = _parse_stars_payload(q.invoice_payload)
    min_d, max_d = deposit_limits()
    ok = bool(p) and p[0] == q.from_user.id and min_d <= p[1] <= max_d and not is_banned(q.from_user.id)
    await q.answer(ok=ok, error_message=None if ok else "Abhi ye payment allowed nahi hai. /start karke dobara try karo.")

@router.message(F.successful_payment)
async def stars_paid(msg: Message):
    sp = msg.successful_payment; uid = msg.from_user.id
    p = _parse_stars_payload(sp.invoice_payload)
    if not p or p[0] != uid:
        for aid in ADMIN_IDS:
            try: await bot.send_message(aid, f"⚠️ Stars payment payload invalid · user {uid} · {sp.total_amount} ⭐ · charge {sp.telegram_payment_charge_id}")
            except Exception: pass
        return
    amount = p[1]; now = datetime.now().isoformat()
    with db() as c:
        cur = c.execute("INSERT OR IGNORE INTO stars_payments(charge_id,user_id,amount,stars,ts) VALUES(?,?,?,?,?)",
                        (sp.telegram_payment_charge_id, uid, amount, sp.total_amount, now))
        if cur.rowcount != 1: return      # duplicate delivery: already credited
        c.execute("UPDATE users SET balance=balance+?, total_deposited=total_deposited+? WHERE user_id=?",
                  (amount, amount, uid))
        c.execute("INSERT OR IGNORE INTO deposits(order_code,user_id,amount,method,status,created_at,expires_at) "
                  "VALUES(?,?,?,?,?,?,?)", (f"stars_{sp.telegram_payment_charge_id}", uid, amount, "stars", "paid", now, now))
    await msg.answer(f"✅ {_money(amount)} wallet mein add ho gaya! (⭐{sp.total_amount})")
    for aid in ADMIN_IDS:
        try: await bot.send_message(aid, f"💫 Stars top-up: {uid} · {_money(amount)} · ⭐{sp.total_amount}")
        except Exception: pass

# ── users ──
def _user_card_text(u, orders, banned):
    return (f"👤 <b>{esc(u['name'] or '—')}</b>\n{'─'*22}\nID: <code>{u['user_id']}</code>\nUsername: @{esc(u['username'] or '—')}\nJoined: {(u['joined_at'] or '')[:10]}\n{'─'*22}\n"
            f"💰 Balance: {_money(u['balance'])}\n📥 Deposited: {_money(u['total_deposited'])}\n💸 Spent: {_money(u['total_spent'])}\n📦 Orders: {orders}\n👥 Referrals: {u['referrals']}\n🚫 Banned: {'YES' if banned else 'no'}")
def _user_card_kb(uid, banned):
    return _kb([("Add Bal", f"adm:uaddbal:{uid}", "action"), ("Cut Bal", f"adm:ucutbal:{uid}", "danger"),
                ("Unban" if banned else "Ban", f"adm:uban:{uid}", "nav" if banned else "danger")],
               [("Tx Log", f"adm:utx:{uid}", "nav"), ("Back", "adm:users", "nav")])
def user_card(uid):
    with db() as c:
        u = c.execute("SELECT * FROM users WHERE user_id=?", (uid,)).fetchone()
        if not u: return None
        orders = c.execute("SELECT COUNT(*) FROM orders WHERE user_id=? AND status='delivered'", (uid,)).fetchone()[0]
    return _user_card_text(u, orders, is_banned(uid)), _user_card_kb(uid, is_banned(uid))
USERS_PER_PAGE = 10

def _users_list_view(page=0, banned_only=False):
    where = "WHERE is_banned=1" if banned_only else ""
    with db() as c:
        total = c.execute(f"SELECT COUNT(*) FROM users {where}").fetchone()[0]
        pages = max(1, (total + USERS_PER_PAGE - 1) // USERS_PER_PAGE)
        page = min(max(page, 0), pages - 1)
        rows = c.execute(f"SELECT user_id,name,balance,is_banned FROM users {where} "
                         f"ORDER BY rowid DESC LIMIT ? OFFSET ?", (USERS_PER_PAGE, page * USERS_PER_PAGE)).fetchall()
    base = "adm:banned" if banned_only else "adm:users"
    title = "🚫 <b>BANNED USERS</b>" if banned_only else "👥 <b>USERS</b>"
    text = f"{title} · {total} total · page {page + 1}/{pages}"
    rows_kb = [[xbtn(f"{'🚫 ' if r['is_banned'] else ''}{(r['name'] or '—')[:22]} · {_money(r['balance'])}",
                     f"adm:user:{r['user_id']}", "nav")] for r in rows]
    nav = []
    if page > 0: nav.append(xbtn("◀ Prev", f"{base}:{page - 1}", "nav"))
    if page < pages - 1: nav.append(xbtn("Next ▶", f"{base}:{page + 1}", "nav"))
    if nav: rows_kb.append(nav)
    rows_kb.append([xbtn("🔎 Find", "adm:find_user", "nav"),
                    xbtn("🚫 Banned" if not banned_only else "👥 All users",
                         "adm:banned:0" if not banned_only else "adm:users:0", "nav")])
    rows_kb.append([xbtn("⬅ Panel", "adm:home", "nav")])
    return text, xkb(*rows_kb)

@adm.callback_query(F.data.startswith(("adm:users", "adm:banned")))
async def adm_users(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    parts = cb.data.split(":")
    banned_only = parts[1] == "banned"
    page = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
    text, kb_ = _users_list_view(page, banned_only); await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data.startswith("adm:user:"))
async def adm_user_open(cb: CallbackQuery, state: FSMContext):
    await state.clear(); card = user_card(int(cb.data.split(":", 2)[2]))
    if not card: return await cb.answer("Nahi mila", show_alert=True)
    await safe_edit(cb, *card); await cb.answer()
@adm.callback_query(F.data == "adm:find_user")
async def adm_find_user(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.find_user); await safe_edit(cb, "User ID:", _kb([("Cancel", "adm:home", "danger")])); await cb.answer()
@adm.message(Flow.find_user)
async def adm_find_user_msg(msg: Message, state: FSMContext):
    try: uid = int((msg.text or "").strip())
    except ValueError: return await msg.answer("Numeric.")
    await state.clear(); card = user_card(uid)
    if not card: return await msg.answer(f"User {uid} nahi mila.", reply_markup=adm_home_kb(msg.from_user.id))
    await msg.answer(_premium_text(card[0]), reply_markup=card[1], parse_mode=ParseMode.HTML)
@adm.callback_query(F.data.startswith("adm:uban:"))
async def adm_user_ban(cb: CallbackQuery):
    uid = int(cb.data.split(":", 2)[2])
    with db() as c:
        row = c.execute("SELECT is_banned FROM users WHERE user_id=?", (uid,)).fetchone()
        if not row: return await cb.answer("Nahi mila", show_alert=True)
        new = 0 if row["is_banned"] else 1
        c.execute("UPDATE users SET is_banned=? WHERE user_id=?", (new, uid))
    log_admin(cb.from_user.id, f"{'ban' if new else 'unban'} {uid}")
    card = user_card(uid)
    if card: await safe_edit(cb, *card)
    await cb.answer("Banned" if new else "Unbanned")
@adm.callback_query(F.data.startswith("adm:utx:"))
async def adm_user_tx(cb: CallbackQuery):
    uid = int(cb.data.split(":", 2)[2])
    with db() as c: rows = c.execute("SELECT amount,action,note,created_at FROM balance_logs WHERE user_id=? ORDER BY id DESC LIMIT 10", (uid,)).fetchall()
    if not rows: return await cb.answer("No logs", show_alert=True)
    lines = [f"{'🟢' if r['action']=='add' else '🔴'} {_money(r['amount'])} · {r['action']} · {(r['created_at'] or '')[:16]}" for r in rows]
    await safe_edit(cb, f"🧾 <b>BALANCE LOG · {uid}</b>\n\n" + "\n".join(lines), _kb([("Back", f"adm:user:{uid}")])); await cb.answer()

# ── add/cut balance ──
@adm.callback_query(F.data == "adm:addbal")
async def adm_addbal(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.add_bal_uid); await safe_edit(cb, "<b>ADD BALANCE</b>\n\nUser ID:", _kb([("Cancel", "adm:home", "danger")])); await cb.answer()
@adm.message(Flow.add_bal_uid)
async def adm_addbal_uid(msg: Message, state: FSMContext):
    try: uid = int((msg.text or "").strip())
    except ValueError: return await msg.answer("Numeric.")
    with db() as c:
        if not c.execute("SELECT 1 FROM users WHERE user_id=?", (uid,)).fetchone(): return await msg.answer(f"User {uid} nahi mila.")
    await state.update_data(target_uid=uid); await state.set_state(Flow.add_bal_amt); await msg.answer(f"User: <code>{uid}</code>\nAmount:", parse_mode=ParseMode.HTML)
@adm.message(Flow.add_bal_amt)
async def adm_addbal_amt(msg: Message, state: FSMContext):
    try:
        amt = float((msg.text or "").strip())
        if amt <= 0 or not math.isfinite(amt): raise ValueError
    except ValueError: return await msg.answer("Positive.")
    data = await state.get_data(); uid = data["target_uid"]; await state.clear()
    add_balance(uid, amt, admin_id=msg.from_user.id, note="admin add")
    await send_safe(uid, f"🟢 <b>{_money(amt)} added!</b>")
    log_admin(msg.from_user.id, f"add {_money(amt)} {uid}")
    await msg.answer(_premium_text(f"✅ {_money(amt)} → <code>{uid}</code>\nNew: {_money(user_balance(uid))}"), reply_markup=adm_home_kb(msg.from_user.id), parse_mode=ParseMode.HTML)
@adm.callback_query(F.data == "adm:cutbal")
async def adm_cutbal(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.cut_bal_uid); await safe_edit(cb, "<b>CUT BALANCE</b>\n\nUser ID:", _kb([("Cancel", "adm:home", "danger")])); await cb.answer()
@adm.message(Flow.cut_bal_uid)
async def adm_cutbal_uid(msg: Message, state: FSMContext):
    try: uid = int((msg.text or "").strip())
    except ValueError: return await msg.answer("Numeric.")
    bal = user_balance(uid)
    if bal == 0: return await msg.answer("Balance 0.")
    await state.update_data(target_uid=uid); await state.set_state(Flow.cut_bal_amt); await msg.answer(f"User: <code>{uid}</code> Bal: {_money(bal)}\nKitna?", parse_mode=ParseMode.HTML)
@adm.message(Flow.cut_bal_amt)
async def adm_cutbal_amt(msg: Message, state: FSMContext):
    try:
        amt = float((msg.text or "").strip())
        if amt <= 0 or not math.isfinite(amt): raise ValueError
    except ValueError: return await msg.answer("Valid.")
    data = await state.get_data(); uid = data["target_uid"]; await state.clear()
    if not cut_balance(uid, amt, admin_id=msg.from_user.id, note="admin cut"): return await msg.answer(f"❌ Bal {_money(user_balance(uid))}.")
    await send_safe(uid, f"🔴 {_money(amt)} cut.")
    log_admin(msg.from_user.id, f"cut {_money(amt)} {uid}")
    await msg.answer(_premium_text(f"✅ {_money(amt)} cut <code>{uid}</code>\nNew: {_money(user_balance(uid))}"), reply_markup=adm_home_kb(msg.from_user.id), parse_mode=ParseMode.HTML)
@adm.callback_query(F.data.startswith("adm:uaddbal:"))
async def adm_uaddbal(cb: CallbackQuery, state: FSMContext):
    uid = int(cb.data.split(":", 2)[2]); await state.set_state(Flow.add_bal_amt); await state.update_data(target_uid=uid)
    await safe_edit(cb, f"🟢 Add to <code>{uid}</code>\nAmount:", _kb([("Cancel", f"adm:user:{uid}", "danger")])); await cb.answer()
@adm.callback_query(F.data.startswith("adm:ucutbal:"))
async def adm_ucutbal(cb: CallbackQuery, state: FSMContext):
    uid = int(cb.data.split(":", 2)[2]); await state.set_state(Flow.cut_bal_amt); await state.update_data(target_uid=uid)
    await safe_edit(cb, f"🔴 Cut from <code>{uid}</code> (bal {_money(user_balance(uid))})\nAmount:", _kb([("Cancel", f"adm:user:{uid}", "danger")])); await cb.answer()

# ── add admin ──
@adm.callback_query(F.data == "adm:addadmin")
async def adm_addadmin(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.aa_admin_uid); await safe_edit(cb, "👑 <b>ADD ADMIN</b>\n\nUser ID:", _kb([("Cancel", "adm:home", "danger")])); await cb.answer()
@adm.message(Flow.aa_admin_uid)
async def adm_aa_uid(msg: Message, state: FSMContext):
    try: uid = int((msg.text or "").strip())
    except ValueError: return await msg.answer("Numeric.")
    if uid == msg.from_user.id: return await msg.answer("Khud ko nahi.")
    await state.update_data(new_admin_uid=uid); await state.set_state(Flow.aa_admin_role)
    await msg.answer(f"User: <code>{uid}</code>\nRole:", reply_markup=_kb(
        [("Full Access", "adrole_full", "action")], [("Deposits Only", "adrole_deposits", "nav")],
        [("Stock Only", "adrole_stock", "nav")], [("Custom", "adrole_custom", "nav")],
        [("Cancel", "adm:home", "danger")]), parse_mode=ParseMode.HTML)
@adm.callback_query(F.data.startswith("adrole_"))
async def adm_aa_role(cb: CallbackQuery, state: FSMContext):
    role = cb.data[7:]
    if role not in ROLES: return await cb.answer("Invalid", show_alert=True)
    data = await state.get_data(); uid = data.get("new_admin_uid")
    if not uid: return await cb.answer("State lost", show_alert=True)
    await state.clear(); add_admin(uid, cb.from_user.id, role)
    log_admin(cb.from_user.id, f"add admin {uid} {role}")
    await send_safe(uid, f"👑 <b>Admin access</b>\nRole: {ROLES[role]}\n/admin use karo.")
    await safe_edit(cb, _premium_text(f"✅ <b>Admin Added</b>\n{uid} · {ROLES[role]}"), adm_home_kb(cb.from_user.id)); await cb.answer()
@adm.callback_query(F.data == "adm:listadmins")
async def adm_list_admins(cb: CallbackQuery):
    with db() as c: rows = c.execute("SELECT * FROM admins ORDER BY added_at DESC").fetchall()
    if not rows: return await safe_edit(cb, "Koi admin nahi.", adm_home_kb(cb.from_user.id))
    lines = [f"<code>{r['user_id']}</code> · {ROLES.get(r['role'], r['role'])}" for r in rows]
    kbrows = [[("Remove " + str(r["user_id"]), f"adm:rmadm:{r['user_id']}", "danger")] for r in rows if r["user_id"] not in ADMIN_IDS]
    kbrows.append([("Back", "adm:home")])
    await safe_edit(cb, "👑 <b>ADMINS</b>\n\n" + "\n".join(lines), _kb(*kbrows)); await cb.answer()
@adm.callback_query(F.data.startswith("adm:rmadm:"))
async def adm_rm_admin(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    uid = int(cb.data.split(":", 2)[2])
    if uid in ADMIN_IDS: return await cb.answer("Master admin remove nahi.", show_alert=True)
    remove_admin(uid); log_admin(cb.from_user.id, f"rm admin {uid}")
    await send_safe(uid, "ℹ Admin access revoke.")
   # ── orders ──
def order_card(code):
    with db() as c:
        o = c.execute("SELECT o.*, a.country, a.dial, a.server, a.type FROM orders o LEFT JOIN accounts a ON a.id=o.account_id WHERE o.order_code=?", (code,)).fetchone()
    if not o: return None
    info = _dial_info(o["dial"] or "+0")
    text = (f"🧾 <b>ORDER</b> <code>{esc(o['order_code'])}</code>\n{'─'*22}\nStatus: {esc(o['status'])}\nBuyer: <code>{o['user_id']}</code>\n"
            f"Account: #{o['account_id']} · S{o['server']} · {info['emoji']} {esc(o['country'] or '—')} {esc(o['dial'] or '')}\n"
            f"Type: {esc(o['type'] or '—')}\nPrice: {_money(o['price'])}\nAt: {(o['created_at'] or '')[:16]}")
    kbrows = []
    if o["status"] == "delivered": kbrows.append([("Refund", f"adm:rfq:{code}", "danger")])
    kbrows.append([("Open buyer", f"adm:user:{o['user_id']}", "nav")])
    kbrows.append([("Back", "adm:home")])
    return text, _kb(*kbrows)
def orders_view():
    with db() as c:
        rows = c.execute("SELECT o.order_code, o.price, o.status, a.country, a.dial FROM orders o LEFT JOIN accounts a ON a.id=o.account_id ORDER BY o.id DESC LIMIT 10").fetchall()
    if not rows: return "🧾 <b>ORDERS</b>\n\nKoi nahi.", _kb([("Back", "adm:home")])
    lines = [f"{_flag(r['dial'] or '+0')} <code>{esc(r['order_code'])}</code> · {esc(r['country'] or '—')} · {_money(r['price'])} · {r['status']}" for r in rows]
    kbrows = [[(r['order_code'][-6:], f"adm:order:{r['order_code']}")] for r in rows]
    kbrows.append([("Back", "adm:home")])
    return "🧾 <b>LATEST 10 ORDERS</b>\n\n" + "\n".join(lines), _kb(*kbrows)
@adm.callback_query(F.data == "adm:orders")
async def adm_orders(cb: CallbackQuery, state: FSMContext):
    await state.clear(); text, kb_ = orders_view(); await safe_edit(cb, text, kb_); await cb.answer()
@adm.callback_query(F.data.startswith("adm:order:"))
async def adm_order_open(cb: CallbackQuery, state: FSMContext):
    await state.clear(); card = order_card(cb.data.split(":", 2)[2])
    if not card: return await cb.answer("Nahi mila", show_alert=True)
    await safe_edit(cb, *card); await cb.answer()
@adm.callback_query(F.data == "adm:find_order")
async def adm_find_order(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.find_order); await safe_edit(cb, "Order code (ss_XXXXXXXX):", _kb([("Cancel", "adm:home", "danger")])); await cb.answer()
@adm.message(Flow.find_order)
async def adm_find_order_msg(msg: Message, state: FSMContext):
    await state.clear(); card = order_card(_norm_code(msg.text or ""))
    if not card: return await msg.answer("Order nahi mila.", reply_markup=adm_home_kb(msg.from_user.id))
    await msg.answer(_premium_text(card[0]), reply_markup=card[1], parse_mode=ParseMode.HTML)
@adm.callback_query(F.data.startswith("adm:rfq:"))
async def adm_refund_ask(cb: CallbackQuery):
    code = cb.data.split(":", 2)[2]
    await safe_edit(cb, f"<b>REFUND?</b>\n<code>{esc(code)}</code>", _kb([("Yes", f"adm:rf:{code}", "action")], [("No", f"adm:order:{code}", "danger")]))
    await cb.answer()
@adm.callback_query(F.data.startswith("adm:rf:"))
async def adm_refund(cb: CallbackQuery):
    code = cb.data.split(":", 2)[2]
    with db() as c:
        cur = c.execute("UPDATE orders SET status='refunded' WHERE order_code=? AND status='delivered'", (code,))
        o = None
        if cur.rowcount == 1:
            o = c.execute("SELECT user_id, price FROM orders WHERE order_code=?", (code,)).fetchone()
            c.execute("UPDATE users SET balance=balance+?, total_spent=total_spent-? WHERE user_id=?", (o["price"], o["price"], o["user_id"]))
    if not o: return await cb.answer("Refund fail", show_alert=True)
    _reverse_referrer(code)
    await send_safe(o["user_id"], f"↩ Order <code>{code}</code> refund {_money(o['price'])}.")
    log_admin(cb.from_user.id, f"refund {code}")
    card = order_card(code)
    if card: await safe_edit(cb, *card)
    await cb.answer("Refunded")

# ── stock ──
def stock_view():
    with db() as c:
        per = c.execute("SELECT server, SUM(CASE WHEN sold=0 AND session_data<>'' THEN 1 ELSE 0 END) AS live, SUM(CASE WHEN sold=1 THEN 1 ELSE 0 END) AS sold, COUNT(*) AS total FROM accounts GROUP BY server ORDER BY server").fetchall()
        top = c.execute("SELECT server, country, dial, COUNT(*) AS n, MIN(price) AS mp FROM accounts WHERE sold=0 AND session_data IS NOT NULL AND session_data<>'' GROUP BY server, country, dial ORDER BY n DESC LIMIT 12").fetchall()
    lines = [f"Server {r['server']} · live <b>{r['live'] or 0}</b> · sold {r['sold'] or 0} · total {r['total']}" for r in per]
    lines.append("")
    lines += [f"S{t['server']} · {_flag(t['dial'])} {esc(t['dial'])} · {t['n']} · from {_money(t['mp'])}" for t in top]
    if not top: lines.append("No live stock.")
    return "📦 <b>STOCK</b>\n\n" + "\n".join(lines), _kb([("Import TXT", "adm:import", "action")], [("Add Account", "adm:ac_start", "action")], [("Refresh", "adm:stock", "nav")], [("Back", "adm:home")])
@adm.callback_query(F.data == "adm:stock")
async def adm_stock(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    text, kb_ = stock_view(); await safe_edit(cb, text, kb_); await cb.answer()
@adm.callback_query(F.data == "adm:import")
async def adm_import(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.stock_file_wait)
    await safe_edit(cb, "📦 <b>IMPORT STOCK</b>\n\nTXT format:\n<code>server|country|dial|phone|price|origin|session|2fa_pass</code>", _kb([("Cancel", "adm:stock", "danger")])); await cb.answer()
@adm.message(Flow.stock_file_wait, F.document)
async def adm_stock_file(msg: Message, state: FSMContext):
    await state.clear()
    try:
        file = await bot.get_file(msg.document.file_id); content = await bot.download_file(file.file_path); text = content.read().decode("utf-8", errors="ignore")
    except Exception as e: log.exception(f"stock dl: {e}"); return await msg.answer("Download fail.", reply_markup=adm_home_kb(msg.from_user.id))
    added = skipped = 0; now = datetime.now().isoformat()
    with db() as c:
        for line in text.splitlines():
            if not line.strip(): continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 7 or not parts[6]: skipped += 1; continue
            try:
                server = int(parts[0]); price = float(parts[4])
                if server not in (1, 2) or not math.isfinite(price) or price <= 0: raise ValueError
            except ValueError: skipped += 1; continue
            twofa_pass = parts[7] if len(parts) > 7 else ""
            d_info = _dial_info(parts[2]); country = parts[1] or d_info["name"]
            c.execute("INSERT INTO accounts (server,country,dial,phone,price,origin,session_data,twofa_pass,twofa,uploaded_at,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                      (server, country, parts[2], parts[3], price, parts[5], parts[6], twofa_pass, 1 if twofa_pass else 0, now, now))
            added += 1
    log_admin(msg.from_user.id, f"import stock {added}/{skipped}")
    await msg.answer(f"✅ Imported {added} · skipped {skipped}", reply_markup=adm_home_kb(msg.from_user.id))

# ── add account: admin only. Two ways: Telethon login (phone -> OTP -> 2FA) or paste session ──
AC_ORDER_PASTE = [Flow.ac_server, Flow.ac_phone, Flow.ac_price, Flow.ac_origin, Flow.ac_twofa, Flow.ac_session]
AC_ORDER_TL = [Flow.ac_server, Flow.ac_price, Flow.ac_origin]   # phone, OTP and 2FA are done by the login
AC_ORIGINS = ["Phishing", "Stealer", "Resale", "Manual"]
AC_TEXT = {
    Flow.ac_server.state: ("Server",
        "Server chuno:\n\n<b>Budget</b> = sasta, risk zyada\n<b>Premium</b> = mehenga, safe\n\nNeeche button dabao, ya <code>1</code> / <code>2</code> likho."),
    Flow.ac_phone.state: ("Phone",
        "Account ka phone number country code ke saath likho.\n\nJaise <code>+919876543210</code>.\n\nCountry aur dial code isi se apne aap pehchan liye jaayenge."),
    Flow.ac_price.state: ("Price",
        "Is account ki price ₹ mein likho.\n\nJaise <code>45</code> ya <code>99.5</code>. Sirf number."),
    Flow.ac_origin.state: ("Origin",
        "Account kahan se aaya hai, chuno:\n\n<b>Phishing</b> · <b>Stealer</b> · <b>Resale</b> · <b>Manual</b>\n\nKoi aur origin ho to type karke bhi likh sakte ho."),
    Flow.ac_twofa.state: ("2FA",
        "Account par 2FA password hai to likho.\n\nNahi hai to <b>None</b> dabao."),
    Flow.ac_session.state: ("Session",
        "Session string paste karo.\n\nSave hote hi account stock mein live ho jayega."),
}

def _ac_order(data):
    return AC_ORDER_TL if (data or {}).get("ac_flow") == "tl" else AC_ORDER_PASTE

def _ac_info(data):
    lines = []
    if data.get("ac_server"):
        with db() as c:
            n = c.execute("SELECT COUNT(*) FROM accounts WHERE server=? AND sold=0", (int(data["ac_server"]),)).fetchone()[0]
        lines.append(f"📦 Server {data['ac_server']} · total available: <b>{n}</b>")
    if data.get("ac_dial"):
        lines.append(f"📍 {_flag(data['ac_dial'])} {esc(data.get('ac_country', ''))} {esc(data['ac_dial'])}")
    return ("\n".join(lines) + "\n\n") if lines else ""

def _ac_render(step, data=None):
    data = data or {}
    order = _ac_order(data)
    idx = order.index(step)
    name, body = AC_TEXT[step.state]
    info = _ac_info(data) if step != Flow.ac_server else ""
    text = f"➕ <b>ADD ACCOUNT · {idx + 1}/{len(order)} · {name}</b>\n{'─'*22}\n{info}{body}"
    rows = []
    if step == Flow.ac_server:
        rows.append([xbtn("🟢 Budget", "adm:ac_pick:server:1", "action"), xbtn("🔵 Premium", "adm:ac_pick:server:2", "action")])
    elif step == Flow.ac_origin:
        rows.append([xbtn(o, f"adm:ac_pick:origin:{o}", "nav") for o in AC_ORIGINS[:2]])
        rows.append([xbtn(o, f"adm:ac_pick:origin:{o}", "nav") for o in AC_ORIGINS[2:]])
    elif step == Flow.ac_twofa:
        rows.append([xbtn("🚫 None", "adm:ac_pick:twofa:none", "nav")])
    rows.append([xbtn("⬅ Back", "adm:acback", "nav"), xbtn("❌ Cancel", "adm:home", "danger")])
    return text, xkb(*rows)

async def _ac_send(msg: Message, state: FSMContext, step):
    await state.set_state(step)
    text, kb_ = _ac_render(step, await state.get_data())
    await msg.answer(_premium_text(text), reply_markup=kb_, parse_mode=ParseMode.HTML)

async def _ac_show_cb(cb: CallbackQuery, state: FSMContext, step):
    await state.set_state(step)
    text, kb_ = _ac_render(step, await state.get_data())
    await safe_edit(cb, text, kb_)

async def _ac_source_menu(cb: CallbackQuery):
    await safe_edit(cb,
        "➕ <b>ADD ACCOUNT</b>\n" + "─" * 22 + "\n"
        "Account kaise add karna hai?\n\n"
        "📲 <b>Telethon login</b>: phone number, OTP aur 2FA se login karo. Session bot khud save karega. Sabse aasan.\n\n"
        "📋 <b>Session paste</b>: pehle se bani session string paste karo.",
        xkb([xbtn("📲 Telethon login", "adm:ac_src:tl", "action"), xbtn("📋 Session paste", "adm:ac_src:paste", "nav")],
            [xbtn("❌ Cancel", "adm:home", "danger")]))

def _ac_insert(server, country, dial, phone, price, origin, session, twofa):
    now = datetime.now().isoformat()
    with db() as c:
        c.execute("INSERT INTO accounts (server,country,dial,phone,price,origin,twofa_pass,session_data,twofa,uploaded_at,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (server, country, dial, phone, price, origin, twofa or "", session, 1 if twofa else 0, now, now))

async def _ac_tl_finish(target: Message, uid: int, state: FSMContext):
    data = await state.get_data(); await state.clear()
    _ac_insert(int(data["ac_server"]), data["ac_country"], data["ac_dial"], data["ac_phone"],
               float(data["ac_price"]), data["ac_origin"], data["tl_session"], data.get("ac_twofa", ""))
    log_admin(uid, f"add acc tl {data['ac_dial']}")
    await target.answer(_premium_text(
        f"✅ <b>Saved!</b>\n🌍 {_flag(data['ac_dial'])} {esc(data['ac_country'])} {esc(data['ac_dial'])}\n📞 <code>{esc(data['ac_phone'])}</code>\n"
        f"💰 {_money(data['ac_price'])} · S{data['ac_server']} · {esc(data['ac_origin'])}\n"
        f"🔐 2FA: {'✅ saved' if data.get('ac_twofa') else '— none'}"),
        reply_markup=_kb([("Stock", "adm:stock", "nav")], [("Back", "adm:home")]), parse_mode=ParseMode.HTML)

@adm.callback_query(F.data == "adm:ac_start")
async def adm_ac_start(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    await state.clear(); await _ac_source_menu(cb); await cb.answer()

@adm.callback_query(F.data == "adm:ac_src:paste")
async def adm_ac_src_paste(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    await state.clear(); await _ac_show_cb(cb, state, Flow.ac_server); await cb.answer()

@adm.callback_query(F.data == "adm:ac_src:tl")
async def adm_ac_src_tl(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    if not get_setting("api_id") or not get_setting("api_hash"):
        return await cb.answer("❌ API ID/HASH set nahi. Settings → API Config mein daalo.", show_alert=True)
    await state.clear(); await state.update_data(ac_flow="tl"); await state.set_state(Flow.tl_phone)
    await safe_edit(cb,
        "📲 <b>TELETHON LOGIN</b>\n" + "─" * 22 + "\n"
        "Account ka phone number country code ke saath likho.\n\n"
        "Jaise <code>+919876543210</code>.\n\n"
        "OTP us account ki Telegram app mein aayega.",
        xkb([xbtn("⬅ Back", "adm:ac_start", "nav"), xbtn("❌ Cancel", "adm:home", "danger")]))
    await cb.answer()

@adm.callback_query(F.data == "adm:acback")
async def adm_ac_back(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    cur = await state.get_state(); order = _ac_order(await state.get_data())
    idx = next((i for i, st in enumerate(order) if st.state == cur), None)
    if idx is None or idx == 0:
        await state.clear(); await _ac_source_menu(cb); return await cb.answer()
    await _ac_show_cb(cb, state, order[idx - 1]); await cb.answer()

@adm.callback_query(F.data.startswith("adm:ac_pick:"))
async def adm_ac_pick(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    cur = await state.get_state(); data = await state.get_data()
    parts = cb.data.split(":")
    if len(parts) != 4: return await cb.answer()
    field, value = parts[2], parts[3]
    if field == "server" and cur == Flow.ac_server.state and value in ("1", "2"):
        await state.update_data(ac_server=int(value))
        nxt = Flow.ac_price if data.get("ac_flow") == "tl" else Flow.ac_phone
        await _ac_show_cb(cb, state, nxt); return await cb.answer("✅")
    if field == "origin" and cur == Flow.ac_origin.state and value in AC_ORIGINS:
        await state.update_data(ac_origin=value); await cb.answer("✅")
        if data.get("ac_flow") == "tl": return await _ac_tl_finish(cb.message, cb.from_user.id, state)
        return await _ac_show_cb(cb, state, Flow.ac_twofa)
    if field == "twofa" and cur == Flow.ac_twofa.state and value == "none":
        await state.update_data(ac_twofa="")
        await _ac_show_cb(cb, state, Flow.ac_session); return await cb.answer("✅")
    await cb.answer("Ye step ab active nahi hai.", show_alert=True)

@adm.message(Flow.ac_server)
async def ac_server_msg(msg: Message, state: FSMContext):
    if (msg.text or "").strip() not in ("1", "2"):
        return await msg.answer("❌ Sirf <b>1</b> (Budget) ya <b>2</b> (Premium) bhejo, ya button dabao.", parse_mode=ParseMode.HTML)
    await state.update_data(ac_server=int(msg.text.strip()))
    data = await state.get_data()
    await _ac_send(msg, state, Flow.ac_price if data.get("ac_flow") == "tl" else Flow.ac_phone)

@adm.message(Flow.ac_phone)
async def ac_phone_msg(msg: Message, state: FSMContext):
    phone = re.sub(r"[\s\-()]", "", msg.text or "")
    if not re.fullmatch(r"\+\d{7,15}", phone):
        return await msg.answer("❌ Number country code ke saath likho, jaise <code>+919876543210</code>.", parse_mode=ParseMode.HTML)
    name, dial = country_from_phone(phone)
    if dial == "+0": name = "Unknown"
    await state.update_data(ac_phone=phone, ac_country=name, ac_dial=dial)
    await _ac_send(msg, state, Flow.ac_price)

@adm.message(Flow.ac_price)
async def ac_price_msg(msg: Message, state: FSMContext):
    try:
        p = float((msg.text or "").strip())
        if not math.isfinite(p) or p <= 0: raise ValueError
    except ValueError:
        return await msg.answer("❌ Valid price bhejo, jaise <code>45</code>.", parse_mode=ParseMode.HTML)
    await state.update_data(ac_price=p)
    await _ac_send(msg, state, Flow.ac_origin)

@adm.message(Flow.ac_origin)
async def ac_origin_msg(msg: Message, state: FSMContext):
    v = (msg.text or "").strip()
    if not v: return await msg.answer("❌ Origin likho ya button dabao.")
    await state.update_data(ac_origin=v)
    data = await state.get_data()
    if data.get("ac_flow") == "tl": return await _ac_tl_finish(msg, msg.from_user.id, state)
    await _ac_send(msg, state, Flow.ac_twofa)

@adm.message(Flow.ac_twofa)
async def ac_twofa_msg(msg: Message, state: FSMContext):
    v = (msg.text or "").strip()
    await state.update_data(ac_twofa="" if v.lower() in ("none", "no", "nahi") else v)
    await _ac_send(msg, state, Flow.ac_session)

@adm.message(Flow.ac_session)
async def ac_session_msg(msg: Message, state: FSMContext):
    session = (msg.text or "").strip()
    if not session: return await msg.answer("❌ Session string bhejo.")
    data = await state.get_data(); await state.clear()
    country, dial = data["ac_country"], data["ac_dial"]
    _ac_insert(int(data["ac_server"]), country, dial, data["ac_phone"], float(data["ac_price"]),
               data["ac_origin"], session, data.get("ac_twofa", ""))
    log_admin(msg.from_user.id, f"add acc {dial}")
    await msg.answer(_premium_text(f"✅ <b>Added!</b>\n{_flag(dial)} {esc(country)} {esc(dial)} · <code>{esc(data['ac_phone'])}</code>\nPrice: {_money(data['ac_price'])}"),
                     reply_markup=_kb([("Stock", "adm:stock", "nav")], [("Back", "adm:home")]), parse_mode=ParseMode.HTML)

async def _tl_login_done(msg, state, result, data):
    """Login succeeded (OTP + optional 2FA). Add-account flow: continue to server/price/origin.
    Standalone Telethon login: save straight away."""
    if data.get("ac_flow") != "tl":
        return await _save_tl_account(msg, state, result, data)
    phone = result.get("phone") or data.get("tl_phone", "")
    name, dial = country_from_phone(phone)
    if dial == "+0": name = "Unknown"
    await state.update_data(ac_phone=phone, ac_country=name, ac_dial=dial, tl_session=result["session"],
                            ac_twofa=data.get("tl_2fa_pass", "") or "")
    await state.set_state(Flow.ac_server)
    text, kb_ = _ac_render(Flow.ac_server, await state.get_data())
    await msg.answer(_premium_text(f"✅ <b>Login ho gaya</b> · <code>{esc(phone)}</code>\n\n" + text),
                     reply_markup=kb_, parse_mode=ParseMode.HTML)

# ── telethon ──
@adm.callback_query(F.data == "adm:tlogin")
async def adm_tlogin_cb(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    if not get_setting("api_id"): return await cb.answer("❌ API ID/HASH set nahi.", show_alert=True)
    await state.clear(); await state.set_state(Flow.tl_phone); await safe_edit(cb, "📲 <b>TELETHON</b>\n\nNumber (+91…):", _kb([("Cancel", "adm:home", "danger")])); await cb.answer()
@adm.message(Flow.tl_phone)
async def tl_phone_msg(msg: Message, state: FSMContext):
    if not has_perm(msg.from_user.id, "stock"): await state.clear(); return
    phone = re.sub(r"[\s\-()]", "", (msg.text or ""))
    if not re.fullmatch(r"\+\d{7,15}", phone):
        return await msg.answer("❌ Number country code ke saath likho, jaise <code>+919876543210</code>.", parse_mode=ParseMode.HTML)
    await msg.answer("⏳ OTP bhej rahe hain...")
    result = await tl_request_otp(phone)
    if not result["success"]:
        await state.clear()
        return await msg.answer(f"❌ OTP nahi gaya: {esc(result['error'])}\n\nNumber ya API ID/HASH check karke /admin se dobara try karo.", parse_mode=ParseMode.HTML)
    await state.update_data(tl_phone=phone, tl_hash=result["phone_code_hash"], tl_session=result["session"])
    await state.set_state(Flow.tl_otp)
    await msg.answer(
        "✅ <b>OTP bhej diya.</b>\n\n"
        "Code us account ki <b>Telegram app</b> mein aayega (Telegram ke official chat mein, SMS mein nahi).\n\n"
        "Wo code yahan likho. Spaces ho to bhi chalega.\n<i>Galat ho to dobara likho, ya /cancel.</i>",
        parse_mode=ParseMode.HTML)

@adm.message(Flow.tl_otp)
async def tl_otp_msg(msg: Message, state: FSMContext):
    if not has_perm(msg.from_user.id, "stock"): await state.clear(); return
    code = re.sub(r"\D", "", msg.text or "")
    if not code: return await msg.answer("Code sirf numbers mein bhejo, ya /cancel.")
    data = await state.get_data()
    if not data.get("tl_phone"): await state.clear(); return await msg.answer("❌ Session khatam. /admin se dobara shuru karo.")
    await msg.answer("⏳ Verify ho raha hai...")
    result = await tl_sign_in(data["tl_phone"], code, data["tl_hash"], data["tl_session"])
    if not result["success"] and result.get("needs_2fa"):
        await state.set_state(Flow.tl_2fa)
        return await msg.answer("🔐 Is account par 2FA hai. Cloud password bhejo:")
    if not result["success"]:
        err = result.get("error", "")
        if "expired" in err.lower():
            await state.clear()
            return await msg.answer("❌ Code expire ho gaya. /admin se Telethon Login dobara karo.")
        return await msg.answer(f"❌ {esc(err)}\nSahi code bhejo, ya /cancel.", parse_mode=ParseMode.HTML)
    await _tl_login_done(msg, state, result, data)

@adm.message(Flow.tl_2fa)
async def tl_2fa_msg(msg: Message, state: FSMContext):
    if not has_perm(msg.from_user.id, "stock"): await state.clear(); return
    data = await state.get_data()
    pwd = (msg.text or "").strip()
    if not pwd: return await msg.answer("2FA password bhejo, ya /cancel.")
    result = await tl_sign_in(data["tl_phone"], "", data.get("tl_hash", ""), data["tl_session"], pwd)
    if not result["success"]:
        return await msg.answer(f"❌ {esc(result.get('error', 'Password galat'))}\nDobara password bhejo, ya /cancel.", parse_mode=ParseMode.HTML)
    data["tl_2fa_pass"] = pwd
    await _tl_login_done(msg, state, result, data)

async def _save_tl_account(msg, state, result, data):
    await state.clear()
    phone = result.get("phone") or data.get("tl_phone", "")
    country_name, dial = country_from_phone(phone)
    if dial == "+0": country_name = "Unknown"
    now = datetime.now().isoformat()
    from_ac = "ac_server" in data
    server = int(data["ac_server"]) if from_ac else 2
    price = float(data["ac_price"]) if from_ac else float(get_setting("tl_price", "10"))
    origin = (data.get("ac_origin") or "Manual") if from_ac else "Manual"
    twofa = data.get("tl_2fa_pass", "") or (data.get("ac_twofa", "") if from_ac else "") or ""
    with db() as c:
        c.execute("INSERT INTO accounts (server,country,dial,phone,price,origin,session_data,twofa_pass,twofa,uploaded_at,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (server, country_name, dial, phone, price, origin, result["session"], twofa, 1 if twofa else 0, now, now))
    log_admin(msg.from_user.id, f"tlogin {phone} {dial}")
    await msg.answer(_premium_text(f"✅ <b>Saved!</b>\n🌍 {_flag(dial)} {esc(country_name)} {esc(dial)}\n📞 <code>{esc(phone)}</code>\n💰 {_money(price)} · S{server} · {esc(origin)}\n🔐 2FA: {'✅ saved' if twofa else '— none'}"),
                     reply_markup=_kb([("Stock", "adm:stock", "nav")], [("Back", "adm:home")]), parse_mode=ParseMode.HTML)

# ── api config ──
@adm.callback_query(F.data == "adm:apiconfig")
async def adm_apiconfig(cb: CallbackQuery):
    cid = get_setting("api_id", "") or "not set"; chsh = get_setting("api_hash", "") or "not set"
    mhsh = (chsh[:4] + "••••" + chsh[-4:]) if len(chsh) > 8 else chsh
    await safe_edit(cb, f"🔑 <b>API CONFIG</b>\nAPI ID: <code>{esc(cid)}</code>\nAPI HASH: <code>{esc(mhsh)}</code>\n\n<i>my.telegram.org</i>",
                    _kb([("Set API ID", "adm:set_api_id", "action")], [("Set API HASH", "adm:set_api_hash", "action")], [("Back", "adm:home")])); await cb.answer()
@adm.callback_query(F.data == "adm:set_api_id")
async def adm_set_api_id(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.api_id_wait); await safe_edit(cb, "API ID:", _kb([("Cancel", "adm:apiconfig", "danger")])); await cb.answer()
@adm.message(Flow.api_id_wait)
async def adm_api_id_msg(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip()
    try: int(raw)
    except ValueError: return await msg.answer("Numeric.")
    set_setting("api_id", raw); await state.clear(); await msg.answer(f"✅ API ID: <code>{esc(raw)}</code>", reply_markup=_kb([("API", "adm:apiconfig", "nav")]), parse_mode=ParseMode.HTML)
@adm.callback_query(F.data == "adm:set_api_hash")
async def adm_set_api_hash(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.api_hash_wait); await safe_edit(cb, "API HASH:", _kb([("Cancel", "adm:apiconfig", "danger")])); await cb.answer()
@adm.message(Flow.api_hash_wait)
async def adm_api_hash_msg(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip()
    if len(raw) < 8: return await msg.answer("Valid.")
    set_setting("api_hash", raw); await state.clear()
    await msg.answer("✅ API HASH saved.", reply_markup=_kb([("API", "adm:apiconfig", "nav")]))
    # ── settings ──
SETTING_FIELDS = {
    "min_deposit": ("Min deposit", "float"), "max_deposit": ("Max deposit", "float"),
    "warranty_hours": ("Warranty", "int"), "welcome_text": ("Welcome text", "text"),
    "crypto_address": ("Crypto address", "text"), "crypto_coin": ("Crypto coin", "text"),
    "stars_rate": ("Stars rate (₹ per ⭐)", "float"),
    "welcome_dev": ("Welcome Developer Name", "text"),
    "sales_channel": ("Sales channel ID (-100…)", "text"), "support_bot": ("Support link (@user)", "text"),
    "upi_id": ("UPI ID", "text"),
    "tos_owner": ("TOS Owner username", "text"),
    "ref_percent": ("Referral reward % per order", "float"),
    "otp_admin_id": ("OTP Admin ID", "int"),
    "otp_admin_link": ("OTP Admin Link/Username", "text"),
    "tl_price": ("Telethon account price ₹", "float"),
    "sales_link": ("Sales channel link (https://t.me/...)", "text")
}
def settings_view():
    sp = xget("welcome_spoiler", "1") == "1"; mt = xget("maintenance") == "1"
    has_media = bool(xget("welcome_media"))
    text = (f"⚙ <b>SETTINGS</b>\nMin: {_money(get_setting('min_deposit'))}\nMax: {_money(get_setting('max_deposit'))}\n"
            f"Warranty: {esc(get_setting('warranty_hours'))}h\nCrypto: {esc(get_setting('crypto_coin'))}\n"
            f"Sales ch: <code>{esc(cfg_sales_channel() or '—')}</code> · Support: <code>{esc(cfg_support())}</code>\n"
            f"Welcome media: {'✅' if has_media else '❌'}\nSpoiler: {'ON' if sp else 'OFF'}\nMaintenance: {'ON' if mt else 'OFF'}\n"
            f"TOS Owner: <code>{esc(get_setting('tos_owner') or '—')}</code>\n"
            f"Welcome Dev: <code>{esc(get_setting('welcome_dev') or '—')}</code>\n"
            f"OTP Admin ID: <code>{esc(get_setting('otp_admin_id') or '0')}</code> · Link: <code>{esc(get_setting('otp_admin_link') or '—')}</code>\n"
            f"Verify Contact: {'ON' if get_setting('verif_contact')=='1' else 'OFF'} · Verify Emoji: {'ON' if get_setting('verif_math')=='1' else 'OFF'}")
    kb_ = xkb(
        [xbtn("Min ✏", "adm:set:min_deposit", "action"), xbtn("Max ✏", "adm:set:max_deposit", "action")],
        [xbtn("Warranty ✏", "adm:set:warranty_hours", "action"), xbtn("Welcome ✏", "adm:set:welcome_text", "action")],
        [xbtn("Crypto Addr ✏", "adm:set:crypto_address", "action"), xbtn("Crypto Coin", "adm:set:crypto_coin", "action")],
        [xbtn("Stars rate ✏", "adm:set:stars_rate", "action")],
        [xbtn("📱 TL Price ✏", "adm:set:tl_price", "action")],
        [xbtn("📢 Sales channel ✏", "adm:set:sales_channel", "action"), xbtn("🤖 Support ✏", "adm:set:support_bot", "action")],
        [xbtn("💳 UPI ID ✏", "adm:set:upi_id", "action")],
        [xbtn("📢 Sales link ✏", "adm:set:sales_link", "action")],
        [xbtn("👑 TOS Owner Set", "adm:set:tos_owner", "action"), xbtn("🥰 Set Dev Name", "adm:set:welcome_dev", "action")],
        [xbtn("🆘 OTP Admin ID", "adm:set:otp_admin_id", "action"), xbtn("🔗 OTP Admin Link", "adm:set:otp_admin_link", "action")],
        [xbtn(f"📱 Contact: {'ON' if get_setting('verif_contact')=='1' else 'OFF'}", "xadm:v_toggle:contact", "action")],
        [xbtn(f"🧩 Emoji captcha: {'ON' if get_setting('verif_math')=='1' else 'OFF'}", "xadm:v_toggle:math", "action")],
        [xbtn("Sale Photo 🖼", "adm:salephoto", "action")],
        [xbtn("🖼 Welcome media", "xadm:wmedia", "action"), xbtn("🗑 Remove media", "xadm:wdel", "danger")],
        [xbtn("💳 UPI QR ✏", "xadm:qr:upi", "action"), xbtn("🔑 Crypto QR ✏", "xadm:qr:crypto", "action")],
        [xbtn(f"✨ Spoiler: {'ON' if sp else 'OFF'}", "xadm:wspoil", "nav")],
        [xbtn(f"🛠 Maintenance: {'ON' if mt else 'OFF'}", "xadm:mtoggle:s", "action")],
        [xbtn("📢 Force-join channels", "xadm:fch", "nav")],
        [xbtn("🤝 Referral % ✏", "adm:set:ref_percent", "action")],
        [xbtn("⬅ Panel", "adm:home", "nav")])
    return text, kb_

@adm.callback_query(F.data == "adm:settings")
async def adm_settings(cb: CallbackQuery, state: FSMContext):
    await state.clear(); text, kb_ = settings_view(); await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data.startswith("adm:set:"))
async def adm_set_pick(cb: CallbackQuery, state: FSMContext):
    key = cb.data.split(":", 2)[2]
    if key not in SETTING_FIELDS: return await cb.answer("Unknown", show_alert=True)
    label, kind = SETTING_FIELDS[key]; hint = {"float": "number", "int": "whole", "text": "text"}[kind]
    await state.set_state(Flow.setting_value); await state.update_data(key=key)
    await safe_edit(cb, f"<b>{label}</b>\nCurrent: <code>{esc(get_setting(key))}</code>\nNew ({hint}):", _kb([("Cancel", "adm:settings", "danger")])); await cb.answer()

@adm.message(Flow.setting_value)
async def adm_setting_value(msg: Message, state: FSMContext):
    data = await state.get_data(); key = data.get("key")
    if key not in SETTING_FIELDS: await state.clear(); return await msg.answer("Lost.")
    _, kind = SETTING_FIELDS[key]; raw = ((msg.html_text if kind == "text" else msg.text) or "").strip()
    try:
        if kind == "float":
            val = float(raw)
            if not math.isfinite(val) or val <= 0: raise ValueError
            new = f"{val:g}"
        elif kind == "int":
            val = int(raw)
            if val < 0: raise ValueError
            new = str(val)
        else:
            if key in ("sales_channel", "support_bot", "upi_id"):
                new = _cfg_value(key, raw)
                if not new:
                    return await msg.answer("❌ Galat format. Sales: -100 wali channel ID. Support: @username ya t.me link. UPI: name@bank")
            elif key == "otp_admin_link":
                if raw and not _normalise_admin_link(raw):
                    return await msg.answer("❌ Invalid link. Formats: @name, name, https://t.me/name, https://t.me/+invite, tg://user?id=123")
                new = raw
            else:
                if not raw or len(raw) > 1000: raise ValueError
                new = raw
    except ValueError: return await msg.answer("Valid.")
    set_setting(key, new); log_admin(msg.from_user.id, f"set {key}")
    if key == "sales_channel":
        set_setting("sales_link", "")          # drop stale link, rebuild from new channel
        try:
            ch = await bot.get_chat(int(new))
            if ch.username: set_setting("sales_link", f"https://t.me/{ch.username}")
        except Exception as e:
            log.warning("sales channel link not resolved: %s", e)
    await state.clear(); text, kb_ = settings_view()
    await msg.answer(f"✅ {SETTING_FIELDS[key][0]} updated.\n\n{text}", reply_markup=kb_, parse_mode=ParseMode.HTML)

@adm.callback_query(F.data.startswith("xadm:v_toggle:"))
async def ex_v_toggle(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    kind = cb.data.split(":")[2]
    key = f"verif_{kind}"
    new_val = "0" if get_setting(key) == "1" else "1"
    set_setting(key, new_val)
    log_admin(cb.from_user.id, f"verify {kind} = {new_val}")
    text, kb_ = settings_view()
    await safe_edit(cb, text, kb_)
    await cb.answer(f"Verification {kind.upper()} {'ON' if new_val=='1' else 'OFF'}")

@adm.callback_query(F.data == "xadm:otpadmin")
async def ex_otpadmin(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    aid = get_setting("otp_admin_id", "0") or "0"
    link = get_setting("otp_admin_link", "") or "—"
    eff = _otp_admin_url() or "❌ none (button hidden)"
    text = (f"🆘 <b>OTP ADMIN SETTINGS</b>\n━━━━━━━━━━━━━━━━━━\n"
            f"🆔 User ID: <code>{esc(aid)}</code>\n🔗 Link/Username: <code>{esc(link)}</code>\n\n"
            f"✅ <b>Active button URL:</b>\n<code>{esc(eff)}</code>\n\n"
            f"<i>Link set hai toh woh priority pe hai.</i>")
    kb_ = xkb([xbtn("🆔 Set User ID", "adm:set:otp_admin_id", "action"), xbtn("🔗 Set Link", "adm:set:otp_admin_link", "action")], [xbtn("⬅ Settings", "adm:settings", "nav")])
    await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data == "adm:salephoto")
async def adm_salephoto(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.sale_photo_wait); await safe_edit(cb, "🖼 Photo:", _kb([("Cancel", "adm:settings", "danger")])); await cb.answer()
@adm.message(Flow.sale_photo_wait, F.photo)
async def adm_set_salephoto(msg: Message, state: FSMContext):
    await state.clear(); file = await bot.get_file(msg.photo[-1].file_id)
    await bot.download_file(file.file_path, SALE_PHOTO_PATH); set_setting("sale_photo", SALE_PHOTO_PATH)
    await msg.answer("✅ Sale photo updated.", reply_markup=adm_home_kb(msg.from_user.id))

# ── product edit / position ──
PRODUCT_FIELDS = {
    "price": "Price ₹ (number, jaise 45)",
    "origin": "Origin: Phishing / Stealer / Resale / Manual",
    "type": "Type (jaise Fresh / Old)",
    "twofa": "2FA password (none likho to hat jayega)",
    "position": "Position (number, chhota number pehle dikhega)",
}

def product_card(acc_id, back="xadm:pl:edit:0"):
    with db() as c:
        a = c.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
    if not a: return None
    status = "SOLD" if a["sold"] else "LIVE"
    flag = _flag(a["dial"] or "")
    text = (f"📦 <b>PRODUCT #{a['id']}</b> · {status}\n{'─'*22}\n"
            f"Server: S{a['server']} · {flag} {esc(a['country'] or '—')} {esc(a['dial'] or '')}\n"
            f"Phone: <code>{esc(a['phone'] or '—')}</code>\n"
            f"Price: <b>{_money(a['price'])}</b>\n"
            f"Origin: {esc(a['origin'] or '—')} · Type: {esc(a['type'] or '—')}\n"
            f"2FA: {'✅ saved' if a['twofa_pass'] else '—'}\n"
            f"Position: <b>{a['position']}</b>")
    kb_ = xkb([xbtn("💰 Price", f"xadm:pe:price:{acc_id}", "action"), xbtn("🏷 Origin", f"xadm:pe:origin:{acc_id}", "action")],
              [xbtn("🧾 Type", f"xadm:pe:type:{acc_id}", "action"), xbtn("🔐 2FA", f"xadm:pe:twofa:{acc_id}", "action")],
              [xbtn("⬆ Move up", f"xadm:pe:up:{acc_id}", "nav"), xbtn("⬇ Move down", f"xadm:pe:down:{acc_id}", "nav")],
              [xbtn("📍 Set number", f"xadm:pe:position:{acc_id}", "action")],
              [xbtn("🔄 Refresh", f"xadm:pe:show:{acc_id}", "nav"), xbtn("⬅ Back", back, "nav")])
    eff = BTN_OVR.get(f"c:buy_{acc_id}", "success")
    buy_style = {"style": eff} if eff != "none" else {}
    kb_.inline_keyboard.insert(-1, [InlineKeyboardButton(text=f"🎨 Buy button: {dict(_CHOICES)[eff]}",
                                                         callback_data=f"xadm:pbc:{acc_id}", **buy_style)])
    return text, kb_

def _move_product(acc_id, delta):
    """Swap this product with its neighbour in the position order, then renumber 1..N."""
    with db() as c:
        ids = [r["id"] for r in c.execute("SELECT id FROM accounts ORDER BY position ASC, id ASC").fetchall()]
    if acc_id not in ids: return False
    i = ids.index(acc_id); j = i + delta
    if j < 0 or j >= len(ids): return False
    ids[i], ids[j] = ids[j], ids[i]
    with db() as c:
        for pos, aid in enumerate(ids, 1):
            c.execute("UPDATE accounts SET position=? WHERE id=?", (pos, aid))
    return True

PROD_PAGE = 8

def _prod_list_view(mode, page=0):
    with db() as c:
        total = c.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
    pages = max(1, (total + PROD_PAGE - 1) // PROD_PAGE)
    page = min(max(page, 0), pages - 1)
    order = "position ASC, id ASC" if mode == "pos" else "id DESC"
    with db() as c:
        rows = c.execute(f"SELECT id, country, dial, price, sold, position FROM accounts ORDER BY {order} LIMIT ? OFFSET ?",
                         (PROD_PAGE, page * PROD_PAGE)).fetchall()
    title = "✏ <b>EDIT PRODUCT</b>" if mode == "edit" else "📍 <b>PRODUCT POSITION</b>"
    hint = "Product tap karo, uski details khulengi." if mode == "edit" else "Product tap karo, uski position set karo."
    text = f"{title}\n{'─'*22}\n{hint}\nID likh kar bhi chal sakta hai.\n\nTotal {total} · Page {page + 1}/{pages}"
    kb_rows = []
    for r in rows:
        dot = "🔴" if r["sold"] else "🟢"
        extra = f" · P{r['position']}" if mode == "pos" else ""
        cb = f"xadm:pe:{'show' if mode == 'edit' else 'pshow'}:{r['id']}"
        kb_rows.append([make_btn(f"{dot} #{r['id']} · {_flag(r['dial'] or '')} {r['country'] or '—'} · ₹{float(r['price']):.0f}{extra}", cb=cb, kind="nav", reg=False, plain=True)])
    nav = []
    if page > 0: nav.append(make_btn("◀ Prev", cb=f"xadm:pl:{mode}:{page - 1}", kind="nav", reg=False, plain=True))
    if page < pages - 1: nav.append(make_btn("Next ▶", cb=f"xadm:pl:{mode}:{page + 1}", kind="nav", reg=False, plain=True))
    if nav: kb_rows.append(nav)
    kb_rows.append([make_btn("⬅ Admin panel", cb="adm:home", kind="nav", reg=False, plain=True)])
    return text, InlineKeyboardMarkup(inline_keyboard=kb_rows)

@adm.callback_query(F.data == "xadm:pe:find")
async def ex_pe_find(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.ep_find); await state.update_data(ep_mode="edit")
    text, kb_ = _prod_list_view("edit", 0)
    await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data == "xadm:pe:posfind")
async def ex_pe_posfind(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    await state.set_state(Flow.ep_find); await state.update_data(ep_mode="pos")
    text, kb_ = _prod_list_view("pos", 0)
    await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data.startswith("xadm:pbc:"))
async def adm_pbc(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    try: acc_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError): return await cb.answer()
    eff = BTN_OVR.get(f"c:buy_{acc_id}", "success")
    row = [InlineKeyboardButton(text=name, callback_data=f"xadm:pbs:{acc_id}:{st}",
                                **({"style": st} if st != "none" else {})) for st, name in _CHOICES]
    rows = [row, [make_btn("⬅ Back", cb=f"xadm:pe:show:{acc_id}", kind="nav", reg=False, plain=True)]]
    await safe_edit(cb, f"🎨 <b>BUY BUTTON · #{acc_id}</b>\nAbhi: {dict(_CHOICES)[eff]}\n\nIs product ke Buy button ka colour chuno:",
                    InlineKeyboardMarkup(inline_keyboard=rows))
    await cb.answer()

@adm.callback_query(F.data.startswith("xadm:pbs:"))
async def adm_pbs(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":")
    if len(parts) != 4 or parts[3] not in dict(_CHOICES): return await cb.answer()
    acc_id, st = int(parts[2]), parts[3]
    xset(f"bc:c:buy_{acc_id}", st); _reload_btn_overrides()
    log_admin(cb.from_user.id, f"buy button colour #{acc_id} = {st}")
    card = product_card(acc_id)
    if not card: return await cb.answer("❌ Nahi mila", show_alert=True)
    await safe_edit(cb, card[0], card[1]); await cb.answer(f"✅ {dict(_CHOICES)[st]}")

@adm.callback_query(F.data.startswith("xadm:pl:"))
async def ex_pl_page(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":")
    if len(parts) != 4 or parts[2] not in ("edit", "pos") or not parts[3].lstrip("-").isdigit(): return await cb.answer()
    await state.set_state(Flow.ep_find); await state.update_data(ep_mode=parts[2])
    text, kb_ = _prod_list_view(parts[2], int(parts[3]))
    await safe_edit(cb, text, kb_); await cb.answer()

@adm.message(Flow.ep_find)
async def ex_pe_find_msg(msg: Message, state: FSMContext):
    if not has_perm(msg.from_user.id, "stock"): await state.clear(); return
    data = await state.get_data(); mode = data.get("ep_mode", "edit")
    txt = (msg.text or "").strip().lstrip("#")
    if not txt.isdigit(): return await msg.answer("Product ID (number) bhejo, ya /cancel.")
    acc_id = int(txt); card = product_card(acc_id)
    if not card: return await msg.answer("❌ Product nahi mila.")
    await state.clear()
    if mode == "pos":
        await state.set_state(Flow.ep_value); await state.update_data(ep_field="position", ep_id=acc_id)
        return await msg.answer(_premium_text(f"📍 Product #{acc_id} ki nayi position bhejo (number):"),
                                reply_markup=_kb([("Cancel", f"xadm:pe:show:{acc_id}", "danger")]), parse_mode=ParseMode.HTML)
    await msg.answer(_premium_text(card[0]), reply_markup=card[1], parse_mode=ParseMode.HTML)

@adm.callback_query(F.data.startswith("xadm:pe:"))
async def ex_pe_actions(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "stock"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":")
    if len(parts) != 4 or not parts[3].isdigit(): return await cb.answer()
    action, acc_id = parts[2], int(parts[3])
    if action in ("show", "pshow", "up", "down"):
        moved = None
        if action in ("up", "down"): moved = _move_product(acc_id, -1 if action == "up" else 1)
        back = "xadm:pl:pos:0" if action in ("pshow", "up", "down") else "xadm:pl:edit:0"
        card = product_card(acc_id, back=back)
        if not card: return await cb.answer("❌ Nahi mila", show_alert=True)
        await state.clear(); await safe_edit(cb, card[0], card[1])
        if moved is not None: return await cb.answer("✅ Moved" if moved else "Ye pehle ya aakhri position par hai")
        return await cb.answer()
    if action not in PRODUCT_FIELDS: return await cb.answer()
    await state.set_state(Flow.ep_value); await state.update_data(ep_field=action, ep_id=acc_id)
    await safe_edit(cb, f"✏ <b>Product #{acc_id}</b>\n{PRODUCT_FIELDS[action]}\nNayi value bhejo:",
                    _kb([("Cancel", f"xadm:pe:show:{acc_id}", "danger")]))
    await cb.answer()

@adm.message(Flow.ep_value)
async def ex_pe_value_msg(msg: Message, state: FSMContext):
    if not has_perm(msg.from_user.id, "stock"): await state.clear(); return
    data = await state.get_data(); field = data.get("ep_field"); acc_id = data.get("ep_id")
    if not field or not acc_id:
        await state.clear(); return await msg.answer("State lost, Edit Product se dobara try karo.")
    raw = (msg.text or "").strip()
    if field == "price":
        try:
            val = float(raw)
            if not math.isfinite(val) or val <= 0: raise ValueError
        except ValueError: return await msg.answer("Valid price (number > 0) bhejo, ya /cancel.")
        col, db_val = "price", val
    elif field == "position":
        if not re.fullmatch(r"-?\d{1,6}", raw): return await msg.answer("Position number bhejo (jaise 1, 2, 10), ya /cancel.")
        col, db_val = "position", int(raw)
    elif field == "origin":
        if not raw: return await msg.answer("Origin khali nahi ho sakta.")
        col, db_val = "origin", raw
    elif field == "type":
        if not raw: return await msg.answer("Type khali nahi ho sakta.")
        col, db_val = "type", raw
    elif field == "twofa":
        col, db_val = "twofa_pass", ("" if raw.lower() == "none" else raw)
    else:
        await state.clear(); return await msg.answer("Unknown field.")
    with db() as c:
        cur = c.execute(f"UPDATE accounts SET {col}=? WHERE id=?", (db_val, acc_id))
        if field == "twofa": c.execute("UPDATE accounts SET twofa=? WHERE id=?", (1 if db_val else 0, acc_id))
    await state.clear()
    if cur.rowcount == 0: return await msg.answer("❌ Product nahi mila.")
    log_admin(msg.from_user.id, f"product #{acc_id} {field}")
    card = product_card(acc_id)
    await msg.answer(_premium_text("✅ <b>Updated</b>\n" + card[0]), reply_markup=card[1], parse_mode=ParseMode.HTML)

@adm.callback_query(F.data == "xadm:wspoil_home")
async def ex_wspoil_home(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    new = "0" if xget("welcome_spoiler", "1") == "1" else "1"; xset("welcome_spoiler", new)
    log_admin(cb.from_user.id, f"welcome spoiler={new}")
    await safe_edit(cb, dashboard_text(), adm_home_kb(cb.from_user.id))
    await cb.answer(f"Welcome spoiler {'ON' if new == '1' else 'OFF'}")

BTN_PAGE = 10
_CHOICES = [("success", "🟢 Green"), ("primary", "🔵 Blue"), ("danger", "🔴 Red"), ("none", "⚪ Default")]

def _find_btn(h):
    for k, e in BTN_REG.items():
        if e["h"] == h: return k, e
    return None, None

# ── Every static button of the bot (menu + admin), so the Button Colours list shows them all ──
_MENU_INV = [
    ("show_shop", "Let's Start 🤕", "action"), ("tos_accept", "I ACCEPT", "danger"),
    ("main", "🏠 Main menu", "nav"), ("browse", "Browse Accounts", "success"),
    ("wallet", "💰 Wallet", "primary"), ("myorders", "📦 My orders", "primary"),
    ("profile", "Profile", "primary"), ("terms", "Terms of Service", "primary"),
    ("srv_1", "🟢 Server 1 · Budget", "action"), ("srv_2", "🔵 Server 2 · Premium", "action"),
    ("bulk", "🎲 Bulk buy", "nav"), ("search_country", "🔍 Search", "nav"),
    ("bulkpick_1", "🟢 Server 1", "action"), ("bulkpick_2", "🔵 Server 2", "action"),
    ("agree_1", "✅ I agree", "action"), ("txns", "🧾 Transactions", "nav"),
    ("addfunds", "➕ Add funds", "action"), ("dep_upi", "UPI", "action"),
    ("dep_crypto", "Crypto", "action"), ("dep_stars", "Telegram Stars", "action"),
    ("fj:verify", "✅ Verify", "action"), ("referral", "🤝 Refer & Earn", "primary"),
    ("mcap_0", "Captcha 1", "nav"), ("mcap_1", "Captcha 2", "nav"), ("mcap_2", "Captcha 3", "nav"), ("mcap_3", "Captcha 4", "nav"),
]
for _srv in (1, 2):
    _MENU_INV.append((f"filters_{_srv}", "Filters", "nav"))
    for _a, _l in [("spam", "Spam"), ("prem", "Premium"), ("twofa", "2FA"), ("email", "Email"),
                   ("origin", "Origin"), ("sort", "Sort"), ("apply", "✅ Apply"), ("reset", "♻ Reset")]:
        _MENU_INV.append((f"flt_{_srv}_{_a}", _l, "action" if _a == "apply" else "nav"))
for _m in ("upi", "crypto", "stars"):
    for _amt in (50, 100, 200, 500, 1000):
        _MENU_INV.append((f"amt_{_m}_{_amt}", f"₹{_amt}", "nav"))
    _MENU_INV.append((f"amt_{_m}_custom", "✏ Custom", "action"))

_ADM_INV = [
    ("adm:home", "⬅ Admin panel", "nav"), ("adm:stats", "📊 Dashboard", "nav"), ("adm:stock", "📦 Stock", "nav"),
    ("adm:users", "👥 Users", "nav"), ("adm:deps", "💳 Deposits", "nav"), ("adm:settings", "⚙️ Settings", "nav"),
    ("adm:system", "🩺 System", "nav"), ("adm:tlogin", "📲 Telethon Login", "action"),
    ("adm:ac_start", "➕ Add Account", "action"), ("adm:ac_src:tl", "📲 Telethon login", "action"),
    ("adm:ac_src:paste", "📋 Session paste", "nav"), ("adm:acback", "⬅ Back", "nav"),
    ("adm:import", "📥 Import TXT", "action"), ("adm:find_order", "🧾 Find Order", "nav"),
    ("adm:find_user", "🔎 Find User", "nav"), ("adm:addbal", "➕ Add Balance", "action"),
    ("adm:cutbal", "➖ Cut Balance", "danger"), ("adm:addadmin", "➕ Add admin", "action"),
    ("adm:bcast", "📢 Broadcast", "nav"), ("adm:export", "📤 Export CSV", "action"),
    ("adm:backup", "💾 Backup DB", "action"), ("adm:audit", "📋 Audit Log", "nav"),
    ("adm:salephoto", "🖼 Sale Photo", "action"), ("adm:apiconfig", "🔑 API Config", "nav"),
    ("adm:set_api_id", "Set API ID", "nav"), ("adm:set_api_hash", "Set API HASH", "nav"),
    ("adm:set:crypto_address", "Crypto Addr ✏", "nav"), ("adm:set:crypto_coin", "Crypto Coin", "nav"),
    ("adm:set:max_deposit", "Max ✏", "nav"), ("adm:set:min_deposit", "Min ✏", "nav"),
    ("adm:set:otp_admin_id", "🆔 Set User ID", "nav"), ("adm:set:otp_admin_link", "🔗 OTP Admin Link", "nav"),
    ("adm:set:sales_link", "📢 Sales link ✏", "nav"), ("adm:set:stars_rate", "Stars rate ✏", "nav"),
    ("adm:set:tl_price", "📱 TL Price ✏", "nav"), ("adm:set:tos_owner", "👑 TOS Owner Set", "nav"),
    ("adm:set:warranty_hours", "Warranty ✏", "nav"), ("adm:set:welcome_dev", "🥰 Set Dev Name", "nav"),
    ("adm:set:welcome_text", "Welcome ✏", "nav"),
    ("xadm:v_toggle:contact", "📱 Share Contact", "action"), ("xadm:v_toggle:math", "🧩 Emoji captcha", "action"),
    ("xadm:sharecontact", "📱 Share Contact", "action"), ("xadm:wspoil_home", "✨ Welcome Spoiler", "nav"),
    ("xadm:wmedia", "🖼 Welcome media", "action"), ("xadm:wdel", "🗑 Remove media", "danger"),
    ("xadm:mtoggle:t", "🛠 Maintenance", "action"), ("xadm:tools", "🧰 Tools", "nav"), ("xadm:top", "🏆 Top Buyers", "nav"),
    ("xadm:src", "📦 Export Bot Src", "nav"), ("xadm:vd:0", "🪪 Verification data", "action"),
    ("xadm:vdcsv", "⬇ CSV export", "action"), ("xadm:coupons", "🏷 Coupons", "nav"), ("xadm:admins", "👥 Admins", "nav"),
    ("xadm:emoji", "😀 Emoji IDs", "nav"), ("xadm:emj", "➕ Other emoji", "action"),
    ("xadm:fch", "📢 Force-join channels", "nav"), ("xadm:fchadd", "➕ Add channel", "action"),
    ("xadm:pe:find", "✏ Edit Product", "action"), ("xadm:pe:posfind", "📍 Product Position", "action"),
    ("xadm:qr:upi", "💳 UPI QR ✏", "action"), ("xadm:qr:crypto", "🔑 Crypto QR ✏", "action"),
    ("xadm:eidlk", "🔎 ID lookup", "nav"), ("xadm:elink", "🔗 Link → IDs", "nav"), ("xadm:cancel", "❌ Cancel", "danger"),
    ("xadm:bc:adm:0", "🎨 Button Colours", "nav"),
]

def _register_inventory():
    kind_to_style = {"action": "success", "danger": "danger"}
    for cb, label, kind in _MENU_INV + _ADM_INV:
        _reg_btn(_btn_key(cb, None), label, cb, kind_to_style.get(kind, "primary"))
    for url, label in ((_sales_url(), "Sales"), (cfg_support(), "Support")):
        if url: _reg_btn(_btn_key(None, url), label, None, "primary")

def _bc_list_view(grp, page=0):
    items = [(k, e) for k, e in BTN_REG.items() if e["grp"] == grp]
    items.sort(key=lambda kv: (re.sub(r"[^a-z0-9]", "", kv[1]["label"].lower()) or kv[1]["label"].lower()))
    pages = max(1, (len(items) + BTN_PAGE - 1) // BTN_PAGE)
    page = min(max(page, 0), pages - 1)
    kb_rows = []
    for k, e in items[page * BTN_PAGE:(page + 1) * BTN_PAGE]:
        eff = _eff_style(k, e)
        style = {"style": eff} if eff != "none" else {}
        kb_rows.append([InlineKeyboardButton(text=e["label"] or " ", callback_data=f"xadm:bp:{e['h']}:{grp}:{page}", **style)])
    nav = []
    if page > 0: nav.append(make_btn("◀ Prev", cb=f"xadm:bc:{grp}:{page - 1}", kind="nav", reg=False, plain=True))
    if page < pages - 1: nav.append(make_btn("Next ▶", cb=f"xadm:bc:{grp}:{page + 1}", kind="nav", reg=False, plain=True))
    if nav: kb_rows.append(nav)
    kb_rows.append([make_btn("👤 Menu buttons", cb="xadm:bc:menu:0", kind="nav", reg=False, plain=True),
                    make_btn("🛠 Admin buttons", cb="xadm:bc:adm:0", kind="nav", reg=False, plain=True)])
    kb_rows.append([make_btn("⬅ Admin panel", cb="adm:home", kind="nav", reg=False, plain=True)])
    title = "👤 MENU BUTTONS" if grp == "menu" else "🛠 ADMIN BUTTONS"
    text = (f"🎨 <b>BUTTON COLOURS · {title}</b>\n{'─'*22}\n"
            "Kisi button par tap karo, phir colour chuno.\n\n"
            f"A to Z · Page {page + 1}/{pages} · Total {len(items)}")
    return text, InlineKeyboardMarkup(inline_keyboard=kb_rows)

@adm.callback_query(F.data.startswith("xadm:bc:"))
async def adm_bc_list(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":")
    grp = parts[2] if len(parts) > 2 and parts[2] in ("menu", "adm") else "menu"
    page = int(parts[3]) if len(parts) > 3 and parts[3].lstrip("-").isdigit() else 0
    text, kb_ = _bc_list_view(grp, page)
    await safe_edit(cb, text, kb_); await cb.answer()

def _eff_style(k, e):
    eff = BTN_OVR.get(k, e["dflt"])
    return eff if eff in ("success", "primary", "danger", "none") else "primary"

def _bc_picker(k, e, grp, page):
    eff = _eff_style(k, e)
    row = [InlineKeyboardButton(text=name, callback_data=f"xadm:bs:{e['h']}:{st}:{grp}:{page}",
                                **({"style": st} if st != "none" else {})) for st, name in _CHOICES]
    rows = [row, [make_btn("⬅ Back", cb=f"xadm:bc:{grp}:{page}", kind="nav", reg=False, plain=True)]]
    text = f"🎨 <b>{esc(e['label'])}</b>\nAbhi: {dict(_CHOICES)[eff]}\n\nIs button ka naya colour chuno:"
    return text, InlineKeyboardMarkup(inline_keyboard=rows)

@adm.callback_query(F.data.startswith("xadm:bp:"))
async def adm_bc_pick(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":")
    if len(parts) < 3: return await cb.answer()
    k, e = _find_btn(parts[2])
    if not k: return await cb.answer("❌ Button nahi mila", show_alert=True)
    grp = parts[3] if len(parts) > 3 and parts[3] in ("menu", "adm") else e["grp"]
    page = int(parts[4]) if len(parts) > 4 and parts[4].lstrip("-").isdigit() else 0
    text, kb_ = _bc_picker(k, e, grp, page)
    await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data.startswith("xadm:bs:"))
async def adm_bc_set(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    parts = cb.data.split(":")
    if len(parts) != 6: return await cb.answer()
    k, e = _find_btn(parts[2]); st = parts[3]
    if not k or st not in dict(_CHOICES): return await cb.answer("❌", show_alert=True)
    grp = parts[4] if parts[4] in ("menu", "adm") else e["grp"]
    page = int(parts[5]) if parts[5].lstrip("-").isdigit() else 0
    xset(f"bc:{k}", st); _reload_btn_overrides()
    log_admin(cb.from_user.id, f"btn colour {k} = {st}")
    text, kb_ = _bc_list_view(grp, page)
    await safe_edit(cb, text, kb_); await cb.answer(f"✅ {dict(_CHOICES)[st]}")

def _warm_btn_registry():
    """Register all known bot buttons, then build the main keyboards once so dynamic ones are listed too."""
    _register_inventory()
    calls = [
        lambda: main_menu_kb(SUPERADMIN_ID or None), lambda: start_btn_kb(0), lambda: tos_accept_kb(),
        lambda: wallet_kb(), lambda: profile_kb(), lambda: server_kb(), lambda: bulk_pick_kb(),
        lambda: addfunds_kb(), lambda: amount_kb("upi"), lambda: amount_kb("crypto"),
        lambda: low_balance_kb(), lambda: after_buy_kb(), lambda: terms_kb(0),
        lambda: agree_kb("agree_1", "browse"), lambda: filter_kb(1, {}),
        lambda: _tools_view(), lambda: settings_view(), lambda: _emoji_list_view(0), lambda: stock_view(),
    ]
    if SUPERADMIN_ID: calls.append(lambda: adm_home_kb(SUPERADMIN_ID))
    for f in calls:
        try: f()
        except Exception as e: log.warning("button registry warm-up: %s", e)

VD_PAGE = 8

def _vdata_rows():
    with db() as c:
        phones = c.execute("SELECT k, v FROM extras_kv WHERE k LIKE 'phone:%'").fetchall()
        out = []
        for r in phones:
            tail = r["k"].split(":", 1)[1]
            if not tail.isdigit(): continue
            uid = int(tail)
            u = c.execute("SELECT username, name FROM users WHERE user_id=?", (uid,)).fetchone()
            vt = c.execute("SELECT v FROM extras_kv WHERE k=?", (f"vtime:{uid}",)).fetchone()
            out.append({"uid": uid, "phone": r["v"] or "", "name": (u["name"] if u else "") or "",
                        "username": (u["username"] if u else "") or "", "vtime": (vt["v"] if vt else "") or ""})
    out.sort(key=lambda x: x["vtime"], reverse=True)
    return out

def _vdata_view(page=0):
    rows = _vdata_rows()
    pages = max(1, (len(rows) + VD_PAGE - 1) // VD_PAGE)
    page = min(max(page, 0), pages - 1)
    lines = []
    for x in rows[page * VD_PAGE:(page + 1) * VD_PAGE]:
        uname = f"@{x['username']}" if x["username"] else "—"
        lines.append(f"<b>#{x['uid']}</b> · {esc(x['name'] or '—')} · {esc(uname)}\n📞 <code>{esc(x['phone'] or '—')}</code> · {esc(x['vtime'] or '—')}")
    body = "\n\n".join(lines) if lines else "Abhi koi verified contact nahi hai."
    text = f"🪪 <b>VERIFICATION DATA</b>\n{'─'*22}\nTotal: {len(rows)} · Page {page + 1}/{pages}\n\n{body}"
    kb_rows = []
    nav = []
    if page > 0: nav.append(make_btn("◀ Prev", cb=f"xadm:vd:{page - 1}", kind="nav", reg=False, plain=True))
    if page < pages - 1: nav.append(make_btn("Next ▶", cb=f"xadm:vd:{page + 1}", kind="nav", reg=False, plain=True))
    if nav: kb_rows.append(nav)
    kb_rows.append([make_btn("⬇ CSV export", cb="xadm:vdcsv", kind="action", reg=False, plain=True)])
    kb_rows.append([make_btn("⬅ Tools", cb="xadm:tools", kind="nav", reg=False, plain=True)])
    return text, InlineKeyboardMarkup(inline_keyboard=kb_rows)

@adm.callback_query(F.data.startswith("xadm:vd:"))
async def adm_vd_page(cb: CallbackQuery, state: FSMContext):
    if not can_tools(cb.from_user.id): return await cb.answer("❌", show_alert=True)
    try: page = int(cb.data.split(":")[2])
    except ValueError: page = 0
    text, kb_ = _vdata_view(page)
    await safe_edit(cb, text, kb_); await cb.answer()

@adm.callback_query(F.data == "xadm:vdcsv")
async def adm_vd_csv(cb: CallbackQuery, state: FSMContext):
    if not can_tools(cb.from_user.id): return await cb.answer("❌", show_alert=True)
    rows = _vdata_rows()
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["user_id", "name", "username", "phone", "verified_at"])
    for x in rows: w.writerow([x["uid"], x["name"], x["username"], x["phone"], x["vtime"]])
    await cb.message.answer_document(BufferedInputFile(buf.getvalue().encode("utf-8-sig"), filename="verification_data.csv"),
                                     caption=f"🪪 Verification data · {len(rows)} users")
    await cb.answer()

# ── tools shortcuts ──
@adm.callback_query(F.data == "adm:export")
async def adm_export(cb: CallbackQuery):
    header = ["order_code","created_at","user_id","price","status","server","country","dial","type","origin"]
    with db() as c: rows = c.execute("SELECT o.order_code, o.created_at, o.user_id, o.price, o.status, a.server, a.country, a.dial, a.type, a.origin FROM orders o LEFT JOIN accounts a ON a.id=o.account_id ORDER BY o.id").fetchall()
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(header)
    for r in rows: w.writerow([r[k] for k in header])
    await cb.message.answer_document(BufferedInputFile(buf.getvalue().encode("utf-8-sig"), filename=f"sales_{datetime.now():%Y%m%d_%H%M}.csv"), caption=f"📤 {len(rows)} orders"); await cb.answer()
@adm.callback_query(F.data == "adm:backup")
async def adm_backup(cb: CallbackQuery):
    if not can_tools(cb.from_user.id): return await cb.answer("❌", show_alert=True)
    try:
        with open(DB_PATH, "rb") as f: await cb.message.answer_document(BufferedInputFile(f.read(), filename=f"backup_{datetime.now():%Y%m%d_%H%M}.db"), caption="💾 DB backup")
        log_admin(cb.from_user.id, "db backup"); await cb.answer("✅")
    except Exception as e: await cb.answer(f"❌ {e}", show_alert=True)
@adm.callback_query(F.data == "adm:audit")
async def adm_audit(cb: CallbackQuery):
    if not can_tools(cb.from_user.id): return await cb.answer("❌", show_alert=True)
    with db() as c: rows = c.execute("SELECT admin_id, action, ts FROM admin_log ORDER BY id DESC LIMIT 20").fetchall()
    if not rows: return await safe_edit(cb, "📋 <b>AUDIT</b>\n\nEmpty.", _kb([("Back", "adm:home")]))
    lines = [f"<code>{r['admin_id']}</code> · {esc(r['action'])} · {(r['ts'] or '')[:16]}" for r in rows]
    await safe_edit(cb, "📋 <b>AUDIT · latest 20</b>\n\n" + "\n".join(lines), _kb([("Back", "adm:home")])); await cb.answer()

# ── system ──
@adm.callback_query(F.data == "adm:system")
async def adm_system(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    size = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0; up = str(datetime.now() - START_TIME).split(".")[0]
    _u = cfg_upi(); upi = (_u[:3] + "•••" + _u[-4:]) if len(_u) > 8 else "•••"
    photo = get_setting("sale_photo"); p_ok = bool(photo) and os.path.exists(photo)
    api_ok = bool(get_setting("api_id") and get_setting("api_hash")); cryp = bool(get_setting("crypto_address"))
    c = BTN_COLOURS
    text = (f"🩺 <b>SYSTEM</b>\nUptime: {up}\nDB: {size/1024:.1f} KB\nSales ch.: {cfg_sales_channel() or 'off'}\nUPI: <code>{esc(upi)}</code>\n"
            f"Bulk max: {BULK_MAX}  TTL: {DEPOSIT_TTL_MIN}m\nSale photo: {'✅' if p_ok else '❌'}\n"
            f"Telethon: {'✅' if api_ok else '❌'}\nCrypto: {'✅' if cryp else '❌'}\n"
            f"Buttons: action={_STYLE_NAMES[c['action']]} · nav={_STYLE_NAMES[c['nav']]} · danger={_STYLE_NAMES[c['danger']]}")
    await safe_edit(cb, text, _kb([("Refresh", "adm:system", "nav"), ("Back", "adm:home")])); await cb.answer()

# ── telethon helpers ──
async def tl_request_otp(phone, session_string=""):
    api_id_str = get_setting("api_id", ""); api_hash = get_setting("api_hash", "")
    if not api_id_str or not api_hash: return {"success": False, "error": "API missing"}
    client = None
    try:
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        client = TelegramClient(StringSession(session_string), int(api_id_str), api_hash)
        await client.connect()
        result = await client.send_code_request(phone)
        return {"success": True, "phone_code_hash": result.phone_code_hash, "session": client.session.save()}
    except Exception as e:
        return {"success": False, "error": str(e)}
    finally:
        if client is not None:
            try: await client.disconnect()
            except Exception: pass

async def tl_sign_in(phone, code, phone_code_hash, session_str, password=""):
    api_id_str = get_setting("api_id", ""); api_hash = get_setting("api_hash", "")
    client = None
    try:
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        from telethon.errors import SessionPasswordNeededError
        client = TelegramClient(StringSession(session_str), int(api_id_str), api_hash)
        await client.connect()
        if password and not code:
            # 2FA step: the login code was already accepted, only the cloud password is needed
            await client.sign_in(password=password)
        else:
            try:
                await client.sign_in(phone, code, phone_code_hash=phone_code_hash)
            except SessionPasswordNeededError:
                if not password: return {"success": False, "needs_2fa": True}
                await client.sign_in(password=password)
        final = client.session.save(); me = await client.get_me()
        return {"success": True, "session": final, "phone": f"+{me.phone}" if me.phone else phone,
                "name": f"{me.first_name or ''} {me.last_name or ''}".strip()}
    except Exception as e:
        return {"success": False, "error": str(e)}
    finally:
        if client is not None:
            try: await client.disconnect()
            except Exception: pass

# ══════════════════════════════════════════════════════════
#   FORCE-JOIN + welcome callbacks (xadm:*)
# ══════════════════════════════════════════════════════════
@adm.callback_query(F.data == "xadm:wmedia")
async def ex_wmedia(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    await state.set_state(ExFlow.welcome_wait)
    await safe_edit(cb, "🖼 Welcome photo/video/GIF bhejo.\n/cancel se band.", _kb([("Cancel", "xadm:cancel", "nav")])); await cb.answer()
@adm.message(ExFlow.welcome_wait)
async def ex_welcome_msg(msg: Message, state: FSMContext):
    if (msg.text or "").strip() == "/cancel": await state.clear(); return await msg.answer("❌ Cancel.")
    if not has_perm(msg.from_user.id, "settings"): await state.clear(); return
    kind, fid = _media_of(msg)
    if not kind: return await msg.answer("Photo, video ya GIF bhejo, ya /cancel.")
    xset("welcome_media", fid); xset("welcome_type", kind); log_admin(msg.from_user.id, f"welcome media {kind}")
    await state.clear(); await msg.answer(f"✅ Welcome {kind} saved.")
@adm.callback_query(F.data.startswith("xadm:qr:"))
async def ex_qr_pick(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    method = cb.data.split(":")[2]
    if method not in ("upi", "crypto"): return await cb.answer()
    await state.set_state(ExFlow.qr_wait); await state.update_data(qr_method=method)
    cur = "✅ set" if xget(f"qr_{method}") else "❌ not set"
    await safe_edit(cb,
        f"🖼 <b>{method.upper()} SCANNER</b>\nCurrent: {cur}\n\n"
        "Scanner ka photo bhejo. Ye har payment message mein photo ke saath jayega.\n\n"
        "<i>Hatane ke liye <code>remove</code> likho. /cancel se band.</i>",
        _kb([("Cancel", "adm:settings", "danger")]))
    await cb.answer()

@adm.message(ExFlow.qr_wait)
async def ex_qr_msg(msg: Message, state: FSMContext):
    if not has_perm(msg.from_user.id, "settings"): await state.clear(); return
    txt = (msg.text or "").strip().lower()
    if txt == "/cancel": await state.clear(); return await msg.answer("❌ Cancel.")
    method = (await state.get_data()).get("qr_method", "upi")
    if txt == "remove":
        xset(f"qr_{method}", ""); result = "removed"
    elif msg.photo:
        xset(f"qr_{method}", msg.photo[-1].file_id); result = "saved"
    else:
        return await msg.answer("Photo bhejo, ya <code>remove</code>, ya /cancel.", parse_mode=ParseMode.HTML)
    await state.clear(); log_admin(msg.from_user.id, f"{method} qr {result}")
    await msg.answer(f"✅ {method.upper()} scanner {result}.", reply_markup=_kb([("Settings", "adm:settings", "nav")]))

@adm.callback_query(F.data == "xadm:cancel")
async def ex_cancel(cb: CallbackQuery, state: FSMContext):
    await state.clear(); text, kb_ = settings_view(); await safe_edit(cb, text, kb_); await cb.answer()
@adm.callback_query(F.data == "xadm:wdel")
async def ex_wdel(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    with db() as c: c.execute("DELETE FROM extras_kv WHERE k IN ('welcome_media','welcome_type')")
    log_admin(cb.from_user.id, "welcome media removed")
    text, kb_ = settings_view(); await safe_edit(cb, text, kb_); await cb.answer("🗑")
@adm.callback_query(F.data == "xadm:wspoil")
async def ex_wspoil(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    new = "0" if xget("welcome_spoiler", "1") == "1" else "1"; xset("welcome_spoiler", new)
    log_admin(cb.from_user.id, f"welcome spoiler={new}")
    text, kb_ = settings_view(); await safe_edit(cb, text, kb_); await cb.answer(f"Spoiler {'ON' if new=='1' else 'OFF'}")
@adm.callback_query(F.data.startswith("xadm:mtoggle:"))
async def ex_mtoggle(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    origin = cb.data.split(":")[2]; new = "0" if xget("maintenance") == "1" else "1"; xset("maintenance", new)
    log_admin(cb.from_user.id, f"maintenance={new}")
    if origin == "t": text, kb_ = _tools_view()
    else: text, kb_ = settings_view()
    await safe_edit(cb, text, kb_); await cb.answer(f"Maintenance {'ON' if new=='1' else 'OFF'}")

@adm.callback_query(F.data == "xadm:fch")
async def ex_fch(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    with db() as c: rows = c.execute("SELECT chat_id,title,is_private FROM fchannels ORDER BY ts").fetchall()
    lines = ["📢 <b>Force-join channels</b>\n"]; kbrows = []
    for r in rows:
        lines.append(f"• {html.escape(r['title'] or '')} · <code>{r['chat_id']}</code>")
        kbrows.append([("🗑 " + (r['title'] or r['chat_id']), f"xadm:fchdel:{r['chat_id']}", "danger")])
    if not rows: lines.append("Koi nahi.")
    kbrows.append([("➕ Add channel", "xadm:fchadd", "action")]); kbrows.append([("Settings", "adm:settings", "nav")])
    await safe_edit(cb, "\n".join(lines), xkb(*kbrows)); await cb.answer()
@adm.callback_query(F.data == "xadm:fchadd")
async def ex_fchadd_prompt(cb: CallbackQuery, state: FSMContext):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    await state.set_state(ExFlow.fch_wait)
    await safe_edit(cb, "➕ <b>Add channel</b>\n\n<code>@username</code> or <code>-100…</code>", _kb([("Cancel", "xadm:fch", "nav")])); await cb.answer()
@adm.message(ExFlow.fch_wait)
async def ex_fchadd_msg(msg: Message, state: FSMContext):
    if (msg.text or "").strip() == "/cancel": await state.clear(); return await msg.answer("❌ Cancel.")
    if not has_perm(msg.from_user.id, "settings"): await state.clear(); return
    target = (msg.text or "").strip()
    try:
        chat = await msg.bot.get_chat(_chat_ref(target))
        me = await msg.bot.get_chat_member(chat.id, msg.bot.id)
        if me.status not in ("administrator", "creator"): return await msg.answer("❌ Bot ko admin banao.")
        if chat.username: invite, priv = f"https://t.me/{chat.username}", 0
        else:
            link = await msg.bot.create_chat_invite_link(chat.id, creates_join_request=True, name="Force-join")
            invite, priv = link.invite_link, 1
    except Exception as e: return await msg.answer(f"❌ {e}\n/cancel")
    with db() as c:
        c.execute("INSERT OR REPLACE INTO fchannels(chat_id,title,is_private,invite_url,ts) VALUES(?,?,?,?,?)",
                  (str(chat.id), chat.title or target, priv, invite, time.time()))
    log_admin(msg.from_user.id, f"force channel added {chat.id}")
    await state.clear(); await msg.answer(f"✅ Added <b>{html.escape(chat.title or target)}</b>.", parse_mode=ParseMode.HTML)
@adm.callback_query(F.data.startswith("xadm:fchdel:"))
async def ex_fchdel(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "settings"): return await cb.answer("❌", show_alert=True)
    cid = cb.data.split(":", 2)[2]
    with db() as c: c.execute("DELETE FROM fchannels WHERE chat_id=?", (cid,))
    log_admin(cb.from_user.id, f"force channel removed {cid}")
    await ex_fch(cb)

# ── tools ──
def _tools_view():
    mt = "ON" if xget("maintenance") == "1" else "OFF"
    text = f"🧰 <b>Tools</b>\n\n🛠 Maintenance: <b>{mt}</b>"
    kb_ = xkb(
        [xbtn("💾 Backup DB", "adm:backup", "action"), xbtn("📤 Export CSV", "adm:export", "action")],
        [xbtn("🪪 Verification data", "xadm:vd:0", "action")],
        [xbtn("📋 Audit Log", "adm:audit", "nav"), xbtn("🏆 Top Buyers", "xadm:top", "nav")],
        [xbtn("🛠 Maintenance", "xadm:mtoggle:t", "action")],
        [xbtn("📦 Export Bot Src", "xadm:src", "action")],
        [xbtn("⬅ Panel", "adm:home", "nav")])
    return text, kb_
@adm.callback_query(F.data == "xadm:tools")
async def ex_tools(cb: CallbackQuery):
    if not can_tools(cb.from_user.id): return await cb.answer("❌", show_alert=True)
    text, kb_ = _tools_view(); await safe_edit(cb, text, kb_); await cb.answer()
@adm.callback_query(F.data == "xadm:top")
async def ex_top(cb: CallbackQuery):
    if not can_tools(cb.from_user.id): return await cb.answer("❌", show_alert=True)
    with db() as c: rows = c.execute("SELECT o.user_id, u.name, COUNT(*) AS n, SUM(o.price) AS s FROM orders o LEFT JOIN users u ON u.user_id=o.user_id WHERE o.status='delivered' GROUP BY o.user_id ORDER BY s DESC LIMIT 10").fetchall()
    lines = ["🏆 <b>Top buyers</b>\n"]
    for i, r in enumerate(rows, 1):
        name = r["name"] or str(r["user_id"]); lines.append(f"{i}. {html.escape(name)} · {r['n']} orders · {_money(r['s'])}")
    if not rows: lines.append("Koi order nahi.")
    await safe_edit(cb, "\n".join(lines), xkb([xbtn("🧰 Tools", "xadm:tools", "nav")])); await cb.answer()
@adm.callback_query(F.data == "xadm:src")
async def ex_src(cb: CallbackQuery):
    if cb.from_user.id != SUPERADMIN_ID: return await cb.answer("Sirf superadmin.", show_alert=True)
    with open(__file__, "rb") as f: data = f.read()
    await cb.message.answer_document(BufferedInputFile(data, filename="smartstore.py"), caption="📦 Bot source")
    log_admin(cb.from_user.id, "export src"); await cb.answer()

# ── coupons ──
@adm.callback_query(F.data == "xadm:coupons")
async def ex_coupons(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "coupons"): return await cb.answer("❌", show_alert=True)
    with db() as c: rows = c.execute("SELECT code,pct,uses_left FROM pct_coupons ORDER BY created_at DESC LIMIT 10").fetchall()
    lines = ["🏷 <b>Coupons</b>\n"]
    for r in rows: lines.append(f"<code>{r['code']}</code> · {r['pct']}% · {r['uses_left']} left")
    if not rows: lines.append("Koi nahi.")
    lines.append("\nBanao: <code>/mkcoupon CODE PCT USES</code>")
    await safe_edit(cb, "\n".join(lines), xkb([xbtn("⬅ Panel", "adm:home", "nav")])); await cb.answer()
@router.message(Command("mkcoupon"))
async def cmd_mkcoupon(msg: Message):
    if not has_perm(msg.from_user.id, "coupons"): return
    parts = (msg.text or "").split()
    if (len(parts) != 4 or not re.fullmatch(r"[A-Za-z0-9_]{3,20}", parts[1])
            or not parts[2].isdigit() or not (1 <= int(parts[2]) <= 100)
            or not parts[3].isdigit() or int(parts[3]) < 1):
        return await msg.answer("Use: /mkcoupon CODE PCT USES")
    code = parts[1].upper()
    try:
        with db() as c: c.execute("INSERT INTO pct_coupons(code,pct,uses_left,created_at) VALUES(?,?,?,?)", (code, int(parts[2]), int(parts[3]), time.time()))
    except sqlite3.IntegrityError: return await msg.answer("Code exists.")
    log_admin(msg.from_user.id, f"coupon {code}")
    await msg.answer(f"🏷 Coupon <code>{code}</code>: {parts[2]}% · {parts[3]} uses.", parse_mode=ParseMode.HTML)
@router.message(Command("coupon"))
async def cmd_coupon(msg: Message):
    parts = (msg.text or "").split()
    if len(parts) != 2: return await msg.answer("Use: /coupon CODE")
    code = parts[1].upper()
    with db() as c: r = c.execute("SELECT pct,uses_left FROM pct_coupons WHERE code=?", (code,)).fetchone()
    if not r or r["uses_left"] <= 0: return await msg.answer("❌ Invalid.")
    xset(f"cp:{msg.from_user.id}", code)
    await msg.answer(f"🏷 Coupon <b>{code}</b> apply: {r['pct']}% off.", parse_mode=ParseMode.HTML)
def discounted_price(uid, price):
    code = xget(f"cp:{uid}", "")
    if not code: return price
    with db() as c: r = c.execute("SELECT pct,uses_left FROM pct_coupons WHERE code=?", (code,)).fetchone()
    if not r or r["uses_left"] <= 0: return price
    return round(price * (100 - r["pct"]) / 100, 2)
def consume_coupon(uid):
    code = xget(f"cp:{uid}", "")
    if not code: return
    with db() as c: c.execute("UPDATE pct_coupons SET uses_left=uses_left-1 WHERE code=? AND uses_left>0", (code,))
    xset(f"cp:{uid}", "")

# ── admin perms ──
def _perm_view(uid):
    with db() as c: r = c.execute("SELECT role FROM admins WHERE user_id=?", (uid,)).fetchone()
    if not r: return ("ℹ️ ADMIN_IDS.", xkb([xbtn("🔙 Admins", "xadm:admins", "nav")]))
    if r["role"] != "custom":
        return (f"👤 <code>{uid}</code>\nRole: {ROLES.get(r['role'], r['role'])}\n\nCustom karo to toggle.", 
                xkb([xbtn("🧩 Custom", f"xadm:tocustom:{uid}", "action")], [xbtn("🔙 Admins", "xadm:admins", "nav")]))
    have = admin_perms(uid)
    rows = [[xbtn(f"{'✅' if k in have else '⬜'} {PERM_LABELS[k]}", f"xadm:tog:{uid}:{k}", "action" if k in have else "nav")] for k in PERM_KEYS]
    rows.append([xbtn("🔙 Admins", "xadm:admins", "nav")])
    return f"🧩 <b>Perms — <code>{uid}</code></b>", xkb(*rows)
@adm.callback_query(F.data == "xadm:admins")
async def ex_admins(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    with db() as c: rows = c.execute("SELECT user_id, role FROM admins ORDER BY added_at DESC").fetchall()
    kb_rows = [[xbtn(f"{r['user_id']} · {ROLES.get(r['role'], r['role'])}", f"xadm:perm:{r['user_id']}", "nav")] for r in rows]
    kb_rows.append([xbtn("➕ Add admin", "adm:addadmin", "action")]); kb_rows.append([xbtn("⬅ Panel", "adm:home", "nav")])
    await safe_edit(cb, "🧩 <b>Admins</b>", xkb(*kb_rows)); await cb.answer()
@adm.callback_query(F.data.startswith("xadm:perm:"))
async def ex_perm_view(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    text, kb_ = _perm_view(int(cb.data.split(":")[2])); await safe_edit(cb, text, kb_); await cb.answer()
@adm.callback_query(F.data.startswith("xadm:tocustom:"))
async def ex_tocustom(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    uid = int(cb.data.split(":")[2])
    with db() as c: c.execute("UPDATE admins SET role='custom', perms='' WHERE user_id=?", (uid,))
    log_admin(cb.from_user.id, f"admin {uid} custom")
    text, kb_ = _perm_view(uid); await safe_edit(cb, text, kb_); await cb.answer()
@adm.callback_query(F.data.startswith("xadm:tog:"))
async def ex_tog(cb: CallbackQuery):
    if not has_perm(cb.from_user.id, "full"): return await cb.answer("❌", show_alert=True)
    _, _, uid_s, key = cb.data.split(":")
    if key not in PERM_KEYS: return await cb.answer("Unknown", show_alert=True)
    uid = int(uid_s); have = admin_perms(uid); have.symmetric_difference_update({key})
    with db() as c: c.execute("UPDATE admins SET perms=? WHERE user_id=? AND role='custom'", (",".join(sorted(have)), uid))
    log_admin(cb.from_user.id, f"admin {uid} perm {key}")
    text, kb_ = _perm_view(uid); await safe_edit(cb, text, kb_); await cb.answer()
    # ══════════════════════════════════════════════════════════
#   GATE (Force-Join + Maintenance)
# ══════════════════════════════════════════════════════════
# ── ToS acceptance + Server 1 one-time confirmation ──
def has_tos(uid):
    return xget(f"tos:{uid}", "") == "1"

def set_tos(uid):
    xset(f"tos:{uid}", "1")

def has_s1_ack(uid):
    return xget(f"s1ack:{uid}", "") == "1"

def set_s1_ack(uid):
    xset(f"s1ack:{uid}", "1")

def tos_accept_kb():
    # Red by default; the colour can be changed live from Admin → Button Colours.
    return InlineKeyboardMarkup(inline_keyboard=[[make_btn("I ACCEPT", cb="tos_accept", default_style="danger", plain=True)]])

def _is_start_or_accept(event):
    if isinstance(event, Message):
        return bool(event.text) and event.text.split()[0].split("@")[0] == "/start"
    if isinstance(event, CallbackQuery):
        return event.data == "tos_accept"
    return False

def _gate_allowed(event):
    """Events that must pass before verification / ToS acceptance."""
    if isinstance(event, Message):
        if event.contact is not None: return True
        return bool(event.text) and event.text.split()[0].split("@")[0] == "/start"
    if isinstance(event, CallbackQuery):
        d = event.data or ""
        return d.startswith("mcap_") or d in ("fj:verify", "tos_accept")
    return False

async def _after_verify(msg, user):
    """Verified: welcome first, then Terms until accepted. A 'Buy Now' deep link opens the shop once Terms are accepted."""
    accepted = is_admin(user.id) or has_tos(user.id)
    if accepted and xget(f"deep:{user.id}") == "buy":
        xset(f"deep:{user.id}", "")
        return await msg.answer(_premium_text(shop_page_text(user)), reply_markup=main_menu_kb(user.id), parse_mode=ParseMode.HTML)
    text = build_welcome_msg(user.id, user.full_name, user.username)
    await send_welcome(msg, text, start_btn_kb(user.id))
    if not accepted: await _show_tos(msg)

class GateMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if _is_payment_update(event): return await handler(event, data)
        if user is None or is_admin(user.id): return await handler(event, data)
        if isinstance(event, CallbackQuery) and event.data == "fj:verify": return await handler(event, data)
        if xget("maintenance") == "1":
            txt = "🛠 Maintenance. Baad mein."
            if isinstance(event, CallbackQuery): await event.answer(txt, show_alert=True)
            elif isinstance(event, Message): await event.answer(txt)
            return
        missing = await missing_channels(data["bot"], user.id)
        if missing:
            if isinstance(event, CallbackQuery): await event.answer()
            # Channel buttons show only the channel name; reg=False keeps per-channel invite links out of the colour list.
            rows = [[make_btn(f"📢 {c['title'] or 'Channel'}", url=c["invite_url"], kind="primary", reg=False)] for c in missing]
            rows.append([xbtn("✅ Verify", "fj:verify", "action")])
            text = ("<b>Access Restricted</b>\n\n"
                    "To use this bot, please join all required channels below, then tap Verify.\n\n"
                    "For private channels, sending a join request is enough. The bot does not approve or cancel your request. "
                    "If a private button is missing, the bot needs admin permission to create its invite link.")
            target = event.message if isinstance(event, CallbackQuery) else event
            await target.answer(_premium_text(text), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows), parse_mode=ParseMode.HTML)
            return
        if _gate_allowed(event): return await handler(event, data)
        if not is_verified(user.id):
            txt = "🔐 Pehle /start karke verification complete karo."
            if isinstance(event, CallbackQuery): await event.answer(txt, show_alert=True)
            else: await event.answer(txt)
            return
        if not has_tos(user.id):
            if _is_start_or_accept(event): return await handler(event, data)
            if isinstance(event, CallbackQuery): await event.answer()
            target = event.message if isinstance(event, CallbackQuery) else event
            await target.answer(_premium_text(_terms_text()), reply_markup=tos_accept_kb(), parse_mode=ParseMode.HTML)
            return
        return await handler(event, data)

# ── ToS accept ──
@router.callback_query(F.data == "tos_accept")
async def cb_tos_accept(cb: CallbackQuery, state: FSMContext):
    uid = cb.from_user.id
    if not is_verified(uid) and not is_admin(uid):
        return await cb.answer("Pehle /start karke verify karo.", show_alert=True)
    if not has_tos(uid) and not is_admin(uid): set_tos(uid)
    await cb.answer("✅ Accepted")
    try: await cb.message.edit_reply_markup(reply_markup=None)
    except Exception: pass
    if xget(f"deep:{uid}") == "buy":
        xset(f"deep:{uid}", "")
        return await cb.message.answer(_premium_text(shop_page_text(cb.from_user)), reply_markup=main_menu_kb(uid), parse_mode=ParseMode.HTML)
    await cb.message.answer(_premium_text("✅ <b>Terms accept ho gaye.</b> Ab aap bot use kar sakte ho."), parse_mode=ParseMode.HTML)

# ── fj:verify callback ──
@router.callback_query(F.data == "fj:verify")
async def ex_fj_verify(cb: CallbackQuery):
    missing = await missing_channels(cb.bot, cb.from_user.id)
    if missing: return await cb.answer(f"Abhi {len(missing)} baaki.", show_alert=True)
    await cb.answer("✅ Verified!"); await cb.message.answer("✅ /start dabao.")

# ── ChatJoinRequest ──
@router.chat_join_request()
async def on_chat_join(req: ChatJoinRequest):
    xset(f"jr:{req.from_user.id}:{req.chat.id}", "1")

# ══════════════════════════════════════════════════════════
#   MAIN
# ══════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════
#   MISSING HELPERS (were referenced but not defined)
# ══════════════════════════════════════════════════════════
def _normalise_admin_link(raw: str):
    s = (raw or "").strip()
    if not s: return None
    if re.fullmatch(r"tg://user\?id=\d{5,15}", s): return s
    m = re.fullmatch(r"(?:https?://)?(?:t\.me|telegram\.me)/(\+?[A-Za-z0-9_]{4,64})/?", s)
    if m: return f"https://t.me/{m.group(1)}"
    m = re.fullmatch(r"@?([A-Za-z][A-Za-z0-9_]{3,31})", s)
    if m: return f"https://t.me/{m.group(1)}"
    return None

def _otp_admin_url():
    link = get_setting("otp_admin_link", "").strip()
    if link: return _normalise_admin_link(link)
    aid = get_setting("otp_admin_id", "0").strip()
    if aid.isdigit() and int(aid) > 0: return f"tg://user?id={aid}"
    return None

# ── Auto OTP forwarding ──
# Sold account ki Telethon session connected rehti hai. Jab bhi Telegram (777000) login code bhejta hai,
# wo code buyer ko bot se forward ho jata hai. Ek account ke liye window OTP_WATCH_HOURS tak chalti hai.
OTP_WATCH_HOURS = 24
_otp_tasks: dict = {}

def _otp_extract(text):
    # Prefer the number right after "code" (Telegram login text); fall back to any 5-6 digit number.
    m = re.search(r"(?:code|kod)\D{0,12}?(\d{5,6})(?!\d)", text or "", re.I) or re.search(r"(?<!\d)(\d{5,6})(?!\d)", text or "")
    return m.group(1) if m else None

async def _otp_watch(account_id, buyer_id, session_data, expires_at):
    from telethon import TelegramClient, events
    from telethon.sessions import StringSession
    api_id_str = get_setting("api_id", ""); api_hash = get_setting("api_hash", "")
    if not api_id_str or not api_hash:
        log.warning("OTP watcher %s: API ID/HASH not set", account_id); return
    if not (session_data or "").strip():
        log.warning("OTP watcher %s: no session stored, skipped", account_id)
        with db() as c: c.execute("DELETE FROM otp_watchers WHERE account_id=?", (account_id,))
        return
    try:
        client = TelegramClient(StringSession(str(session_data).strip()), int(api_id_str), api_hash)
    except Exception as e:
        log.warning("OTP watcher %s: session string is not valid (%s). Re-login this account.", account_id, e)
        with db() as c: c.execute("DELETE FROM otp_watchers WHERE account_id=?", (account_id,))
        return

    async def on_login_code(event):
        code = _otp_extract(event.raw_text)
        if not code: return
        try:
            with db() as c: r = c.execute("SELECT twofa_pass FROM accounts WHERE id=?", (account_id,)).fetchone()
            tfa = (r["twofa_pass"] if r else "") or ""
            body = f"🔐 <b>Login code</b>\n<code>{code}</code>\n\nYe code aapke account ke login ke liye aaya hai. Kisi ko mat dena."
            if tfa: body += f"\n\n🔐 <b>2FA password</b> (agar maange):\n<code>{esc(tfa)}</code>"
            body += "\n\n<b>OTP aur 2FA dene ke baad login ho gaya?</b> Neeche se batao."
            confirm_kb = xkb([xbtn("✅ Haan, login ho gaya", f"lg:yes:{account_id}", "action")],
                             [xbtn("❌ Nahi hua", f"lg:no:{account_id}", "danger")])
            await bot.send_message(buyer_id, _premium_text(body), parse_mode=ParseMode.HTML, reply_markup=confirm_kb)
            log.info("OTP forwarded for account %s to %s", account_id, buyer_id)
        except Exception as e:
            log.warning("OTP forward failed for account %s: %s", account_id, e)

    try:
        await client.connect()
        if not await client.is_user_authorized():
            log.warning("OTP watcher %s: session not authorized", account_id); return
        client.add_event_handler(on_login_code, events.NewMessage(from_users=777000))
        while datetime.now() < expires_at:
            await asyncio.sleep(30)
    except asyncio.CancelledError:
        raise
    except Exception as e:
        log.warning("OTP watcher %s stopped: %s", account_id, e)
    finally:
        try: await client.disconnect()
        except Exception: pass
        with db() as c: c.execute("DELETE FROM otp_watchers WHERE account_id=?", (account_id,))
        _otp_tasks.pop(account_id, None)

def _otp_task_done(t):
    if t.cancelled(): return
    exc = t.exception()
    if exc: log.warning("OTP watcher task ended with error: %s", exc)

def _start_otp_task(account_id, buyer_id, session_data, expires_at):
    old = _otp_tasks.get(account_id)
    if old and not old.done(): old.cancel()
    t = asyncio.create_task(_otp_watch(account_id, buyer_id, session_data, expires_at))
    t.add_done_callback(_otp_task_done)
    _otp_tasks[account_id] = t

def spawn_otp_watcher(account_id, buyer_id, session_data):
    if not (session_data or "").strip():
        log.warning("OTP watcher not started for account %s: no session (already released?)", account_id)
        return
    expires = datetime.now() + timedelta(hours=OTP_WATCH_HOURS)
    with db() as c:
        c.execute("INSERT OR REPLACE INTO otp_watchers(account_id,buyer_id,session_data,started_at,expires_at) VALUES(?,?,?,?,?)",
                  (account_id, buyer_id, session_data, datetime.now().isoformat(), expires.isoformat()))
    _start_otp_task(account_id, buyer_id, session_data, expires)

async def _resume_otp_watchers():
    """Startup: restart watchers for accounts still inside their window, using the account's current session."""
    with db() as c:
        rows = c.execute("""SELECT w.account_id, w.buyer_id, a.session_data, w.expires_at
                            FROM otp_watchers w JOIN accounts a ON a.id = w.account_id""").fetchall()
    for r in rows:
        exp = datetime.fromisoformat(r["expires_at"])
        if exp <= datetime.now() or not (r["session_data"] or "").strip():
            with db() as c: c.execute("DELETE FROM otp_watchers WHERE account_id=?", (r["account_id"],))
            continue
        _start_otp_task(r["account_id"], r["buyer_id"], r["session_data"], exp)

def addfunds_kb():
    return xkb([xbtn("UPI", "dep_upi", "action")], [xbtn("Crypto", "dep_crypto", "action")],
               [xbtn("Telegram Stars", "dep_stars", "action")], [xbtn("⬅ Wallet", "wallet", "nav")])

def amount_kb(method):
    amts = [50, 100, 200, 500, 1000]
    rows = [[xbtn(f"₹{a}", f"amt_{method}_{a}", "action") for a in amts[i:i + 2]] for i in range(0, len(amts), 2)]
    rows.append([xbtn("✏ Custom", f"amt_{method}_custom", "action")])
    rows.append([xbtn("⬅ Back", "addfunds", "nav")])
    return xkb(*rows)

def deposit_kb(code):
    return xkb([xbtn("✅ I have paid", f"verify_{code}", "action")], [xbtn("⬅ Wallet", "wallet", "nav")])

def wallet_kb():
    return xkb([xbtn("➕ Add funds", "addfunds", "action")], [xbtn("🧾 Transactions", "txns", "nav")],
               [xbtn("⬅ Main menu", "main", "nav")])

def profile_kb():
    return xkb([xbtn("💰 Wallet", "wallet", "nav")], [xbtn("📦 My orders", "myorders", "nav")],
               [xbtn("🤝 Refer & Earn", "referral", "primary")],
               [xbtn("⬅ Main menu", "main", "nav")])

def low_balance_kb():
    return xkb([xbtn("➕ Add funds", "addfunds", "action")], [xbtn("⬅ Back", "browse", "nav")])

def after_buy_kb():
    return xkb([xbtn("📦 My orders", "myorders", "nav")], [xbtn("🏠 Main menu", "main", "nav")])

def terms_kb(uid=None):
    rows = []
    if uid is not None and not is_admin(uid) and not has_tos(uid):
        rows.append([make_btn("I ACCEPT", cb="tos_accept", default_style="danger", plain=True)])
    rows.append([xbtn("⬅ Main menu", "main", "nav")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def server_kb():
    return xkb([xbtn("🟢 Server 1 · Budget", "srv_1", "action")], [xbtn("🔵 Server 2 · Premium", "srv_2", "action")],
               [xbtn("🎲 Bulk buy", "bulk", "nav"), xbtn("🔍 Search", "search_country", "nav")],
               [xbtn("⬅ Main menu", "main", "nav")])

def bulk_pick_kb():
    return xkb([xbtn("🟢 Server 1", "bulkpick_1", "action")], [xbtn("🔵 Server 2", "bulkpick_2", "action")],
               [xbtn("⬅ Back", "browse", "nav")])

def agree_kb(yes_cb, back_cb):
    return xkb([xbtn("✅ I agree", yes_cb, "action")], [xbtn("⬅ Back", back_cb, "nav")])

def country_list_kb(server, rows, page=0):
    total_pages = max(1, (len(rows) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = min(max(page, 0), total_pages - 1)
    chunk = rows[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]
    kb_rows = [[xbtn(f"{_flag(r['dial'])} {r['country']} {r['dial']} · {r['stock']} · ₹{float(r['min_price']):.0f}",
                     f"cty_{server}_{r['dial']}", "nav")] for r in chunk]
    nav = []
    if page > 0: nav.append(xbtn("◀ Prev", f"cl_{server}_{page - 1}", "nav"))
    if page < total_pages - 1: nav.append(xbtn("Next ▶", f"cl_{server}_{page + 1}", "nav"))
    if nav: kb_rows.append(nav)
    kb_rows.append([xbtn("⬅ Back", "browse", "nav")])
    return xkb(*kb_rows)

def country_detail_kb(server, dial, rows):
    kb_rows = [[xbtn(f"#{r['id']} · ₹{float(r['price']):.0f}", f"acc_{r['id']}", "nav")] for r in rows[:PAGE_SIZE]]
    kb_rows.append([xbtn("⬅ Back", f"cl_{server}_0", "nav")])
    return xkb(*kb_rows)

def account_kb(acc_id, price, server, dial):
    return xkb([xbtn(f"🛒 Buy · ₹{float(price):.0f}", f"buy_{acc_id}", "action")],
               [xbtn("⬅ Back", f"cty_{server}_{dial}", "nav")])

def filter_kb(server, f):
    spam = {"any": "Any", "free": "Free", "blocked": "Blocked"}.get(f.get("spam", "any"), "Any")
    origin = f.get("origin") or "Any"
    sort = "Low → High" if f.get("sort", "asc") == "asc" else "High → Low"
    return xkb(
        [xbtn(f"Spam: {spam}", f"flt_{server}_spam", "nav")],
        [xbtn(f"⭐ Premium: {'ON' if f.get('prem') else 'OFF'}", f"flt_{server}_prem", "nav"),
         xbtn(f"🔐 2FA: {'ON' if f.get('twofa') else 'OFF'}", f"flt_{server}_twofa", "nav")],
        [xbtn(f"📧 Email: {'ON' if f.get('email') else 'OFF'}", f"flt_{server}_email", "nav")],
        [xbtn(f"Origin: {origin}", f"flt_{server}_origin", "nav")],
        [xbtn(f"Sort: {sort}", f"flt_{server}_sort", "nav")],
        [xbtn("✅ Apply", f"flt_{server}_apply", "action"), xbtn("♻ Reset", f"flt_{server}_reset", "nav")],
        [xbtn("⬅ Back", f"cl_{server}_0", "nav")])


# ══════════════════════════════════════════════════════════
#   REFER & EARN
# ══════════════════════════════════════════════════════════
def ref_percent():
    try: return max(0.0, float(get_setting("ref_percent", "1") or 1))
    except ValueError: return 1.0

def _user_exists(uid):
    with db() as c: return bool(c.execute("SELECT 1 FROM users WHERE user_id=?", (uid,)).fetchone())

def _set_referrer(uid, args):
    """Called from /start only for brand-new users. Accepts 'ref_<referrer_id>'."""
    m = re.fullmatch(r"ref_(\d+)", (args or "").strip(), re.I)
    if not m: return
    ref = int(m.group(1))
    if ref == uid: return                       # no self-referral
    with db() as c:
        if not c.execute("SELECT 1 FROM users WHERE user_id=?", (ref,)).fetchone(): return
        cur = c.execute("UPDATE users SET referred_by=? WHERE user_id=? AND referred_by=0", (ref, uid))
        if cur.rowcount == 1:
            c.execute("UPDATE users SET referrals=referrals+1 WHERE user_id=?", (ref,))

def _credit_referrer(order_code, buyer_id, price):
    """Reward for a delivered order, credited to the referrer's wallet. One reward per order (order_code is unique)."""
    with db() as c:
        r = c.execute("SELECT referred_by FROM users WHERE user_id=?", (buyer_id,)).fetchone()
        ref = r["referred_by"] if r else 0
        if not ref or ref == buyer_id: return 0.0
        amt = round(float(price or 0) * ref_percent() / 100, 2)
        if amt <= 0: return 0.0
        cur = c.execute("INSERT OR IGNORE INTO ref_rewards(order_code,referrer_id,buyer_id,amount,created_at) VALUES(?,?,?,?,?)",
                        (order_code, ref, buyer_id, amt, datetime.now().isoformat()))
        if cur.rowcount != 1: return 0.0
        c.execute("UPDATE users SET balance=balance+?, ref_earned=ref_earned+? WHERE user_id=?", (amt, amt, ref))
    return amt

def _reverse_referrer(order_code):
    """Refunded order: take back the referrer's reward."""
    with db() as c:
        r = c.execute("SELECT referrer_id, amount FROM ref_rewards WHERE order_code=?", (order_code,)).fetchone()
        if not r: return
        c.execute("DELETE FROM ref_rewards WHERE order_code=?", (order_code,))
        c.execute("UPDATE users SET balance=balance-?, ref_earned=ref_earned-? WHERE user_id=?",
                  (r["amount"], r["amount"], r["referrer_id"]))

def _ref_link(uid): return f"https://t.me/{BOT_USERNAME}?start=ref_{uid}"

def referral_view(uid):
    with db() as c:
        row = c.execute("SELECT referrals, ref_earned FROM users WHERE user_id=?", (uid,)).fetchone()
    refs = row["referrals"] if row else 0
    earned = row["ref_earned"] if row else 0
    pct = ref_percent(); link = _ref_link(uid)
    text = (f"🤝 <b>REFER &amp; EARN</b>\n<i>Earn from every purchase your friends make</i>\n{'─'*22}\n"
            f"<pre>REFERRALS : {refs}\nEARNED    : {_money(earned)}\nREWARD    : {pct:g}% of each purchase</pre>\n\n"
            f"<b>YOUR REFERRAL LINK</b>\n<code>{link}</code>\n\n"
            f"<b>HOW IT WORKS</b>\n<pre>1. Share your personal link.\n"
            f"2. A friend starts the bot with it and buys accounts.\n"
            f"3. You get {pct:g}% of each delivered order, credited to your wallet.</pre>\n"
            "<i>Rewards come only from completed purchases. There is no sign-up bonus.</i>")
    share = ("https://t.me/share/url?url=" + quote(link, safe="") +
             "&text=" + quote("Buy verified Telegram accounts here", safe=""))
    kb_ = InlineKeyboardMarkup(inline_keyboard=[
        [make_btn("Share Link", url=share, default_style="primary", plain=True, reg=False)],
        [make_btn("Main Menu", cb="main", default_style="primary", plain=True, reg=False)],
    ])
    return text, kb_

@router.message(Command("referral"))
async def cmd_referral(msg: Message, state: FSMContext):
    await state.clear()
    text, kb_ = referral_view(msg.from_user.id)
    await msg.answer(_premium_text(text), reply_markup=kb_, parse_mode=ParseMode.HTML)

@router.callback_query(F.data == "referral")
async def cb_referral(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    text, kb_ = referral_view(cb.from_user.id)
    await safe_edit(cb, text, kb_); await cb.answer()

async def main():
    global bot, BOT_USERNAME
    init_db()
    bot = Bot(token=BOT_TOKEN)
    BOT_USERNAME = (await bot.get_me()).username or ""
    _reload_btn_overrides()
    _warm_btn_registry()
    if xget("captcha_v2") != "1":
        set_setting("verif_math", "1"); xset("captcha_v2", "1")
    if cfg_sales_channel() and not get_setting("sales_link", "").strip():
        try:
            ch = await bot.get_chat(cfg_sales_channel())
            if ch.username: set_setting("sales_link", f"https://t.me/{ch.username}")
        except Exception as e:
            log.warning("sales channel username not resolved: %s", e)
    dp = Dispatcher(storage=MemoryStorage())
    dp.message.outer_middleware(GateMiddleware())
    dp.callback_query.outer_middleware(GateMiddleware())
    dp.include_router(router)
    dp.include_router(adm)
    log.info(f"{BOT_NAME} starting…")
    
    # OTP Watchers resume on startup
    asyncio.create_task(_resume_otp_watchers())
    
    await dp.start_polling(bot, allowed_updates=["message", "callback_query", "chat_join_request", "pre_checkout_query"])

if __name__ == "__main__":
    asyncio.run(main())
           